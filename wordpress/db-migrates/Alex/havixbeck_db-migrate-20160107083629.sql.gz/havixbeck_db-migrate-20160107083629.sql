# WordPress MySQL database migration
#
# Generated: Thursday 7. January 2016 08:36 UTC
# Hostname: localhost
# Database: `havixbeck_db`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-10-22 09:58:38', '2015-10-22 07:58:38', 'Hi, das ist ein Kommentar.\nUm einen Kommentar zu löschen, melde dich einfach an und betrachte die Beitrags-Kommentare. Dort hast du die Möglichkeit sie zu löschen oder zu bearbeiten. ', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_nextend_smartslider_layouts`
#

DROP TABLE IF EXISTS `wp_nextend_smartslider_layouts`;


#
# Table structure of table `wp_nextend_smartslider_layouts`
#

CREATE TABLE `wp_nextend_smartslider_layouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `slide` longtext,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_nextend_smartslider_layouts`
#

#
# End of data contents of table `wp_nextend_smartslider_layouts`
# --------------------------------------------------------



#
# Delete any existing table `wp_nextend_smartslider_sliders`
#

DROP TABLE IF EXISTS `wp_nextend_smartslider_sliders`;


#
# Table structure of table `wp_nextend_smartslider_sliders`
#

CREATE TABLE `wp_nextend_smartslider_sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `params` text NOT NULL,
  `generator` text NOT NULL,
  `slide` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_nextend_smartslider_sliders`
#
INSERT INTO `wp_nextend_smartslider_sliders` ( `id`, `title`, `type`, `params`, `generator`, `slide`) VALUES
(1, 'MainPage', 'simple', '{"size":"800|*|500|*|1","responsive":"1|*|0","align":"left","globalfontsize":"12|*|16|*|20","margin":"0|*|0|*|0|*|0|*|px","simplebackgroundimage":"","simplebackgroundimagesize":"auto","simplepadding":"0|*|0|*|0|*|0","simpleborder":"0|*|3E3E3Eff","simpleborderradius":"0|*|0|*|0|*|0","simpleresponsivemaxwidth":"3000","improvedtouch":"0","simpleskins":"","simpleslidercss":"","simpleanimation":"horizontal","simpleanimationproperties":"1500|*|0|*|easeInOutQuint|*|1","simplebackgroundanimation":"0|*|bars||blocks","fadeonload":"1|*|0","playfirstlayer":"0","mainafterout":"1","inaftermain":"1","controls":"1|*|0|*|1","blockrightclick":"0","imageload":"0|*|0","backgroundresize":"cover","randomize":"0","autoplay":"1|*|5000","autoplayfinish":"0|*|loop|*|current","stopautoplay":"1|*|1|*|1","resumeautoplay":"0|*|1|*|0","widgetarrow":"transition","widgetarrowdisplay":"1|*|hover|*|0|*|0","previousposition":"left|*|0|*|%|*|top|*|50|*|%","previous":"\\/plugins\\/smart-slider-2\\/plugins\\/nextendsliderwidgetarrow\\/transition\\/transition\\/previous\\/my-test.png","nextposition":"right|*|0|*|%|*|top|*|50|*|%","next":"\\/plugins\\/smart-slider-2\\/plugins\\/nextendsliderwidgetarrow\\/transition\\/transition\\/next\\/my-test.png","arrowbackground":"00000080","arrowbackgroundhover":"7670c7ff","widgetbullet":"numbers","widgetbulletdisplay":"0|*|always|*|0|*|0","bulletposition":"left|*|0|*|%|*|bottom|*|5|*|%","bulletwidth":"100%","bulletorientation":"horizontal","bulletalign":"center","bullet":"\\/plugins\\/smart-slider-2\\/plugins\\/nextendsliderwidgetbullet\\/numbers\\/numbers\\/bullets\\/square.png","bulletbackground":"00000060","bulletbackgroundhover":"7670C7ff","fontclassnumber":"sliderfont7","bulletbar":"none","bulletshadow":"none","bulletbarcolor":"00000060","bullethumbnail":"0|*|top","thumbnailsizebullet":"100|*|60","bulletthumbnail":"00000060","widgets":"thumbnail"}', '', '') ;

#
# End of data contents of table `wp_nextend_smartslider_sliders`
# --------------------------------------------------------



#
# Delete any existing table `wp_nextend_smartslider_slides`
#

DROP TABLE IF EXISTS `wp_nextend_smartslider_slides`;


#
# Table structure of table `wp_nextend_smartslider_slides`
#

CREATE TABLE `wp_nextend_smartslider_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `slider` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  `first` int(11) NOT NULL,
  `slide` longtext,
  `description` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `background` varchar(300) NOT NULL,
  `params` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `generator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_nextend_smartslider_slides`
#
INSERT INTO `wp_nextend_smartslider_slides` ( `id`, `title`, `slider`, `publish_up`, `publish_down`, `published`, `first`, `slide`, `description`, `thumbnail`, `background`, `params`, `ordering`, `generator`) VALUES
(1, 'Slide 1', 1, '2015-11-09 12:40:53', '2025-11-10 12:40:53', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer #1" class="smart-slider-layer" style="top: 0%; left: 0%; width: 100%; height: 100%; position: absolute; z-index: 1; display: block;" data-animation="slide" data-desktopleft="0%" data-desktoptop="0%" data-showdesktop="1" data-showtablet="1" data-showphone="1" data-layerbackgroundcolor="00000000">[image values="eyJpbWFnZSI6Imh0dHA6Ly9sb2NhbGhvc3QvbXVzaWtzY2h1bGUtd3AtdGhlbWUvd29yZHByZXNzL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzExL011c2lrc2NodWxlLUtsaWNrLTEwMjR4OTI1LmpwZyIsImFsdCI6Ii0iLCJ0aXRsZSI6IiIsImxpbmsiOiIjfCp8X3NlbGYiLCJzaXplIjoiMTAwJXwqfGF1dG8iLCJjc3NjbGFzcyI6IiIsImNzcyI6IiIsIm9ubW91c2VlbnRlciI6IiIsIm9ubW91c2VjbGljayI6IiIsIm9ubW91c2VsZWF2ZSI6IiIsImtlbmJ1cm5zIjoiMHwqfDEwMDAwfCp8MTE1fCp8MC01MCUgNTAlfCp8MCJ9"]</div>', '', 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/11/Musikschule-Klick-1024x925.jpg', 'ffffff00|*||*|', '{"link":"|*|_self","adminmode":"all"}', 1, 0) ;

#
# End of data contents of table `wp_nextend_smartslider_slides`
# --------------------------------------------------------



#
# Delete any existing table `wp_nextend_smartslider_storage`
#

DROP TABLE IF EXISTS `wp_nextend_smartslider_storage`;


#
# Table structure of table `wp_nextend_smartslider_storage`
#

CREATE TABLE `wp_nextend_smartslider_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(200) NOT NULL,
  `value` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_nextend_smartslider_storage`
#
INSERT INTO `wp_nextend_smartslider_storage` ( `id`, `key`, `value`) VALUES
(1, 'layout', '{"size":"1024|*|768"}'),
(2, 'settings', '{"debugmessages":"1","slideeditoralert":"1","translateurl":"|*|","jquery":"1","placeholder":"http:\\/\\/www.nextendweb.com\\/static\\/placeholder.png","tidy-input-encoding":"utf8","tidy-output-encoding":"utf8"}'),
(3, 'font', '{"sliderfont1customlabel":"Heading light","sliderfont1":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"320||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":1,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"paddingleft\\":0,\\"size\\":\\"100||%\\"},\\"Link:Hover\\":{\\"paddingleft\\":0,\\"size\\":\\"100||%\\"}}","sliderfont2customlabel":"Heading dark","sliderfont2":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"320||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":1,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont3customlabel":"Subheading light","sliderfont3":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"170||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont4customlabel":"Subheading dark","sliderfont4":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"170||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont5customlabel":"Paragraph light","sliderfont5":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"114||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.4\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"justify\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont6customlabel":"Paragraph dark","sliderfont6":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"114||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.4\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"justify\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont7customlabel":"Small text light","sliderfont7":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"90||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont8customlabel":"Small text dark","sliderfont8":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"90||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.1\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont9customlabel":"Handwritten light","sliderfont9":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"140||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Pacifico);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont10customlabel":"Handwritten dark","sliderfont10":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"140||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Pacifico);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont11customlabel":"Button light","sliderfont11":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"100||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"center\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont12customlabel":"Button dark","sliderfont12":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"100||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"center\\",\\"paddingleft\\":0},\\"Link\\":{\\"paddingleft\\":0,\\"size\\":\\"100||%\\"},\\"Link:Hover\\":{\\"paddingleft\\":0,\\"size\\":\\"100||%\\"}}","sliderfontcustom1customlabel":"My first custom font","sliderfontcustom1":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"1abc9cff\\",\\"size\\":\\"360||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Pacifico);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfontcustom2customlabel":"My second custom font","sliderfontcustom2":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"140||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"center\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfontcustom3customlabel":"My third custom font","sliderfontcustom3":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"1abc9cff\\",\\"size\\":\\"120||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"center\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfontcustom4customlabel":"My fourthcustom font ","sliderfontcustom4":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"1abc9cff\\",\\"size\\":\\"120||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\\\\\/\\\\\\/fonts.googleapis.com\\\\\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"right\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}"}'),
(4, 'sliderchanged1', '0'),
(5, 'slidercache1', '{"time":1447159255,"data":{"css":"http:\\/\\/localhost\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/cache\\/css\\/static\\/4ef0144d43d1a33a64e446a4a92ed6ec.css","js":{"core":{"\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/assets\\/js\\/class.js":"\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/assets\\/js\\/class.js"}},"fonts":{"Open Sans":{"0":400,"1":"latin","400,latin":1},"Pacifico":{"0":400,"1":"latin","400,latin":1}},"html":"<div class=\'ss2-align\' style=\'float:left;\'><script type=\\"text\\/javascript\\">\\r\\n    window[\'nextend-smart-slider-1-onresize\'] = [];\\r\\n<\\/script>\\r\\n\\r\\n<div id=\\"nextend-smart-slider-1\\" class=\\"nextend-slider-fadeload nextend-desktop \\" style=\\"font-size: 12px;\\" data-allfontsize=\\"12\\" data-desktopfontsize=\\"12\\" data-tabletfontsize=\\"16\\" data-phonefontsize=\\"20\\">\\r\\n    <div class=\\"smart-slider-border1\\" style=\\"\\">\\r\\n        <div class=\\"smart-slider-border2\\">\\r\\n            \\r\\n                            <div class=\\"smart-slider-canvas smart-slider-slide-active smart-slider-bg-colored\\" style=\\"\\">\\r\\n                                                            <div class=\\"smart-slider-canvas-inner\\">\\r\\n                        <div data-parallaxout=\\"0.45\\" data-delayout=\\"0\\" data-easingout=\\"linear\\" data-durationout=\\"500\\" data-animationout=\\"0\\" data-playoutafter=\\"0\\" data-parallaxin=\\"0.45\\" data-delayin=\\"0\\" data-easingin=\\"linear\\" data-durationin=\\"500\\" data-animationin=\\"0\\" data-name=\\"Layer #1\\" class=\\"smart-slider-layer\\" style=\\"top: 0%; left: 0%; width: 100%; height: 100%; position: absolute; z-index: 1; display: block;\\" data-animation=\\"slide\\" data-desktopleft=\\"0%\\" data-desktoptop=\\"0%\\" data-showdesktop=\\"1\\" data-showtablet=\\"1\\" data-showphone=\\"1\\" data-layerbackgroundcolor=\\"00000000\\"><div >\\r\\n            \\r\\n                <img id=\\"nextend-smart-slider-1item1\\"  src=\\"http:\\/\\/localhost\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/uploads\\/2015\\/11\\/Musikschule-Klick-1024x925.jpg\\" data-desktop=\\"http:\\/\\/localhost\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/uploads\\/2015\\/11\\/Musikschule-Klick-1024x925.jpg\\"  style=\\"display: block; max-width: 100%; ;width:100%;height:auto;\\" class=\\" \\" alt=\\"-\\" title=\\"\\" \\/>\\r\\n            \\r\\n        <\\/div><\\/div>                    <\\/div>\\r\\n                                    <\\/div>\\r\\n                    <\\/div>\\r\\n    <\\/div>\\r\\n    <div onclick=\\"njQuery(\'#nextend-smart-slider-1\').smartslider(\'previous\');\\" class=\\"nextend-widget nextend-widget-hover nextend-widget-display-desktop nextend-arrow-previous nextend-transition nextend-transition-previous nextend-transition-previous-my-test\\" style=\\"position: absolute;left:0%;top:50%;\\" ><div class=\\"smartslider-outer\\"><\\/div><div class=\\"smartslider-inner\\"><\\/div><\\/div><div onclick=\\"njQuery(\'#nextend-smart-slider-1\').smartslider(\'next\');\\" class=\\"nextend-widget nextend-widget-hover nextend-widget-display-desktop nextend-arrow-next nextend-transition nextend-transition-next nextend-transition-next-my-test\\" style=\\"position: absolute;right:0%;top:50%;\\" ><div class=\\"smartslider-outer\\"><\\/div><div class=\\"smartslider-inner\\"><\\/div><\\/div><\\/div>\\r\\n\\r\\n<script type=\\"text\\/javascript\\">\\r\\n    njQuery(document).ready(function () {\\r\\n        njQuery(\'#nextend-smart-slider-1\').smartslider({\\"translate3d\\":1,\\"playfirstlayer\\":0,\\"mainafterout\\":1,\\"inaftermain\\":1,\\"fadeonscroll\\":0,\\"autoplay\\":1,\\"autoplayConfig\\":{\\"duration\\":5000,\\"counter\\":0,\\"autoplayToSlide\\":0,\\"stopautoplay\\":{\\"click\\":1,\\"mouseenter\\":1,\\"slideplaying\\":1},\\"resumeautoplay\\":{\\"mouseleave\\":0,\\"slideplayed\\":1,\\"slidechanged\\":0}},\\"responsive\\":{\\"downscale\\":1,\\"upscale\\":0,\\"maxwidth\\":3000,\\"basedon\\":\\"combined\\",\\"screenwidth\\":{\\"tablet\\":1024,\\"phone\\":640},\\"ratios\\":[1,1,0.7,0.5]},\\"controls\\":{\\"scroll\\":1,\\"touch\\":\\"0\\",\\"keyboard\\":1},\\"blockrightclick\\":0,\\"lazyload\\":0,\\"lazyloadneighbor\\":0,\\"randomize\\":0,\\"type\\":\\"ssSimpleSlider\\",\\"animation\\":[\\"horizontal\\"],\\"animationSettings\\":{\\"duration\\":1500,\\"delay\\":0,\\"easing\\":\\"easeInOutQuint\\",\\"parallax\\":1},\\"flux\\":[0,[\\"bars\\",\\"blocks\\"]],\\"touchanimation\\":\\"0\\"});\\r\\n    });\\r\\n<\\/script>\\r\\n<div style=\\"clear: both;\\"><\\/div>\\r\\n<\\/div><div style=\'clear:both;\'><\\/div><div id=\\"nextend-smart-slider-1-placeholder\\" ><img alt=\\"\\" style=\\"width:100%; max-width: 3000px;\\" src=\\"data:image\\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAH0CAYAAADFQEl4AAAKXUlEQVR4nO3XMQEAIAzAMMC\\/5+GiHCQK+nbPAgAAaJzXAQAAwD8MCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABAxoAAAAAZAwIAAGQMCAAAkDEgAABA5gIFngTnPiV7xAAAAABJRU5ErkJggg==\\" \\/><\\/div>","libraries":{"modernizr":{"jsfiles":["\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/modernizr\\/modernizr.js"],"js":""},"jquery":{"jsfiles":["\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/njQuery.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jQuery.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/uacss.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.unique-element-id.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.unveil.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.waitforimages.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.mousewheel.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/easing.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.transit.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/animationbase.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/smartsliderbase.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/mainslider.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/layers.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/no.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/nostatic.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/fade.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/fadestatic.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/slide.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/slidestatic.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/transit.js","\\/Applications\\/MAMP\\/htdocs\\/musikschule-wp-theme\\/wordpress\\/wp-content\\/plugins\\/smart-slider-2\\/plugins\\/nextendslidertype\\/simple\\/simple\\/slider.js"],"js":""}}},"slideexpire":1762778453}') ;

#
# End of data contents of table `wp_nextend_smartslider_storage`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5746 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/musikschule-wp-theme/wordpress', 'yes'),
(2, 'home', 'http://localhost/musikschule-wp-theme/wordpress', 'yes'),
(3, 'blogname', 'Jugendorchester Havixbeck', 'yes'),
(4, 'blogdescription', 'Die Webseite des Jugendorchesters Havixbeck', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'brian.joe.stark@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '3', 'yes'),
(13, 'rss_use_excerpt', '1', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j. F Y', 'yes'),
(24, 'time_format', 'G:i', 'yes'),
(25, 'links_updated_date_format', 'j. F Y G:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:23:"admin-bar/admin-bar.php";i:1;s:33:"admin-menu-editor/menu-editor.php";i:2;s:30:"advanced-custom-fields/acf.php";i:3;s:35:"si-contact-form/si-contact-form.php";i:4;s:45:"simple-page-ordering/simple-page-ordering.php";i:5;s:43:"the-events-calendar/the-events-calendar.php";i:6;s:31:"wp-google-maps/wpGoogleMaps.php";i:7;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', 'a:2:{i:0;s:94:"/Applications/MAMP/htdocs/musikschule-wp-theme/wordpress/wp-content/themes/Havixbeck/style.css";i:2;s:0:"";}', 'no'),
(41, 'template', 'Havixbeck', 'yes'),
(42, 'stylesheet', 'Havixbeck', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '0', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '33056', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '1', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '1', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '0', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '0', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(82, 'uninstall_plugins', 'a:0:{}', 'no'),
(83, 'timezone_string', 'Europe/Berlin', 'yes'),
(84, 'page_for_posts', '15', 'yes'),
(85, 'page_on_front', '4', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'finished_splitting_shared_terms', '1', 'yes'),
(89, 'initial_db_version', '33056', 'yes'),
(90, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:92:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:25:"read_private_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:24:"edit_others_tribe_events";b:1;s:25:"edit_private_tribe_events";b:1;s:27:"edit_published_tribe_events";b:1;s:19:"delete_tribe_events";b:1;s:26:"delete_others_tribe_events";b:1;s:27:"delete_private_tribe_events";b:1;s:29:"delete_published_tribe_events";b:1;s:20:"publish_tribe_events";b:1;s:25:"read_private_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:24:"edit_others_tribe_venues";b:1;s:25:"edit_private_tribe_venues";b:1;s:27:"edit_published_tribe_venues";b:1;s:19:"delete_tribe_venues";b:1;s:26:"delete_others_tribe_venues";b:1;s:27:"delete_private_tribe_venues";b:1;s:29:"delete_published_tribe_venues";b:1;s:20:"publish_tribe_venues";b:1;s:29:"read_private_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;s:28:"edit_others_tribe_organizers";b:1;s:29:"edit_private_tribe_organizers";b:1;s:31:"edit_published_tribe_organizers";b:1;s:23:"delete_tribe_organizers";b:1;s:30:"delete_others_tribe_organizers";b:1;s:31:"delete_private_tribe_organizers";b:1;s:33:"delete_published_tribe_organizers";b:1;s:24:"publish_tribe_organizers";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:64:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:25:"read_private_tribe_events";b:1;s:17:"edit_tribe_events";b:1;s:24:"edit_others_tribe_events";b:1;s:25:"edit_private_tribe_events";b:1;s:27:"edit_published_tribe_events";b:1;s:19:"delete_tribe_events";b:1;s:26:"delete_others_tribe_events";b:1;s:27:"delete_private_tribe_events";b:1;s:29:"delete_published_tribe_events";b:1;s:20:"publish_tribe_events";b:1;s:25:"read_private_tribe_venues";b:1;s:17:"edit_tribe_venues";b:1;s:24:"edit_others_tribe_venues";b:1;s:25:"edit_private_tribe_venues";b:1;s:27:"edit_published_tribe_venues";b:1;s:19:"delete_tribe_venues";b:1;s:26:"delete_others_tribe_venues";b:1;s:27:"delete_private_tribe_venues";b:1;s:29:"delete_published_tribe_venues";b:1;s:20:"publish_tribe_venues";b:1;s:29:"read_private_tribe_organizers";b:1;s:21:"edit_tribe_organizers";b:1;s:28:"edit_others_tribe_organizers";b:1;s:29:"edit_private_tribe_organizers";b:1;s:31:"edit_published_tribe_organizers";b:1;s:23:"delete_tribe_organizers";b:1;s:30:"delete_others_tribe_organizers";b:1;s:31:"delete_private_tribe_organizers";b:1;s:33:"delete_published_tribe_organizers";b:1;s:24:"publish_tribe_organizers";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:25:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:17:"edit_tribe_events";b:1;s:27:"edit_published_tribe_events";b:1;s:19:"delete_tribe_events";b:1;s:29:"delete_published_tribe_events";b:1;s:20:"publish_tribe_events";b:1;s:17:"edit_tribe_venues";b:1;s:27:"edit_published_tribe_venues";b:1;s:19:"delete_tribe_venues";b:1;s:29:"delete_published_tribe_venues";b:1;s:20:"publish_tribe_venues";b:1;s:21:"edit_tribe_organizers";b:1;s:31:"edit_published_tribe_organizers";b:1;s:23:"delete_tribe_organizers";b:1;s:33:"delete_published_tribe_organizers";b:1;s:24:"publish_tribe_organizers";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:11:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:17:"edit_tribe_events";b:1;s:19:"delete_tribe_events";b:1;s:17:"edit_tribe_venues";b:1;s:19:"delete_tribe_venues";b:1;s:21:"edit_tribe_organizers";b:1;s:23:"delete_tribe_organizers";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(91, 'WPLANG', 'de_DE', 'yes'),
(92, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(99, 'cron', 'a:5:{i:1452186120;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1452196718;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1452206168;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1452240021;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(110, 'can_compress_scripts', '1', 'yes'),
(122, 'recently_activated', 'a:0:{}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(157, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1447015505;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(158, 'current_theme', 'Hevixbeck', 'yes'),
(159, 'theme_mods_Havixbeck', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:4:{s:8:"top_menu";i:2;s:7:"primary";i:2;s:4:"side";i:4;s:6:"side_2";i:5;}}', 'yes'),
(160, 'theme_switched', '', 'yes'),
(210, 'widget_nav_menu', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(211, 'widget_calendar', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(213, 'widget_tag_cloud', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(214, 'widget_pages', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(257, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(260, 'widget_nextendsmartslider2widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(465, 'acf_version', '4.4.3', 'yes'),
(509, 'tribe_events_calendar_options', 'a:37:{s:14:"schema-version";s:3:"4.0";s:27:"recurring_events_are_hidden";s:6:"hidden";s:21:"previous_ecp_versions";a:1:{i:0;s:1:"0";}s:18:"latest_ecp_version";s:3:"4.0";s:19:"last-update-message";s:3:"4.0";s:16:"stylesheetOption";s:4:"full";s:19:"tribeEventsTemplate";s:7:"default";s:16:"tribeEnableViews";a:1:{i:0;s:4:"list";}s:10:"viewOption";s:4:"list";s:20:"tribeDisableTribeBar";b:0;s:16:"monthEventAmount";s:1:"3";s:23:"enable_month_view_cache";b:0;s:18:"dateWithYearFormat";s:6:"j. F Y";s:21:"dateWithoutYearFormat";s:3:"F j";s:18:"monthAndYearFormat";s:3:"F Y";s:17:"dateTimeSeparator";s:3:" @ ";s:18:"timeRangeSeparator";s:3:" - ";s:16:"datepickerFormat";s:1:"0";s:21:"tribeEventsBeforeHTML";s:0:"";s:20:"tribeEventsAfterHTML";s:0:"";s:11:"donate-link";b:0;s:12:"postsPerPage";s:2:"10";s:17:"liveFiltersUpdate";b:0;s:12:"showComments";b:0;s:20:"showEventsInMainLoop";b:0;s:15:"singleEventSlug";s:5:"event";s:14:"multiDayCutoff";s:5:"07:00";s:21:"defaultCurrencySymbol";s:3:"€";s:23:"reverseCurrencyPosition";b:0;s:15:"embedGoogleMaps";b:0;s:19:"embedGoogleMapsZoom";s:2:"10";s:11:"debugEvents";b:0;s:26:"tribe_events_timezone_mode";s:5:"event";s:32:"tribe_events_timezones_show_zone";b:0;s:10:"eventsSlug";s:7:"termine";s:13:"earliest_date";s:19:"2015-12-08 08:00:00";s:11:"latest_date";s:19:"2015-12-14 17:00:00";}', 'yes'),
(510, 'tribe_last_save_post', '1452155797', 'yes'),
(553, 'tribe_events_cat_children', 'a:0:{}', 'yes'),
(566, 'category_children', 'a:0:{}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(571, 'ws_menu_editor', 'a:18:{s:22:"hide_advanced_settings";b:1;s:16:"show_extra_icons";b:0;s:11:"custom_menu";a:3:{s:4:"tree";a:20:{s:9:"index.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:10:">index.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:19:"index.php>index.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:4:"Home";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"index.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:9:"index.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:19:"index.php>index.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"index.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:25:"index.php>update-core.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:209:"Aktualisierungen <span class=\'update-plugins count-6\' title=\'1 WordPress-Aktualisierung, 3 Plugin-Updates, 1 Theme-Aktualisierung, Aktualisierungen der Übersetzung \'><span class=\'update-count\'>6</span></span>";s:12:"access_level";s:11:"update_core";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"update-core.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:9:"index.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:25:"index.php>update-core.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:15:"update-core.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Dashboard";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"index.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:0:"";s:9:"css_class";s:43:"menu-top menu-top-first menu-icon-dashboard";s:8:"hookname";s:14:"menu-dashboard";s:8:"icon_url";s:19:"dashicons-dashboard";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:10:">index.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"index.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"separator_3";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">separator_3";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_3";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">separator_3";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:8:"edit.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:9:">edit.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:4:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";s:16:"Alle Instrumente";s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:17:"edit.php>edit.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:14:"Alle Beiträge";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"edit.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:17:"edit.php>edit.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:8:"edit.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"edit.php>post-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Erstellen";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"post-new.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"edit.php>post-new.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:12:"post-new.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=category";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Kategorien";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit-tags.php?taxonomy=category";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=category";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit-tags.php?taxonomy=category";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=post_tag";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Schlagworte";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit-tags.php?taxonomy=post_tag";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:8:"edit.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:40:"edit.php>edit-tags.php?taxonomy=post_tag";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit-tags.php?taxonomy=post_tag";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Beiträge";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:8:"edit.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:0:"";s:9:"css_class";s:37:"open-if-no-js menu-top menu-icon-post";s:8:"hookname";s:10:"menu-posts";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:9:">edit.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:8:"edit.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:31:"edit.php?post_type=tribe_events";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:32:">edit.php?post_type=tribe_events";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:9:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:63:"edit.php?post_type=tribe_events>edit.php?post_type=tribe_events";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:15:"Veranstaltungen";s:12:"access_level";s:17:"edit_tribe_events";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit.php?post_type=tribe_events";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:31:"edit.php?post_type=tribe_events";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:63:"edit.php?post_type=tribe_events>edit.php?post_type=tribe_events";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit.php?post_type=tribe_events";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:67:"edit.php?post_type=tribe_events>post-new.php?post_type=tribe_events";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Hinzufügen";s:12:"access_level";s:17:"edit_tribe_events";s:16:"extra_capability";s:0:"";s:4:"file";s:35:"post-new.php?post_type=tribe_events";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:31:"edit.php?post_type=tribe_events";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:67:"edit.php?post_type=tribe_events>post-new.php?post_type=tribe_events";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:35:"post-new.php?post_type=tribe_events";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:90:"edit.php?post_type=tribe_events>edit-tags.php?taxonomy=post_tag&amp;post_type=tribe_events";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Schlagworte";s:12:"access_level";s:17:"manage_categories";s:16:"extra_capability";s:0:"";s:4:"file";s:58:"edit-tags.php?taxonomy=post_tag&amp;post_type=tribe_events";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:31:"edit.php?post_type=tribe_events";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:90:"edit.php?post_type=tribe_events>edit-tags.php?taxonomy=post_tag&amp;post_type=tribe_events";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:54:"edit-tags.php?taxonomy=post_tag&post_type=tribe_events";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:98:"edit.php?post_type=tribe_events>edit-tags.php?taxonomy=tribe_events_cat&amp;post_type=tribe_events";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:25:"Veranstaltungs-Kategorien";s:12:"access_level";s:20:"publish_tribe_events";s:16:"extra_capability";s:0:"";s:4:"file";s:66:"edit-tags.php?taxonomy=tribe_events_cat&amp;post_type=tribe_events";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:31:"edit.php?post_type=tribe_events";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:98:"edit.php?post_type=tribe_events>edit-tags.php?taxonomy=tribe_events_cat&amp;post_type=tribe_events";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:62:"edit-tags.php?taxonomy=tribe_events_cat&post_type=tribe_events";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:62:"edit.php?post_type=tribe_events>edit.php?post_type=tribe_venue";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:18:"Veranstaltungsorte";s:10:"menu_title";s:18:"Veranstaltungsorte";s:12:"access_level";s:17:"edit_tribe_venues";s:16:"extra_capability";s:0:"";s:4:"file";s:30:"edit.php?post_type=tribe_venue";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:31:"edit.php?post_type=tribe_events";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:62:"edit.php?post_type=tribe_events>edit.php?post_type=tribe_venue";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:30:"edit.php?post_type=tribe_venue";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:66:"edit.php?post_type=tribe_events>edit.php?post_type=tribe_organizer";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:12:"Veranstalter";s:10:"menu_title";s:12:"Veranstalter";s:12:"access_level";s:21:"edit_tribe_organizers";s:16:"extra_capability";s:0:"";s:4:"file";s:34:"edit.php?post_type=tribe_organizer";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:31:"edit.php?post_type=tribe_events";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:66:"edit.php?post_type=tribe_events>edit.php?post_type=tribe_organizer";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:34:"edit.php?post_type=tribe_organizer";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:6;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:47:"edit.php?post_type=tribe_events>events-importer";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:11:"Importieren";s:10:"menu_title";s:11:"Importieren";s:12:"access_level";s:6:"import";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"events-importer";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:31:"edit.php?post_type=tribe_events";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:47:"edit.php?post_type=tribe_events>events-importer";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:52:"edit.php?post_type=tribe_events&page=events-importer";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:7;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:44:"edit.php?post_type=tribe_events>tribe-common";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:27:"Veranstaltungseinstellungen";s:10:"menu_title";s:13:"Einstellungen";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"tribe-common";s:12:"page_heading";s:0:"";s:8:"position";i:7;s:6:"parent";s:31:"edit.php?post_type=tribe_events";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:44:"edit.php?post_type=tribe_events>tribe-common";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:49:"edit.php?post_type=tribe_events&page=tribe-common";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:8;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:46:"edit.php?post_type=tribe_events>tribe-app-shop";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:7:"Add-Ons";s:10:"menu_title";s:7:"Add-Ons";s:12:"access_level";s:15:"install_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:14:"tribe-app-shop";s:12:"page_heading";s:0:"";s:8:"position";i:8;s:6:"parent";s:31:"edit.php?post_type=tribe_events";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:46:"edit.php?post_type=tribe_events>tribe-app-shop";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:51:"edit.php?post_type=tribe_events&page=tribe-app-shop";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:15:"Veranstaltungen";s:12:"access_level";s:17:"edit_tribe_events";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"edit.php?post_type=tribe_events";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:0:"";s:9:"css_class";s:31:"menu-top menu-icon-tribe_events";s:8:"hookname";s:23:"menu-posts-tribe_events";s:8:"icon_url";s:18:"dashicons-calendar";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:32:">edit.php?post_type=tribe_events";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"edit.php?post_type=tribe_events";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"separator_4";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">separator_4";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_4";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">separator_4";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:30:"edit.php?post_type=instrumente";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:31:">edit.php?post_type=instrumente";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:61:"edit.php?post_type=instrumente>edit.php?post_type=instrumente";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Instrumente";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:30:"edit.php?post_type=instrumente";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:30:"edit.php?post_type=instrumente";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:61:"edit.php?post_type=instrumente>edit.php?post_type=instrumente";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:30:"edit.php?post_type=instrumente";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:65:"edit.php?post_type=instrumente>post-new.php?post_type=instrumente";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Erstellen";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:34:"post-new.php?post_type=instrumente";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:30:"edit.php?post_type=instrumente";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:65:"edit.php?post_type=instrumente>post-new.php?post_type=instrumente";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:34:"post-new.php?post_type=instrumente";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Instrumente";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:30:"edit.php?post_type=instrumente";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:0:"";s:9:"css_class";s:23:"menu-top menu-icon-post";s:8:"hookname";s:22:"menu-posts-instrumente";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:31:">edit.php?post_type=instrumente";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:30:"edit.php?post_type=instrumente";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:27:"edit.php?post_type=dozenten";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:28:">edit.php?post_type=dozenten";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:55:"edit.php?post_type=dozenten>edit.php?post_type=dozenten";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Dozenten";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:27:"edit.php?post_type=dozenten";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:27:"edit.php?post_type=dozenten";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:55:"edit.php?post_type=dozenten>edit.php?post_type=dozenten";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:27:"edit.php?post_type=dozenten";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:59:"edit.php?post_type=dozenten>post-new.php?post_type=dozenten";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Erstellen";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:31:"post-new.php?post_type=dozenten";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:27:"edit.php?post_type=dozenten";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:59:"edit.php?post_type=dozenten>post-new.php?post_type=dozenten";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:31:"post-new.php?post_type=dozenten";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Dozenten";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:27:"edit.php?post_type=dozenten";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:0:"";s:9:"css_class";s:23:"menu-top menu-icon-post";s:8:"hookname";s:19:"menu-posts-dozenten";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:28:">edit.php?post_type=dozenten";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:27:"edit.php?post_type=dozenten";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:26:"edit.php?post_type=faecher";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:7;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:">edit.php?post_type=faecher";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:53:"edit.php?post_type=faecher>edit.php?post_type=faecher";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Fächer";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:26:"edit.php?post_type=faecher";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:26:"edit.php?post_type=faecher";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:53:"edit.php?post_type=faecher>edit.php?post_type=faecher";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:26:"edit.php?post_type=faecher";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:57:"edit.php?post_type=faecher>post-new.php?post_type=faecher";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Erstellen";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:30:"post-new.php?post_type=faecher";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:26:"edit.php?post_type=faecher";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:57:"edit.php?post_type=faecher>post-new.php?post_type=faecher";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:30:"post-new.php?post_type=faecher";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Fächer";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:26:"edit.php?post_type=faecher";s:12:"page_heading";s:0:"";s:8:"position";i:7;s:6:"parent";s:0:"";s:9:"css_class";s:23:"menu-top menu-icon-post";s:8:"hookname";s:18:"menu-posts-faecher";s:8:"icon_url";s:20:"dashicons-admin-post";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:">edit.php?post_type=faecher";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:26:"edit.php?post_type=faecher";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:15:"separator_GaTwZ";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:8;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:16:">separator_GaTwZ";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_GaTwZ";s:12:"page_heading";s:0:"";s:8:"position";i:8;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_GaTwZ";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:0:"";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:10:"upload.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:9;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:11:">upload.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"upload.php>upload.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:16:"Medienübersicht";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"upload.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:10:"upload.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"upload.php>upload.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"upload.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:"upload.php>media-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:17:"Datei hinzufügen";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"media-new.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:10:"upload.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:"upload.php>media-new.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:13:"media-new.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Medien";s:12:"access_level";s:12:"upload_files";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"upload.php";s:12:"page_heading";s:0:"";s:8:"position";i:9;s:6:"parent";s:0:"";s:9:"css_class";s:24:"menu-top menu-icon-media";s:8:"hookname";s:10:"menu-media";s:8:"icon_url";s:21:"dashicons-admin-media";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:11:">upload.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"upload.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:23:"edit.php?post_type=page";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:10;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:">edit.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:2:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:47:"edit.php?post_type=page>edit.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Alle Seiten";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"edit.php?post_type=page";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:23:"edit.php?post_type=page";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:47:"edit.php?post_type=page>edit.php?post_type=page";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:23:"edit.php?post_type=page";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:51:"edit.php?post_type=page>post-new.php?post_type=page";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Erstellen";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:27:"post-new.php?post_type=page";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:23:"edit.php?post_type=page";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:51:"edit.php?post_type=page>post-new.php?post_type=page";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:27:"post-new.php?post_type=page";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Seiten";s:12:"access_level";s:10:"edit_pages";s:16:"extra_capability";s:0:"";s:4:"file";s:23:"edit.php?post_type=page";s:12:"page_heading";s:0:"";s:8:"position";i:10;s:6:"parent";s:0:"";s:9:"css_class";s:23:"menu-top menu-icon-page";s:8:"hookname";s:10:"menu-pages";s:8:"icon_url";s:20:"dashicons-admin-page";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:">edit.php?post_type=page";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:23:"edit.php?post_type=page";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:17:"edit-comments.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:11;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:18:">edit-comments.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:1:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:35:"edit-comments.php>edit-comments.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:15:"Alle Kommentare";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"edit-comments.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:17:"edit-comments.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:35:"edit-comments.php>edit-comments.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"edit-comments.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:89:"Kommentare <span class=\'awaiting-mod count-0\'><span class=\'pending-count\'>0</span></span>";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"edit-comments.php";s:12:"page_heading";s:0:"";s:8:"position";i:11;s:6:"parent";s:0:"";s:9:"css_class";s:27:"menu-top menu-icon-comments";s:8:"hookname";s:13:"menu-comments";s:8:"icon_url";s:24:"dashicons-admin-comments";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:18:">edit-comments.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"edit-comments.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:15:"separator_zfjaS";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:12;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:16:">separator_zfjaS";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:15:"separator_zfjaS";s:12:"page_heading";s:0:"";s:8:"position";i:12;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:15:"separator_zfjaS";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:0:"";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:10:"themes.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:13;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:11:">themes.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:6:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"themes.php>themes.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Themes";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"themes.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"themes.php>themes.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"themes.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:"themes.php>customize.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Anpassen";s:12:"access_level";s:9:"customize";s:16:"extra_capability";s:0:"";s:4:"file";s:110:"customize.php?return=%2Fmusikschule-wp-theme%2Fwordpress%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:20:"hide-if-no-customize";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:"themes.php>customize.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:110:"customize.php?return=%2Fmusikschule-wp-theme%2Fwordpress%2Fwp-admin%2Foptions-general.php%3Fpage%3Dmenu_editor";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:22:"themes.php>widgets.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:7:"Widgets";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"widgets.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:22:"themes.php>widgets.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"widgets.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:24:"themes.php>nav-menus.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Menüs";s:12:"access_level";s:18:"edit_theme_options";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"nav-menus.php";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:24:"themes.php>nav-menus.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:13:"nav-menus.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:20:"themes.php>admin-bar";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:9:"Admin Bar";s:10:"menu_title";s:9:"Admin Bar";s:12:"access_level";s:13:"administrator";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"admin-bar";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:20:"themes.php>admin-bar";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:25:"themes.php?page=admin-bar";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:27:"themes.php>theme-editor.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:6:"Editor";s:10:"menu_title";s:6:"Editor";s:12:"access_level";s:11:"edit_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:16:"theme-editor.php";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:10:"themes.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:27:"themes.php>theme-editor.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:16:"theme-editor.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Design";s:12:"access_level";s:13:"switch_themes";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"themes.php";s:12:"page_heading";s:0:"";s:8:"position";i:13;s:6:"parent";s:0:"";s:9:"css_class";s:29:"menu-top menu-icon-appearance";s:8:"hookname";s:15:"menu-appearance";s:8:"icon_url";s:26:"dashicons-admin-appearance";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:11:">themes.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"themes.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"plugins.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:14;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">plugins.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:3:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:23:"plugins.php>plugins.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:20:"Installierte Plugins";s:12:"access_level";s:16:"activate_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"plugins.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:23:"plugins.php>plugins.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"plugins.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:30:"plugins.php>plugin-install.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:12:"Installieren";s:12:"access_level";s:15:"install_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:18:"plugin-install.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:30:"plugins.php>plugin-install.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:18:"plugin-install.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:29:"plugins.php>plugin-editor.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Editor";s:12:"access_level";s:12:"edit_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"plugin-editor.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:11:"plugins.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:29:"plugins.php>plugin-editor.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"plugin-editor.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:87:"Plugins <span class=\'update-plugins count-3\'><span class=\'plugin-count\'>3</span></span>";s:12:"access_level";s:16:"activate_plugins";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"plugins.php";s:12:"page_heading";s:0:"";s:8:"position";i:14;s:6:"parent";s:0:"";s:9:"css_class";s:26:"menu-top menu-icon-plugins";s:8:"hookname";s:12:"menu-plugins";s:8:"icon_url";s:23:"dashicons-admin-plugins";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">plugins.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"plugins.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:9:"users.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:15;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:10:">users.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:3:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:19:"users.php>users.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:13:"Alle Benutzer";s:12:"access_level";s:10:"list_users";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"users.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:19:"users.php>users.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"users.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:22:"users.php>user-new.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:15:"Neu hinzufügen";s:12:"access_level";s:12:"create_users";s:16:"extra_capability";s:0:"";s:4:"file";s:12:"user-new.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:22:"users.php>user-new.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:12:"user-new.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:21:"users.php>profile.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:11:"Dein Profil";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"profile.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:9:"users.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:21:"users.php>profile.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:11:"profile.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:8:"Benutzer";s:12:"access_level";s:10:"list_users";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"users.php";s:12:"page_heading";s:0:"";s:8:"position";i:15;s:6:"parent";s:0:"";s:9:"css_class";s:24:"menu-top menu-icon-users";s:8:"hookname";s:10:"menu-users";s:8:"icon_url";s:21:"dashicons-admin-users";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:10:">users.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"users.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:9:"tools.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:16;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:10:">tools.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:4:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:19:"tools.php>tools.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:21:"Verfügbare Werkzeuge";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"tools.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:19:"tools.php>tools.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"tools.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:20:"tools.php>import.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:17:"Daten importieren";s:12:"access_level";s:6:"import";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"import.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:20:"tools.php>import.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"import.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:20:"tools.php>export.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:17:"Daten exportieren";s:12:"access_level";s:6:"export";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"export.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:20:"tools.php>export.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:10:"export.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:23:"tools.php>wp-migrate-db";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:10:"Migrate DB";s:10:"menu_title";s:10:"Migrate DB";s:12:"access_level";s:6:"export";s:16:"extra_capability";s:0:"";s:4:"file";s:13:"wp-migrate-db";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:9:"tools.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:23:"tools.php>wp-migrate-db";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:28:"tools.php?page=wp-migrate-db";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Werkzeuge";s:12:"access_level";s:10:"edit_posts";s:16:"extra_capability";s:0:"";s:4:"file";s:9:"tools.php";s:12:"page_heading";s:0:"";s:8:"position";i:16;s:6:"parent";s:0:"";s:9:"css_class";s:24:"menu-top menu-icon-tools";s:8:"hookname";s:10:"menu-tools";s:8:"icon_url";s:21:"dashicons-admin-tools";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:10:">tools.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:9:"tools.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:19:"options-general.php";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:17;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:20:">options-general.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:7:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:39:"options-general.php>options-general.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Allgemein";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-general.php";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:39:"options-general.php>options-general.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-general.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:39:"options-general.php>options-writing.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:9:"Schreiben";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-writing.php";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:39:"options-general.php>options-writing.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-writing.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:39:"options-general.php>options-reading.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:5:"Lesen";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-reading.php";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:39:"options-general.php>options-reading.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-reading.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:3;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:3;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:42:"options-general.php>options-discussion.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Diskussion";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:22:"options-discussion.php";s:12:"page_heading";s:0:"";s:8:"position";i:3;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:42:"options-general.php>options-discussion.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:22:"options-discussion.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:4;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:4;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:37:"options-general.php>options-media.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:6:"Medien";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:17:"options-media.php";s:12:"page_heading";s:0:"";s:8:"position";i:4;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:37:"options-general.php>options-media.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:17:"options-media.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:5;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:5;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:41:"options-general.php>options-permalink.php";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:10:"Permalinks";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:21:"options-permalink.php";s:12:"page_heading";s:0:"";s:8:"position";i:5;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:41:"options-general.php>options-permalink.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:21:"options-permalink.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:6;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:6;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:31:"options-general.php>menu_editor";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:11:"Menu Editor";s:10:"menu_title";s:11:"Menu Editor";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"menu_editor";s:12:"page_heading";s:0:"";s:8:"position";i:6;s:6:"parent";s:19:"options-general.php";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:31:"options-general.php>menu_editor";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:36:"options-general.php?page=menu_editor";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:13:"Einstellungen";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:19:"options-general.php";s:12:"page_heading";s:0:"";s:8:"position";i:17;s:6:"parent";s:0:"";s:9:"css_class";s:27:"menu-top menu-icon-settings";s:8:"hookname";s:13:"menu-settings";s:8:"icon_url";s:24:"dashicons-admin-settings";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:20:">options-general.php";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:19:"options-general.php";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:22:"edit.php?post_type=acf";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:18;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:23:">edit.php?post_type=acf";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:3:{i:0;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:0;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:45:"edit.php?post_type=acf>edit.php?post_type=acf";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:13:"Eigene Felder";s:10:"menu_title";s:13:"Eigene Felder";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:22:"edit.php?post_type=acf";s:12:"page_heading";s:0:"";s:8:"position";i:0;s:6:"parent";s:22:"edit.php?post_type=acf";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:45:"edit.php?post_type=acf>edit.php?post_type=acf";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:22:"edit.php?post_type=acf";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:1;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:1;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:33:"edit.php?post_type=acf>acf-export";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:6:"Export";s:10:"menu_title";s:6:"Export";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"acf-export";s:12:"page_heading";s:0:"";s:8:"position";i:1;s:6:"parent";s:22:"edit.php?post_type=acf";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:33:"edit.php?post_type=acf>acf-export";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:38:"edit.php?post_type=acf&page=acf-export";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}i:2;a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:2;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:0;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:33:"edit.php?post_type=acf>acf-addons";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:13:"Zusatz-Module";s:10:"menu_title";s:13:"Zusatz-Module";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:10:"acf-addons";s:12:"page_heading";s:0:"";s:8:"position";i:2;s:6:"parent";s:22:"edit.php?post_type=acf";s:9:"css_class";s:0:"";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:33:"edit.php?post_type=acf>acf-addons";s:14:"is_plugin_page";b:1;s:6:"custom";b:0;s:3:"url";s:38:"edit.php?post_type=acf&page=acf-addons";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:13:"Eigene Felder";s:10:"menu_title";s:13:"Eigene Felder";s:12:"access_level";s:14:"manage_options";s:16:"extra_capability";s:0:"";s:4:"file";s:22:"edit.php?post_type=acf";s:12:"page_heading";s:0:"";s:8:"position";i:18;s:6:"parent";s:0:"";s:9:"css_class";s:59:"menu-top menu-icon-generic toplevel_page_edit?post_type=acf";s:8:"hookname";s:32:"toplevel_page_edit?post_type=acf";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:0;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:23:">edit.php?post_type=acf";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:22:"edit.php?post_type=acf";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}s:11:"separator_5";a:31:{s:10:"page_title";N;s:10:"menu_title";N;s:12:"access_level";N;s:16:"extra_capability";N;s:4:"file";N;s:12:"page_heading";N;s:8:"position";i:19;s:6:"parent";N;s:9:"css_class";N;s:8:"hookname";N;s:8:"icon_url";N;s:9:"separator";b:1;s:6:"colors";N;s:14:"is_always_open";N;s:7:"open_in";N;s:13:"iframe_height";N;s:11:"template_id";s:12:">separator_5";s:14:"is_plugin_page";N;s:6:"custom";b:0;s:3:"url";N;s:16:"embedded_page_id";N;s:21:"embedded_page_blog_id";N;s:5:"items";a:0:{}s:12:"grant_access";a:0:{}s:7:"missing";b:0;s:6:"unused";b:0;s:6:"hidden";b:0;s:17:"hidden_from_actor";a:0:{}s:24:"restrict_access_to_items";b:0;s:24:"had_access_before_hiding";N;s:8:"defaults";a:22:{s:10:"page_title";s:0:"";s:10:"menu_title";s:0:"";s:12:"access_level";s:4:"read";s:16:"extra_capability";s:0:"";s:4:"file";s:11:"separator_5";s:12:"page_heading";s:0:"";s:8:"position";i:19;s:6:"parent";s:0:"";s:9:"css_class";s:17:"wp-menu-separator";s:8:"hookname";s:0:"";s:8:"icon_url";s:23:"dashicons-admin-generic";s:9:"separator";b:1;s:6:"colors";b:0;s:14:"is_always_open";b:0;s:7:"open_in";s:11:"same_window";s:13:"iframe_height";i:0;s:11:"template_id";s:12:">separator_5";s:14:"is_plugin_page";b:0;s:6:"custom";b:0;s:3:"url";s:0:"";s:16:"embedded_page_id";i:0;s:21:"embedded_page_blog_id";i:1;}}}s:6:"format";a:3:{s:4:"name";s:22:"Admin Menu Editor menu";s:7:"version";s:3:"6.3";s:13:"is_normalized";b:1;}s:13:"color_presets";a:0:{}}s:18:"first_install_time";i:1449587123;s:21:"display_survey_notice";b:1;s:17:"plugin_db_version";i:140;s:24:"security_logging_enabled";b:0;s:17:"menu_config_scope";s:6:"global";s:13:"plugin_access";s:14:"manage_options";s:15:"allowed_user_id";N;s:28:"plugins_page_allowed_user_id";N;s:27:"show_deprecated_hide_button";b:1;s:37:"dashboard_hiding_confirmation_enabled";b:1;s:21:"submenu_icons_enabled";s:9:"if_custom";s:16:"ui_colour_scheme";s:10:"modern-one";s:13:"visible_users";a:0:{}s:23:"show_plugin_menu_notice";b:0;s:20:"unused_item_position";s:8:"relative";}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(573, 'widget_tribe-events-list-widget', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(5703, 'fs_contact_global', 'a:11:{s:12:"fscf_version";s:6:"4.0.39";s:7:"donated";s:5:"false";s:18:"vcita_auto_install";s:5:"false";s:13:"vcita_dismiss";s:5:"false";s:17:"vcita_initialized";s:5:"false";s:22:"vcita_show_disable_msg";s:5:"false";s:10:"vcita_site";s:13:"www.vcita.com";s:19:"enable_php_sessions";s:5:"false";s:19:"num_standard_fields";s:1:"4";s:12:"max_form_num";s:1:"2";s:9:"form_list";a:2:{i:1;s:8:"New Form";i:2;s:6:"Form 2";}}', 'yes'),
(5705, 'wpgmza_xml_location', '{uploads_dir}/wp-google-maps/', 'yes'),
(5706, 'wpgmza_xml_url', '{uploads_url}/wp-google-maps/', 'yes'),
(5707, 'wpgmza_db_version', '6.3.04', 'yes'),
(5708, 'wpgmaps_current_version', '6.3.04', 'yes'),
(5709, 'WPGMZA_OTHER_SETTINGS', 'a:1:{s:27:"wpgmza_settings_marker_pull";s:1:"0";}', 'yes'),
(5711, 'fs_contact_form1', 'a:165:{s:9:"form_name";s:8:"New Form";s:7:"welcome";s:61:"<p>Ihre Fragen und Anmerkungen sind jederzeit willkommen.</p>";s:8:"email_to";s:35:"Webmaster,brian.joe.stark@gmail.com";s:9:"email_bcc";s:0:"";s:13:"email_subject";s:34:"Jugendorchester Havixbeck Kontakt:";s:10:"email_from";s:0:"";s:14:"email_reply_to";s:0:"";s:6:"fields";a:5:{i:4;a:21:{s:8:"standard";s:1:"0";s:6:"delete";s:5:"false";s:5:"label";s:8:"Vorname:";s:4:"type";s:4:"text";s:4:"slug";s:7:"Vorname";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:3:"req";s:5:"false";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:0;a:21:{s:8:"standard";s:1:"1";s:6:"delete";s:5:"false";s:5:"label";s:5:"Name:";s:4:"type";s:4:"text";s:4:"slug";s:9:"full_name";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:1;a:21:{s:8:"standard";s:1:"2";s:6:"delete";s:5:"false";s:5:"label";s:6:"Email:";s:4:"type";s:4:"text";s:4:"slug";s:5:"email";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:2;a:21:{s:8:"standard";s:1:"3";s:6:"delete";s:5:"false";s:5:"label";s:8:"Betreff:";s:4:"type";s:4:"text";s:4:"slug";s:7:"subject";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:3;a:21:{s:8:"standard";s:1:"4";s:6:"delete";s:5:"false";s:5:"label";s:10:"Nachricht:";s:4:"type";s:8:"textarea";s:4:"slug";s:7:"message";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}}s:11:"name_format";s:4:"name";s:16:"auto_fill_enable";s:4:"true";s:11:"date_format";s:10:"dd/mm/yyyy";s:13:"cal_start_day";s:1:"0";s:11:"time_format";s:2:"24";s:12:"attach_types";s:33:"doc,docx,pdf,txt,gif,jpg,jpeg,png";s:11:"attach_size";s:3:"1mb";s:12:"title_border";s:12:"Contact Form";s:14:"external_style";s:5:"false";s:10:"form_style";s:27:"width:99%; max-width:555px;";s:14:"left_box_style";s:39:"float:left; width:55%; max-width:270px;";s:15:"right_box_style";s:24:"float:left; width:235px;";s:11:"clear_style";s:11:"clear:both;";s:16:"field_left_style";s:70:"clear:left; float:left; width:99%; max-width:550px; margin-right:10px;";s:18:"field_follow_style";s:58:"float:left; padding-left:10px; width:99%; max-width:250px;";s:21:"field_prefollow_style";s:70:"clear:left; float:left; width:99%; max-width:250px; margin-right:10px;";s:11:"title_style";s:33:"text-align:left; padding-top:5px;";s:15:"field_div_style";s:16:"text-align:left;";s:20:"captcha_div_style_sm";s:42:"width:175px; height:50px; padding-top:2px;";s:19:"captcha_div_style_m";s:42:"width:250px; height:65px; padding-top:2px;";s:19:"captcha_image_style";s:72:"border-style:none; margin:0; padding:0px; padding-right:5px; float:left;";s:26:"captcha_reload_image_style";s:64:"border-style:none; margin:0; padding:0px; vertical-align:bottom;";s:16:"submit_div_style";s:46:"text-align:left; clear:both; padding-top:15px;";s:12:"border_style";s:65:"border:1px solid black; width:99%; max-width:550px; padding:10px;";s:14:"required_style";s:16:"text-align:left;";s:19:"required_text_style";s:16:"text-align:left;";s:10:"hint_style";s:38:"font-size:x-small; font-weight:normal;";s:11:"error_style";s:27:"text-align:left; color:red;";s:14:"redirect_style";s:16:"text-align:left;";s:14:"fieldset_style";s:65:"border:1px solid black; width:97%; max-width:500px; padding:10px;";s:11:"label_style";s:16:"text-align:left;";s:18:"option_label_style";s:15:"display:inline;";s:11:"field_style";s:54:"text-align:left; margin:0; width:99%; max-width:250px;";s:19:"captcha_input_style";s:38:"text-align:left; margin:0; width:50px;";s:14:"textarea_style";s:68:"text-align:left; margin:0; width:99%; max-width:250px; height:120px;";s:12:"select_style";s:16:"text-align:left;";s:14:"checkbox_style";s:24:"width:22px; height:32px;";s:11:"radio_style";s:24:"width:22px; height:32px;";s:17:"placeholder_style";s:27:"opacity:0.6; color:#333333;";s:12:"button_style";s:25:"cursor:pointer; margin:0;";s:11:"reset_style";s:25:"cursor:pointer; margin:0;";s:18:"vcita_button_style";s:156:"text-decoration:none; display:block; text-align:center; background:linear-gradient(to bottom, #ed6a31 0%, #e55627 100%); color:#fff !important; padding:8px;";s:22:"vcita_div_button_style";s:63:"border-left:1px dashed #ccc; margin-top:25px; padding:8px 20px;";s:16:"powered_by_style";s:74:"font-size:x-small; font-weight:normal; padding-top:5px; text-align:center;";s:22:"req_field_label_enable";s:4:"true";s:16:"tooltip_required";s:0:"";s:26:"req_field_indicator_enable";s:4:"true";s:19:"req_field_indicator";s:1:"*";s:10:"title_dept";s:0:"";s:12:"title_select";s:0:"";s:10:"title_name";s:0:"";s:11:"title_fname";s:0:"";s:11:"title_lname";s:0:"";s:11:"title_mname";s:0:"";s:12:"title_miname";s:0:"";s:11:"title_email";s:0:"";s:12:"title_email2";s:0:"";s:10:"title_subj";s:0:"";s:10:"title_mess";s:0:"";s:10:"title_capt";s:0:"";s:12:"title_submit";s:0:"";s:16:"title_submitting";s:0:"";s:11:"title_reset";s:0:"";s:16:"title_areyousure";s:0:"";s:17:"text_message_sent";s:0:"";s:17:"text_print_button";s:0:"";s:15:"tooltip_captcha";s:0:"";s:15:"tooltip_refresh";s:0:"";s:17:"tooltip_filetypes";s:0:"";s:16:"tooltip_filesize";s:0:"";s:13:"error_correct";s:0:"";s:20:"error_contact_select";s:0:"";s:13:"error_subject";s:0:"";s:10:"error_name";s:0:"";s:11:"error_field";s:0:"";s:12:"error_select";s:0:"";s:11:"error_email";s:0:"";s:17:"error_email_check";s:0:"";s:12:"error_email2";s:0:"";s:9:"error_url";s:0:"";s:10:"error_date";s:0:"";s:10:"error_time";s:0:"";s:12:"error_maxlen";s:0:"";s:19:"error_captcha_blank";s:0:"";s:19:"error_captcha_wrong";s:0:"";s:13:"error_spambot";s:0:"";s:11:"error_input";s:0:"";s:14:"captcha_enable";s:4:"true";s:18:"captcha_perm_level";s:4:"read";s:19:"akismet_send_anyway";s:4:"true";s:14:"domain_protect";s:4:"true";s:20:"domain_protect_names";s:0:"";s:22:"auto_respond_from_name";s:25:"Jugendorchester Havixbeck";s:23:"auto_respond_from_email";s:25:"brian.joe.stark@gmail.com";s:21:"auto_respond_reply_to";s:25:"brian.joe.stark@gmail.com";s:20:"auto_respond_subject";s:0:"";s:20:"auto_respond_message";s:0:"";s:15:"redirect_enable";s:4:"true";s:16:"redirect_seconds";i:3;s:12:"redirect_url";s:47:"http://localhost/musikschule-wp-theme/wordpress";s:15:"redirect_ignore";s:0:"";s:15:"redirect_rename";s:0:"";s:12:"redirect_add";s:0:"";s:17:"submit_attributes";s:0:"";s:15:"form_attributes";s:0:"";s:13:"anchor_enable";s:4:"true";s:22:"enable_submit_oneclick";s:4:"true";s:15:"after_form_note";s:0:"";s:17:"success_page_html";s:0:"";s:17:"php_mailer_enable";s:9:"wordpress";s:18:"sender_info_enable";s:4:"true";s:11:"silent_send";s:3:"off";s:10:"silent_url";s:0:"";s:13:"silent_ignore";s:0:"";s:13:"silent_rename";s:0:"";s:10:"silent_add";s:0:"";s:24:"silent_conditional_field";s:0:"";s:24:"silent_conditional_value";s:0:"";s:13:"export_ignore";s:0:"";s:13:"export_rename";s:0:"";s:10:"export_add";s:0:"";s:14:"vcita_approved";s:5:"false";s:9:"vcita_uid";s:0:"";s:11:"vcita_email";s:0:"";s:15:"vcita_email_new";s:25:"brian.joe.stark@gmail.com";s:16:"vcita_first_name";s:0:"";s:15:"vcita_last_name";s:0:"";s:29:"vcita_scheduling_button_label";s:23:"Schedule an Appointment";s:19:"email_from_enforced";s:5:"false";s:21:"preserve_space_enable";s:5:"false";s:12:"double_email";s:5:"false";s:16:"name_case_enable";s:5:"false";s:15:"email_check_dns";s:5:"false";s:16:"email_check_easy";s:5:"false";s:10:"email_html";s:5:"false";s:15:"akismet_disable";s:5:"false";s:13:"captcha_small";s:5:"false";s:16:"email_hide_empty";s:5:"false";s:22:"email_keep_attachments";s:5:"false";s:17:"print_form_enable";s:5:"false";s:12:"captcha_perm";s:5:"false";s:15:"honeypot_enable";s:5:"false";s:14:"redirect_query";s:5:"false";s:18:"redirect_email_off";s:5:"false";s:16:"silent_email_off";s:5:"false";s:16:"export_email_off";s:5:"false";s:19:"ex_fields_after_msg";s:5:"false";s:18:"email_inline_label";s:5:"false";s:19:"textarea_html_allow";s:5:"false";s:17:"enable_areyousure";s:5:"false";s:19:"auto_respond_enable";s:5:"false";s:17:"auto_respond_html";s:5:"false";s:13:"border_enable";s:5:"false";s:13:"aria_required";s:5:"false";s:12:"enable_reset";s:5:"false";s:18:"enable_credit_link";s:5:"false";s:23:"vcita_scheduling_button";s:5:"false";}', 'yes'),
(5724, 'WPGMZA_FIRST_TIME', '6.3.04', 'yes'),
(5725, 'wpgmza_stats', 'a:2:{s:15:"list_maps_basic";a:3:{s:5:"views";i:3;s:13:"last_accessed";s:19:"2016-01-07 08:30:25";s:14:"first_accessed";s:19:"2016-01-06 17:37:40";}s:9:"dashboard";a:3:{s:5:"views";i:5;s:13:"last_accessed";s:19:"2016-01-07 08:30:28";s:14:"first_accessed";s:19:"2016-01-06 17:37:44";}}', 'yes'),
(5726, 'WPGMZA_SETTINGS', 'a:10:{s:24:"map_default_starting_lat";s:17:"51.97555209999999";s:24:"map_default_starting_lng";s:17:"7.413628199999948";s:18:"map_default_height";s:3:"400";s:17:"map_default_width";s:3:"100";s:16:"map_default_zoom";i:15;s:20:"map_default_max_zoom";i:1;s:16:"map_default_type";i:1;s:21:"map_default_alignment";i:1;s:22:"map_default_width_type";s:2:"\\%";s:23:"map_default_height_type";s:2:"px";}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1697 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(3, 4, '_edit_last', '1'),
(4, 4, '_edit_lock', '1450204677:1'),
(5, 1, '_edit_lock', '1448537876:1'),
(6, 15, '_edit_last', '1'),
(7, 15, '_edit_lock', '1447325928:1'),
(8, 17, '_edit_last', '1'),
(9, 17, '_edit_lock', '1447432145:1'),
(10, 19, '_edit_last', '1'),
(11, 19, '_edit_lock', '1450203866:1'),
(12, 21, '_edit_last', '1'),
(13, 21, '_edit_lock', '1447088780:1'),
(14, 23, '_edit_last', '1'),
(15, 23, '_edit_lock', '1449847237:1'),
(16, 25, '_edit_last', '1'),
(17, 25, '_edit_lock', '1452155694:1'),
(20, 4, '_wp_page_template', 'template-home.php'),
(21, 28, '_edit_last', '1'),
(22, 28, '_edit_lock', '1447092793:1'),
(25, 30, '_wp_attached_file', '2015/11/post_thumbnail1.jpg'),
(26, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:647;s:6:"height";i:432;s:4:"file";s:27:"2015/11/post_thumbnail1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"post_thumbnail1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"post_thumbnail1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:1;}}'),
(27, 28, '_thumbnail_id', '30'),
(28, 32, '_wp_attached_file', '2015/11/Musikschule-Klick.jpg'),
(29, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1735;s:4:"file";s:29:"2015/11/Musikschule-Klick.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"Musikschule-Klick-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"Musikschule-Klick-300x271.jpg";s:5:"width";i:300;s:6:"height";i:271;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"Musikschule-Klick-1024x925.jpg";s:5:"width";i:1024;s:6:"height";i:925;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(101, 44, '_edit_last', '1'),
(102, 44, '_edit_lock', '1447320498:1'),
(103, 44, '_wp_page_template', 'default'),
(112, 17, '_thumbnail_id', '30'),
(113, 17, '_wp_page_template', 'template-site.php'),
(114, 50, '_edit_last', '1'),
(115, 50, '_edit_lock', '1449850705:1'),
(116, 50, '_wp_page_template', 'template-anmeldung.php'),
(125, 1, '_thumbnail_id', '30'),
(126, 1, '_edit_last', '1'),
(131, 60, '_edit_last', '1'),
(133, 60, 'field_5656f0adab496', 'a:14:{s:3:"key";s:19:"field_5656f0adab496";s:5:"label";s:12:"Geburtsdatum";s:4:"name";s:21:"dozenten_geburtsdatum";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(134, 60, 'field_5656f0dfab497', 'a:11:{s:3:"key";s:19:"field_5656f0dfab497";s:5:"label";s:4:"Bild";s:4:"name";s:13:"dozenten_bild";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(135, 60, 'field_5656f0feab498', 'a:12:{s:3:"key";s:19:"field_5656f0feab498";s:5:"label";s:5:"Email";s:4:"name";s:14:"dozenten_email";s:4:"type";s:5:"email";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(138, 60, 'position', 'normal'),
(139, 60, 'layout', 'no_box'),
(140, 60, 'hide_on_screen', 'a:5:{i:0;s:8:"comments";i:1;s:9:"revisions";i:2;s:4:"slug";i:3;s:6:"author";i:4;s:15:"send-trackbacks";}'),
(141, 60, '_edit_lock', '1450109433:1'),
(142, 61, '_edit_last', '1'),
(144, 61, 'field_5656f1c469a43', 'a:11:{s:3:"key";s:19:"field_5656f1c469a43";s:5:"label";s:4:"Bild";s:4:"name";s:15:"instrument_bild";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(146, 61, 'field_5656f1da69a45', 'a:13:{s:3:"key";s:19:"field_5656f1da69a45";s:5:"label";s:20:"Unterrichtseinheiten";s:4:"name";s:31:"instrument_unterrichtseinheiten";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:44:"Einzelunterricht 30 min\r\nFörderstufe 45 min";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:1:"2";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'),
(147, 61, 'field_5656f21669a46', 'a:13:{s:3:"key";s:19:"field_5656f21669a46";s:5:"label";s:23:"Unterrichtsschwerpunkte";s:4:"name";s:34:"instrument_unterrichtsschwerpunkte";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:1:"3";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(149, 61, 'position', 'normal'),
(150, 61, 'layout', 'no_box'),
(151, 61, 'hide_on_screen', 'a:5:{i:0;s:8:"comments";i:1;s:9:"revisions";i:2;s:4:"slug";i:3;s:4:"tags";i:4;s:15:"send-trackbacks";}'),
(152, 61, '_edit_lock', '1450191689:1'),
(153, 61, 'field_5656f2422905e', 'a:11:{s:3:"key";s:19:"field_5656f2422905e";s:5:"label";s:5:"Links";s:4:"name";s:16:"instrument_links";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:7;}'),
(154, 61, 'field_5656f25c2905f', 'a:14:{s:3:"key";s:19:"field_5656f25c2905f";s:5:"label";s:8:"Dozenten";s:4:"name";s:22:"instrument_by_dozenten";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"return_format";s:2:"id";s:9:"post_type";a:1:{i:0;s:8:"dozenten";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:6;}'),
(158, 63, '_edit_last', '1'),
(159, 63, '_edit_lock', '1449563537:1'),
(160, 63, '_wp_page_template', 'template-site.php'),
(161, 65, '_EventOrigin', 'events-calendar'),
(162, 65, '_edit_last', '1'),
(163, 65, '_edit_lock', '1449564042:1'),
(164, 65, '_EventShowMapLink', ''),
(165, 65, '_EventShowMap', ''),
(166, 66, '_OrganizerOrigin', 'events-calendar'),
(167, 66, '_OrganizerOrganizer', ''),
(168, 66, '_OrganizerPhone', ''),
(169, 66, '_OrganizerWebsite', ''),
(170, 66, '_OrganizerEmail', 'jo_megabrain@yahoo.de'),
(171, 67, '_VenueOrigin', 'events-calendar'),
(172, 67, '_EventShowMapLink', ''),
(173, 67, '_EventShowMap', ''),
(174, 67, '_VenueVenue', 'JUH'),
(175, 67, '_VenueAddress', 'Auf der Straße'),
(176, 67, '_VenueCity', 'Havixbeck'),
(177, 67, '_VenueCountry', 'Deutschland'),
(178, 67, '_VenueProvince', 'NRW'),
(179, 67, '_VenueState', ''),
(180, 67, '_VenueZip', ''),
(181, 67, '_VenuePhone', ''),
(182, 67, '_VenueURL', ''),
(183, 67, '_VenueShowMap', 'true'),
(184, 67, '_VenueShowMapLink', 'true'),
(185, 67, '_VenueStateProvince', 'NRW'),
(186, 65, '_EventStartDate', '2015-12-08 08:00:00'),
(187, 65, '_EventEndDate', '2015-12-08 17:00:00'),
(188, 65, '_EventStartDateUTC', '2015-12-08 07:00:00'),
(189, 65, '_EventEndDateUTC', '2015-12-08 16:00:00'),
(190, 65, '_EventDuration', '32400'),
(191, 65, '_EventVenueID', '67'),
(192, 65, '_EventCurrencySymbol', ''),
(193, 65, '_EventCurrencyPosition', 'prefix'),
(194, 65, '_EventCost', ''),
(195, 65, '_EventURL', ''),
(196, 65, '_EventOrganizerID', '66'),
(197, 65, '_EventTimezone', 'Europe/Berlin'),
(198, 65, '_EventTimezoneAbbr', 'CET'),
(199, 68, '_EventOrigin', 'events-calendar'),
(200, 68, '_edit_last', '1'),
(201, 68, '_edit_lock', '1449578367:1'),
(202, 68, '_EventShowMapLink', ''),
(203, 68, '_EventShowMap', ''),
(204, 68, '_EventStartDate', '2015-12-08 08:00:00'),
(205, 68, '_EventEndDate', '2015-12-08 17:00:00'),
(206, 68, '_EventStartDateUTC', '2015-12-08 07:00:00') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(207, 68, '_EventEndDateUTC', '2015-12-08 16:00:00'),
(208, 68, '_EventDuration', '32400'),
(209, 68, '_EventVenueID', '67'),
(210, 68, '_EventCurrencySymbol', ''),
(211, 68, '_EventCurrencyPosition', 'prefix'),
(212, 68, '_EventCost', ''),
(213, 68, '_EventURL', ''),
(214, 68, '_EventOrganizerID', '66'),
(215, 68, '_EventTimezone', 'Europe/Berlin'),
(216, 68, '_EventTimezoneAbbr', 'CET'),
(217, 69, '_menu_item_type', 'custom'),
(218, 69, '_menu_item_menu_item_parent', '161'),
(219, 69, '_menu_item_object_id', '69'),
(220, 69, '_menu_item_object', 'custom'),
(221, 69, '_menu_item_target', ''),
(222, 69, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(223, 69, '_menu_item_xfn', ''),
(224, 69, '_menu_item_url', 'http://localhost/musikschule-wp-theme/wordpress/termine/'),
(226, 70, '_edit_last', '1'),
(227, 70, '_edit_lock', '1449850427:1'),
(228, 70, '_wp_page_template', 'template-anmeldung.php'),
(229, 72, '_edit_last', '1'),
(230, 72, '_edit_lock', '1450105138:1'),
(231, 72, '_wp_page_template', 'template-angebot.php'),
(232, 74, '_edit_last', '1'),
(233, 74, '_edit_lock', '1449591347:1'),
(234, 74, '_wp_page_template', 'template-4thlevel.php'),
(262, 93, '_edit_last', '1'),
(263, 93, '_edit_lock', '1450025014:1'),
(266, 93, 'name', 'Ralf Bachmann'),
(267, 93, '_name', 'field_5656f076ab495'),
(268, 93, 'geburtsdatum', ''),
(269, 93, '_geburtsdatum', 'field_5656f0adab496'),
(270, 93, 'bild', '94'),
(271, 93, '_bild', 'field_5656f0dfab497'),
(272, 93, 'email', ''),
(273, 93, '_email', 'field_5656f0feab498'),
(274, 93, 'beschreibung', ''),
(275, 93, '_beschreibung', 'field_5656f10aab499'),
(276, 95, '_edit_last', '1'),
(277, 95, '_edit_lock', '1449855328:1'),
(278, 95, '_wp_page_template', 'template-dozenten.php'),
(279, 60, 'field_56670063e61c4', 'a:14:{s:3:"key";s:19:"field_56670063e61c4";s:5:"label";s:10:"Instrument";s:4:"name";s:24:"dozent_spielt_instrument";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"return_format";s:6:"object";s:9:"post_type";a:2:{i:0;s:11:"instrumente";i:1;s:7:"faecher";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'),
(281, 97, '_edit_last', '1'),
(282, 97, '_edit_lock', '1450193648:1'),
(283, 98, '_wp_attached_file', '2015/12/trompete.jpg'),
(284, 98, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1483;s:6:"height";i:600;s:4:"file";s:20:"2015/12/trompete.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"trompete-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"trompete-300x121.jpg";s:5:"width";i:300;s:6:"height";i:121;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"trompete-1024x414.jpg";s:5:"width";i:1024;s:6:"height";i:414;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(285, 97, 'bild', '98'),
(286, 97, '_bild', 'field_5656f1c469a43'),
(287, 97, 'beschreibung', 'create_post_typecreate_post_typecreate_post_typecreate_post_typecreate_post_type'),
(288, 97, '_beschreibung', 'field_5656f1d169a44'),
(289, 97, 'unterrichtseinheiten', 'Gut schlecht scheiße'),
(290, 97, '_unterrichtseinheiten', 'field_5656f1da69a45'),
(291, 97, 'unterrichtsschwerpunkte', ''),
(292, 97, '_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(293, 97, 'links', '1'),
(294, 97, '_links', 'field_5656f2422905e'),
(295, 97, 'dozenten', 'a:1:{i:0;s:2:"93";}'),
(296, 97, '_dozenten', 'field_5656f25c2905f'),
(298, 93, 'instrument', 'a:1:{i:0;s:2:"97";}'),
(299, 93, '_instrument', 'field_56670063e61c4'),
(301, 74, '_wp_trash_meta_status', 'publish'),
(302, 74, '_wp_trash_meta_time', '1449591496'),
(322, 97, 'instrument_bild', '98'),
(323, 97, '_instrument_bild', 'field_5656f1c469a43'),
(324, 97, 'instrument_beschreibung', 'Läuft!'),
(325, 97, '_instrument_beschreibung', 'field_5656f1d169a44'),
(328, 97, 'instrument_by_dozenten', 'a:1:{i:0;s:2:"93";}'),
(329, 97, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(334, 61, 'field_566951a61f99f', 'a:14:{s:3:"key";s:19:"field_566951a61f99f";s:5:"label";s:19:"Ergänzende Fächer";s:4:"name";s:29:"instrument_ergaenzende_facher";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"return_format";s:6:"object";s:9:"post_type";a:1:{i:0;s:7:"faecher";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'),
(335, 61, 'field_566952391f9a0', 'a:13:{s:3:"key";s:19:"field_566952391f9a0";s:5:"label";s:16:"Unterrichtssform";s:4:"name";s:26:"instrument_unterrichtsform";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:93:"Einzelunterricht,\r\nEnsemblespiel,\r\nSpiel mit Klavierbegleitung,\r\nMitwirken im Jugendorchester";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:1:"2";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(340, 60, 'field_566953f721491', 'a:11:{s:3:"key";s:19:"field_566953f721491";s:5:"label";s:5:"Links";s:4:"name";s:14:"dozenten_links";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'),
(343, 93, 'dozenten_bild', '239'),
(344, 93, '_dozenten_bild', 'field_5656f0dfab497'),
(345, 93, 'dozenten_geburtsdatum', '1976, Obergünzburg im Allgäu'),
(346, 93, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(347, 93, 'dozenten_email', ''),
(348, 93, '_dozenten_email', 'field_5656f0feab498'),
(349, 93, 'dozent_spielt_instrument', 'a:1:{i:0;s:3:"227";}'),
(350, 93, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(351, 93, 'dozenten_links', ''),
(352, 93, '_dozenten_links', 'field_566953f721491'),
(353, 97, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Ansatz, Grifftechnik), \r\nSpielliteratur von Barock bis zum 21. Jahrhundert, \r\nAtemführung und Musikalische Gestaltung. \r\nDie Musikschule Havixbeck bietet auch die Möglichkeit das verwandte Instrument Flügelhorn zu lernen.'),
(354, 97, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(355, 97, 'instrument_unterrichtsform', 'Einzelunterricht, \r\nEnsemblespiel, \r\nSpiel mit Klavierbegleitung, \r\nMitwirken im Jugendorchester'),
(356, 97, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(357, 97, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min \r\nFörderstufe 45 min'),
(358, 97, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(359, 97, 'instrument_ergaenzende_facher', ''),
(360, 97, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(361, 97, 'instrument_links', ''),
(362, 97, '_instrument_links', 'field_5656f2422905e'),
(369, 106, '_edit_last', '1'),
(370, 106, '_edit_lock', '1449846782:1'),
(371, 106, '_wp_page_template', 'template-site.php'),
(372, 108, '_edit_last', '1'),
(373, 108, '_edit_lock', '1449846799:1'),
(374, 108, '_wp_page_template', 'template-site.php'),
(375, 110, '_edit_last', '1'),
(376, 110, '_edit_lock', '1449846823:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(377, 110, '_wp_page_template', 'template-site.php'),
(378, 112, '_edit_last', '1'),
(379, 112, '_edit_lock', '1449846856:1'),
(380, 112, '_wp_page_template', 'template-site.php'),
(381, 114, '_edit_last', '1'),
(382, 114, '_edit_lock', '1449846880:1'),
(383, 114, '_wp_page_template', 'template-site.php'),
(384, 116, '_edit_last', '1'),
(385, 116, '_edit_lock', '1449846899:1'),
(386, 116, '_wp_page_template', 'template-site.php'),
(387, 118, '_edit_last', '1'),
(388, 118, '_edit_lock', '1449846914:1'),
(389, 118, '_wp_page_template', 'template-site.php'),
(390, 120, '_edit_last', '1'),
(391, 120, '_wp_page_template', 'template-angebot.php'),
(392, 120, '_edit_lock', '1449856106:1'),
(393, 122, '_edit_last', '1'),
(394, 122, '_edit_lock', '1449856316:1'),
(395, 122, '_wp_page_template', 'template-angebot.php'),
(396, 124, '_edit_last', '1'),
(397, 124, '_edit_lock', '1449850854:1'),
(398, 124, '_wp_page_template', 'template-angebot.php'),
(399, 126, '_edit_last', '1'),
(400, 126, '_edit_lock', '1450193510:1'),
(401, 126, '_wp_page_template', 'template-angebot.php'),
(402, 128, '_edit_last', '1'),
(403, 128, '_edit_lock', '1449850855:1'),
(404, 128, '_wp_page_template', 'template-angebot.php'),
(405, 130, '_edit_last', '1'),
(406, 130, '_edit_lock', '1450108350:1'),
(407, 130, '_wp_page_template', 'template-angebot.php'),
(408, 132, '_edit_last', '1'),
(409, 132, '_edit_lock', '1450033763:1'),
(410, 132, '_wp_page_template', 'template-angebot.php'),
(411, 134, '_edit_last', '1'),
(412, 134, '_edit_lock', '1449855347:1'),
(413, 134, '_wp_page_template', 'template-angebot.php'),
(414, 136, '_edit_last', '1'),
(415, 136, '_edit_lock', '1449850856:1'),
(416, 136, '_wp_page_template', 'template-angebot.php'),
(417, 138, '_edit_last', '1'),
(418, 138, '_edit_lock', '1449850705:1'),
(419, 138, '_wp_page_template', 'template-anmeldung.php'),
(420, 140, '_edit_last', '1'),
(421, 140, '_edit_lock', '1449850704:1'),
(422, 140, '_wp_page_template', 'template-anmeldung.php'),
(423, 142, '_edit_last', '1'),
(424, 142, '_edit_lock', '1449850704:1'),
(425, 142, '_wp_page_template', 'template-anmeldung.php'),
(426, 23, '_wp_trash_meta_status', 'publish'),
(427, 23, '_wp_trash_meta_time', '1449847386'),
(428, 144, '_menu_item_type', 'post_type'),
(429, 144, '_menu_item_menu_item_parent', '0'),
(430, 144, '_menu_item_object_id', '142'),
(431, 144, '_menu_item_object', 'page'),
(432, 144, '_menu_item_target', ''),
(433, 144, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(434, 144, '_menu_item_xfn', ''),
(435, 144, '_menu_item_url', ''),
(436, 144, '_menu_item_orphaned', '1449847510'),
(437, 145, '_menu_item_type', 'post_type'),
(438, 145, '_menu_item_menu_item_parent', '0'),
(439, 145, '_menu_item_object_id', '140'),
(440, 145, '_menu_item_object', 'page'),
(441, 145, '_menu_item_target', ''),
(442, 145, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(443, 145, '_menu_item_xfn', ''),
(444, 145, '_menu_item_url', ''),
(445, 145, '_menu_item_orphaned', '1449847510'),
(446, 146, '_menu_item_type', 'post_type'),
(447, 146, '_menu_item_menu_item_parent', '0'),
(448, 146, '_menu_item_object_id', '138'),
(449, 146, '_menu_item_object', 'page'),
(450, 146, '_menu_item_target', ''),
(451, 146, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(452, 146, '_menu_item_xfn', ''),
(453, 146, '_menu_item_url', ''),
(454, 146, '_menu_item_orphaned', '1449847510'),
(455, 147, '_menu_item_type', 'post_type'),
(456, 147, '_menu_item_menu_item_parent', '0'),
(457, 147, '_menu_item_object_id', '136'),
(458, 147, '_menu_item_object', 'page'),
(459, 147, '_menu_item_target', ''),
(460, 147, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(461, 147, '_menu_item_xfn', ''),
(462, 147, '_menu_item_url', ''),
(463, 147, '_menu_item_orphaned', '1449847510'),
(464, 148, '_menu_item_type', 'post_type'),
(465, 148, '_menu_item_menu_item_parent', '0'),
(466, 148, '_menu_item_object_id', '134'),
(467, 148, '_menu_item_object', 'page'),
(468, 148, '_menu_item_target', ''),
(469, 148, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(470, 148, '_menu_item_xfn', ''),
(471, 148, '_menu_item_url', ''),
(472, 148, '_menu_item_orphaned', '1449847510'),
(473, 149, '_menu_item_type', 'post_type'),
(474, 149, '_menu_item_menu_item_parent', '0'),
(475, 149, '_menu_item_object_id', '132'),
(476, 149, '_menu_item_object', 'page') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(477, 149, '_menu_item_target', ''),
(478, 149, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(479, 149, '_menu_item_xfn', ''),
(480, 149, '_menu_item_url', ''),
(481, 149, '_menu_item_orphaned', '1449847510'),
(482, 150, '_menu_item_type', 'post_type'),
(483, 150, '_menu_item_menu_item_parent', '0'),
(484, 150, '_menu_item_object_id', '130'),
(485, 150, '_menu_item_object', 'page'),
(486, 150, '_menu_item_target', ''),
(487, 150, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(488, 150, '_menu_item_xfn', ''),
(489, 150, '_menu_item_url', ''),
(490, 150, '_menu_item_orphaned', '1449847510'),
(491, 151, '_menu_item_type', 'post_type'),
(492, 151, '_menu_item_menu_item_parent', '0'),
(493, 151, '_menu_item_object_id', '128'),
(494, 151, '_menu_item_object', 'page'),
(495, 151, '_menu_item_target', ''),
(496, 151, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(497, 151, '_menu_item_xfn', ''),
(498, 151, '_menu_item_url', ''),
(499, 151, '_menu_item_orphaned', '1449847510'),
(500, 152, '_menu_item_type', 'post_type'),
(501, 152, '_menu_item_menu_item_parent', '0'),
(502, 152, '_menu_item_object_id', '126'),
(503, 152, '_menu_item_object', 'page'),
(504, 152, '_menu_item_target', ''),
(505, 152, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(506, 152, '_menu_item_xfn', ''),
(507, 152, '_menu_item_url', ''),
(508, 152, '_menu_item_orphaned', '1449847510'),
(509, 153, '_menu_item_type', 'post_type'),
(510, 153, '_menu_item_menu_item_parent', '0'),
(511, 153, '_menu_item_object_id', '124'),
(512, 153, '_menu_item_object', 'page'),
(513, 153, '_menu_item_target', ''),
(514, 153, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(515, 153, '_menu_item_xfn', ''),
(516, 153, '_menu_item_url', ''),
(517, 153, '_menu_item_orphaned', '1449847510'),
(518, 154, '_menu_item_type', 'post_type'),
(519, 154, '_menu_item_menu_item_parent', '0'),
(520, 154, '_menu_item_object_id', '122'),
(521, 154, '_menu_item_object', 'page'),
(522, 154, '_menu_item_target', ''),
(523, 154, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(524, 154, '_menu_item_xfn', ''),
(525, 154, '_menu_item_url', ''),
(526, 154, '_menu_item_orphaned', '1449847510'),
(527, 155, '_menu_item_type', 'post_type'),
(528, 155, '_menu_item_menu_item_parent', '0'),
(529, 155, '_menu_item_object_id', '120'),
(530, 155, '_menu_item_object', 'page'),
(531, 155, '_menu_item_target', ''),
(532, 155, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(533, 155, '_menu_item_xfn', ''),
(534, 155, '_menu_item_url', ''),
(535, 155, '_menu_item_orphaned', '1449847510'),
(536, 156, '_menu_item_type', 'post_type'),
(537, 156, '_menu_item_menu_item_parent', '0'),
(538, 156, '_menu_item_object_id', '118'),
(539, 156, '_menu_item_object', 'page'),
(540, 156, '_menu_item_target', ''),
(541, 156, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(542, 156, '_menu_item_xfn', ''),
(543, 156, '_menu_item_url', ''),
(544, 156, '_menu_item_orphaned', '1449847510'),
(545, 157, '_menu_item_type', 'post_type'),
(546, 157, '_menu_item_menu_item_parent', '0'),
(547, 157, '_menu_item_object_id', '116'),
(548, 157, '_menu_item_object', 'page'),
(549, 157, '_menu_item_target', ''),
(550, 157, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(551, 157, '_menu_item_xfn', ''),
(552, 157, '_menu_item_url', ''),
(553, 157, '_menu_item_orphaned', '1449847510'),
(554, 158, '_menu_item_type', 'post_type'),
(555, 158, '_menu_item_menu_item_parent', '0'),
(556, 158, '_menu_item_object_id', '114'),
(557, 158, '_menu_item_object', 'page'),
(558, 158, '_menu_item_target', ''),
(559, 158, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(560, 158, '_menu_item_xfn', ''),
(561, 158, '_menu_item_url', ''),
(562, 158, '_menu_item_orphaned', '1449847510'),
(563, 159, '_menu_item_type', 'post_type'),
(564, 159, '_menu_item_menu_item_parent', '0'),
(565, 159, '_menu_item_object_id', '4'),
(566, 159, '_menu_item_object', 'page'),
(567, 159, '_menu_item_target', ''),
(568, 159, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(569, 159, '_menu_item_xfn', ''),
(570, 159, '_menu_item_url', ''),
(572, 160, '_menu_item_type', 'post_type'),
(573, 160, '_menu_item_menu_item_parent', '0'),
(574, 160, '_menu_item_object_id', '4'),
(575, 160, '_menu_item_object', 'page'),
(576, 160, '_menu_item_target', ''),
(577, 160, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(578, 160, '_menu_item_xfn', ''),
(579, 160, '_menu_item_url', ''),
(580, 160, '_menu_item_orphaned', '1449847681'),
(581, 161, '_menu_item_type', 'post_type'),
(582, 161, '_menu_item_menu_item_parent', '0'),
(583, 161, '_menu_item_object_id', '15'),
(584, 161, '_menu_item_object', 'page'),
(585, 161, '_menu_item_target', ''),
(586, 161, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(587, 161, '_menu_item_xfn', ''),
(588, 161, '_menu_item_url', ''),
(590, 162, '_menu_item_type', 'post_type'),
(591, 162, '_menu_item_menu_item_parent', '161'),
(592, 162, '_menu_item_object_id', '106'),
(593, 162, '_menu_item_object', 'page'),
(594, 162, '_menu_item_target', ''),
(595, 162, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(596, 162, '_menu_item_xfn', ''),
(597, 162, '_menu_item_url', ''),
(599, 163, '_menu_item_type', 'post_type'),
(600, 163, '_menu_item_menu_item_parent', '161'),
(601, 163, '_menu_item_object_id', '63'),
(602, 163, '_menu_item_object', 'page'),
(603, 163, '_menu_item_target', ''),
(604, 163, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(605, 163, '_menu_item_xfn', ''),
(606, 163, '_menu_item_url', ''),
(608, 164, '_menu_item_type', 'post_type'),
(609, 164, '_menu_item_menu_item_parent', '0'),
(610, 164, '_menu_item_object_id', '17'),
(611, 164, '_menu_item_object', 'page'),
(612, 164, '_menu_item_target', ''),
(613, 164, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(614, 164, '_menu_item_xfn', ''),
(615, 164, '_menu_item_url', ''),
(617, 165, '_menu_item_type', 'post_type'),
(618, 165, '_menu_item_menu_item_parent', '164'),
(619, 165, '_menu_item_object_id', '110'),
(620, 165, '_menu_item_object', 'page'),
(621, 165, '_menu_item_target', ''),
(622, 165, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(623, 165, '_menu_item_xfn', ''),
(624, 165, '_menu_item_url', ''),
(626, 166, '_menu_item_type', 'post_type'),
(627, 166, '_menu_item_menu_item_parent', '164'),
(628, 166, '_menu_item_object_id', '108'),
(629, 166, '_menu_item_object', 'page'),
(630, 166, '_menu_item_target', ''),
(631, 166, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(632, 166, '_menu_item_xfn', ''),
(633, 166, '_menu_item_url', ''),
(635, 167, '_menu_item_type', 'post_type'),
(636, 167, '_menu_item_menu_item_parent', '0'),
(637, 167, '_menu_item_object_id', '21'),
(638, 167, '_menu_item_object', 'page'),
(639, 167, '_menu_item_target', ''),
(640, 167, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(641, 167, '_menu_item_xfn', ''),
(642, 167, '_menu_item_url', ''),
(644, 168, '_menu_item_type', 'post_type'),
(645, 168, '_menu_item_menu_item_parent', '167'),
(646, 168, '_menu_item_object_id', '44'),
(647, 168, '_menu_item_object', 'page'),
(648, 168, '_menu_item_target', ''),
(649, 168, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(650, 168, '_menu_item_xfn', ''),
(651, 168, '_menu_item_url', ''),
(653, 169, '_menu_item_type', 'post_type'),
(654, 169, '_menu_item_menu_item_parent', '167'),
(655, 169, '_menu_item_object_id', '112'),
(656, 169, '_menu_item_object', 'page'),
(657, 169, '_menu_item_target', ''),
(658, 169, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(659, 169, '_menu_item_xfn', ''),
(660, 169, '_menu_item_url', ''),
(662, 170, '_menu_item_type', 'post_type'),
(663, 170, '_menu_item_menu_item_parent', '167'),
(664, 170, '_menu_item_object_id', '114'),
(665, 170, '_menu_item_object', 'page'),
(666, 170, '_menu_item_target', ''),
(667, 170, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(668, 170, '_menu_item_xfn', ''),
(669, 170, '_menu_item_url', ''),
(671, 171, '_menu_item_type', 'post_type'),
(672, 171, '_menu_item_menu_item_parent', '167'),
(673, 171, '_menu_item_object_id', '118'),
(674, 171, '_menu_item_object', 'page'),
(675, 171, '_menu_item_target', ''),
(676, 171, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(677, 171, '_menu_item_xfn', ''),
(678, 171, '_menu_item_url', ''),
(680, 172, '_menu_item_type', 'post_type'),
(681, 172, '_menu_item_menu_item_parent', '167'),
(682, 172, '_menu_item_object_id', '116'),
(683, 172, '_menu_item_object', 'page'),
(684, 172, '_menu_item_target', ''),
(685, 172, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(686, 172, '_menu_item_xfn', ''),
(687, 172, '_menu_item_url', ''),
(689, 173, '_menu_item_type', 'post_type') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(690, 173, '_menu_item_menu_item_parent', '0'),
(691, 173, '_menu_item_object_id', '19'),
(692, 173, '_menu_item_object', 'page'),
(693, 173, '_menu_item_target', ''),
(694, 173, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(695, 173, '_menu_item_xfn', ''),
(696, 173, '_menu_item_url', ''),
(698, 174, '_menu_item_type', 'post_type'),
(699, 174, '_menu_item_menu_item_parent', '173'),
(700, 174, '_menu_item_object_id', '120'),
(701, 174, '_menu_item_object', 'page'),
(702, 174, '_menu_item_target', ''),
(703, 174, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(704, 174, '_menu_item_xfn', ''),
(705, 174, '_menu_item_url', ''),
(707, 175, '_menu_item_type', 'post_type'),
(708, 175, '_menu_item_menu_item_parent', '174'),
(709, 175, '_menu_item_object_id', '130'),
(710, 175, '_menu_item_object', 'page'),
(711, 175, '_menu_item_target', ''),
(712, 175, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(713, 175, '_menu_item_xfn', ''),
(714, 175, '_menu_item_url', ''),
(716, 176, '_menu_item_type', 'post_type'),
(717, 176, '_menu_item_menu_item_parent', '174'),
(718, 176, '_menu_item_object_id', '134'),
(719, 176, '_menu_item_object', 'page'),
(720, 176, '_menu_item_target', ''),
(721, 176, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(722, 176, '_menu_item_xfn', ''),
(723, 176, '_menu_item_url', ''),
(725, 177, '_menu_item_type', 'post_type'),
(726, 177, '_menu_item_menu_item_parent', '174'),
(727, 177, '_menu_item_object_id', '126'),
(728, 177, '_menu_item_object', 'page'),
(729, 177, '_menu_item_target', ''),
(730, 177, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(731, 177, '_menu_item_xfn', ''),
(732, 177, '_menu_item_url', ''),
(734, 178, '_menu_item_type', 'post_type'),
(735, 178, '_menu_item_menu_item_parent', '174'),
(736, 178, '_menu_item_object_id', '124'),
(737, 178, '_menu_item_object', 'page'),
(738, 178, '_menu_item_target', ''),
(739, 178, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(740, 178, '_menu_item_xfn', ''),
(741, 178, '_menu_item_url', ''),
(743, 179, '_menu_item_type', 'post_type'),
(744, 179, '_menu_item_menu_item_parent', '174'),
(745, 179, '_menu_item_object_id', '132'),
(746, 179, '_menu_item_object', 'page'),
(747, 179, '_menu_item_target', ''),
(748, 179, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(749, 179, '_menu_item_xfn', ''),
(750, 179, '_menu_item_url', ''),
(752, 180, '_menu_item_type', 'post_type'),
(753, 180, '_menu_item_menu_item_parent', '174'),
(754, 180, '_menu_item_object_id', '128'),
(755, 180, '_menu_item_object', 'page'),
(756, 180, '_menu_item_target', ''),
(757, 180, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(758, 180, '_menu_item_xfn', ''),
(759, 180, '_menu_item_url', ''),
(761, 181, '_menu_item_type', 'post_type'),
(762, 181, '_menu_item_menu_item_parent', '174'),
(763, 181, '_menu_item_object_id', '136'),
(764, 181, '_menu_item_object', 'page'),
(765, 181, '_menu_item_target', ''),
(766, 181, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(767, 181, '_menu_item_xfn', ''),
(768, 181, '_menu_item_url', ''),
(770, 182, '_menu_item_type', 'post_type'),
(771, 182, '_menu_item_menu_item_parent', '174'),
(772, 182, '_menu_item_object_id', '122'),
(773, 182, '_menu_item_object', 'page'),
(774, 182, '_menu_item_target', ''),
(775, 182, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(776, 182, '_menu_item_xfn', ''),
(777, 182, '_menu_item_url', ''),
(779, 183, '_menu_item_type', 'post_type'),
(780, 183, '_menu_item_menu_item_parent', '173'),
(781, 183, '_menu_item_object_id', '70'),
(782, 183, '_menu_item_object', 'page'),
(783, 183, '_menu_item_target', ''),
(784, 183, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(785, 183, '_menu_item_xfn', ''),
(786, 183, '_menu_item_url', ''),
(788, 184, '_menu_item_type', 'post_type'),
(789, 184, '_menu_item_menu_item_parent', '183'),
(790, 184, '_menu_item_object_id', '142'),
(791, 184, '_menu_item_object', 'page'),
(792, 184, '_menu_item_target', ''),
(793, 184, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(794, 184, '_menu_item_xfn', ''),
(795, 184, '_menu_item_url', ''),
(797, 185, '_menu_item_type', 'post_type'),
(798, 185, '_menu_item_menu_item_parent', '183'),
(799, 185, '_menu_item_object_id', '140'),
(800, 185, '_menu_item_object', 'page'),
(801, 185, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(802, 185, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(803, 185, '_menu_item_xfn', ''),
(804, 185, '_menu_item_url', ''),
(806, 186, '_menu_item_type', 'post_type'),
(807, 186, '_menu_item_menu_item_parent', '183'),
(808, 186, '_menu_item_object_id', '138'),
(809, 186, '_menu_item_object', 'page'),
(810, 186, '_menu_item_target', ''),
(811, 186, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(812, 186, '_menu_item_xfn', ''),
(813, 186, '_menu_item_url', ''),
(815, 187, '_menu_item_type', 'post_type'),
(816, 187, '_menu_item_menu_item_parent', '183'),
(817, 187, '_menu_item_object_id', '50'),
(818, 187, '_menu_item_object', 'page'),
(819, 187, '_menu_item_target', ''),
(820, 187, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(821, 187, '_menu_item_xfn', ''),
(822, 187, '_menu_item_url', ''),
(824, 188, '_menu_item_type', 'post_type'),
(825, 188, '_menu_item_menu_item_parent', '174'),
(826, 188, '_menu_item_object_id', '95'),
(827, 188, '_menu_item_object', 'page'),
(828, 188, '_menu_item_target', ''),
(829, 188, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(830, 188, '_menu_item_xfn', ''),
(831, 188, '_menu_item_url', ''),
(833, 189, '_menu_item_type', 'post_type'),
(834, 189, '_menu_item_menu_item_parent', '174'),
(835, 189, '_menu_item_object_id', '72'),
(836, 189, '_menu_item_object', 'page'),
(837, 189, '_menu_item_target', ''),
(838, 189, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(839, 189, '_menu_item_xfn', ''),
(840, 189, '_menu_item_url', ''),
(842, 190, '_menu_item_type', 'post_type'),
(843, 190, '_menu_item_menu_item_parent', '0'),
(844, 190, '_menu_item_object_id', '25'),
(845, 190, '_menu_item_object', 'page'),
(846, 190, '_menu_item_target', ''),
(847, 190, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(848, 190, '_menu_item_xfn', ''),
(849, 190, '_menu_item_url', ''),
(851, 191, '_menu_item_type', 'post_type'),
(852, 191, '_menu_item_menu_item_parent', '0'),
(853, 191, '_menu_item_object_id', '130'),
(854, 191, '_menu_item_object', 'page'),
(855, 191, '_menu_item_target', ''),
(856, 191, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(857, 191, '_menu_item_xfn', ''),
(858, 191, '_menu_item_url', ''),
(860, 192, '_menu_item_type', 'post_type'),
(861, 192, '_menu_item_menu_item_parent', '0'),
(862, 192, '_menu_item_object_id', '134'),
(863, 192, '_menu_item_object', 'page'),
(864, 192, '_menu_item_target', ''),
(865, 192, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(866, 192, '_menu_item_xfn', ''),
(867, 192, '_menu_item_url', ''),
(869, 193, '_menu_item_type', 'post_type'),
(870, 193, '_menu_item_menu_item_parent', '0'),
(871, 193, '_menu_item_object_id', '126'),
(872, 193, '_menu_item_object', 'page'),
(873, 193, '_menu_item_target', ''),
(874, 193, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(875, 193, '_menu_item_xfn', ''),
(876, 193, '_menu_item_url', ''),
(878, 194, '_menu_item_type', 'post_type'),
(879, 194, '_menu_item_menu_item_parent', '0'),
(880, 194, '_menu_item_object_id', '124'),
(881, 194, '_menu_item_object', 'page'),
(882, 194, '_menu_item_target', ''),
(883, 194, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(884, 194, '_menu_item_xfn', ''),
(885, 194, '_menu_item_url', ''),
(887, 195, '_menu_item_type', 'post_type'),
(888, 195, '_menu_item_menu_item_parent', '0'),
(889, 195, '_menu_item_object_id', '132'),
(890, 195, '_menu_item_object', 'page'),
(891, 195, '_menu_item_target', ''),
(892, 195, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(893, 195, '_menu_item_xfn', ''),
(894, 195, '_menu_item_url', ''),
(896, 196, '_menu_item_type', 'post_type'),
(897, 196, '_menu_item_menu_item_parent', '0'),
(898, 196, '_menu_item_object_id', '128'),
(899, 196, '_menu_item_object', 'page'),
(900, 196, '_menu_item_target', ''),
(901, 196, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(902, 196, '_menu_item_xfn', ''),
(903, 196, '_menu_item_url', ''),
(905, 197, '_menu_item_type', 'post_type'),
(906, 197, '_menu_item_menu_item_parent', '0'),
(907, 197, '_menu_item_object_id', '136'),
(908, 197, '_menu_item_object', 'page'),
(909, 197, '_menu_item_target', ''),
(910, 197, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(911, 197, '_menu_item_xfn', ''),
(912, 197, '_menu_item_url', ''),
(914, 198, '_menu_item_type', 'post_type') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(915, 198, '_menu_item_menu_item_parent', '0'),
(916, 198, '_menu_item_object_id', '122'),
(917, 198, '_menu_item_object', 'page'),
(918, 198, '_menu_item_target', ''),
(919, 198, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(920, 198, '_menu_item_xfn', ''),
(921, 198, '_menu_item_url', ''),
(923, 199, '_menu_item_type', 'post_type'),
(924, 199, '_menu_item_menu_item_parent', '0'),
(925, 199, '_menu_item_object_id', '72'),
(926, 199, '_menu_item_object', 'page'),
(927, 199, '_menu_item_target', ''),
(928, 199, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(929, 199, '_menu_item_xfn', ''),
(930, 199, '_menu_item_url', ''),
(932, 200, '_menu_item_type', 'post_type'),
(933, 200, '_menu_item_menu_item_parent', '0'),
(934, 200, '_menu_item_object_id', '142'),
(935, 200, '_menu_item_object', 'page'),
(936, 200, '_menu_item_target', ''),
(937, 200, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(938, 200, '_menu_item_xfn', ''),
(939, 200, '_menu_item_url', ''),
(941, 201, '_menu_item_type', 'post_type'),
(942, 201, '_menu_item_menu_item_parent', '0'),
(943, 201, '_menu_item_object_id', '140'),
(944, 201, '_menu_item_object', 'page'),
(945, 201, '_menu_item_target', ''),
(946, 201, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(947, 201, '_menu_item_xfn', ''),
(948, 201, '_menu_item_url', ''),
(950, 202, '_menu_item_type', 'post_type'),
(951, 202, '_menu_item_menu_item_parent', '0'),
(952, 202, '_menu_item_object_id', '138'),
(953, 202, '_menu_item_object', 'page'),
(954, 202, '_menu_item_target', ''),
(955, 202, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(956, 202, '_menu_item_xfn', ''),
(957, 202, '_menu_item_url', ''),
(959, 203, '_menu_item_type', 'post_type'),
(960, 203, '_menu_item_menu_item_parent', '0'),
(961, 203, '_menu_item_object_id', '50'),
(962, 203, '_menu_item_object', 'page'),
(963, 203, '_menu_item_target', ''),
(964, 203, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(965, 203, '_menu_item_xfn', ''),
(966, 203, '_menu_item_url', ''),
(968, 19, '_wp_page_template', 'template-site.php'),
(969, 217, '_edit_last', '1'),
(970, 217, '_edit_lock', '1450193482:1'),
(971, 217, 'instrument_bild', ''),
(972, 217, '_instrument_bild', 'field_5656f1c469a43'),
(973, 217, 'instrument_unterrichtsschwerpunkte', ''),
(974, 217, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(975, 217, 'instrument_unterrichtsform', 'Einzelunterricht und\r\nEnsemblespiel'),
(976, 217, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(977, 217, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min \r\nFörderstufe 45 min'),
(978, 217, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(979, 217, 'instrument_ergaenzende_facher', ''),
(980, 217, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(981, 217, 'instrument_by_dozenten', ''),
(982, 217, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(983, 217, 'instrument_links', 'Erlebniswelt Blockflöte\r\nEin Blockflötenmuseum zum Anfassen und Mitmachen, zum Lernen und Begreifen, und das auch noch mit jeder Menge Spaß: für Blockflötenfreunde jeden Alters.\r\n\r\nPortal blockfloete.de\r\nblockfloete.de ist eine Plattform, die von einigen Blockflötenverrückten betrieben und gepflegt wird. Das heisst, es gibt kein Vollzeit-Redaktionsteam, sondern alle Updates und Ergänzungen werden quasi "in der Freizeit" gemacht.\r\n\r\nwindkanal - forum für Blockflöte\r\nDer Windkanal bietet Kapitel zu den Tehmen Alte und Neue Musik, Portraits und Interviews, Praxis Blockflötenunterricht, Aus der Blockflötenwerkstatt, Bildung und Ausbildung, Symposien, Kongresse, Seminare und einen Terminkalender mit Fortbildungsangeboten in Deutschland, Österreich und der Schweiz'),
(984, 217, '_instrument_links', 'field_5656f2422905e'),
(986, 218, '_edit_last', '1'),
(987, 218, '_edit_lock', '1450193483:1'),
(988, 218, 'instrument_bild', ''),
(989, 218, '_instrument_bild', 'field_5656f1c469a43'),
(990, 218, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Ansatz, Grifftechnik), Spielliteratur von Barock bis zum 20. Jahrhundert, Atemführung und Musikalische Gestaltung.'),
(991, 218, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(992, 218, 'instrument_unterrichtsform', 'Einzelunterricht, \r\nEnsemblespiel, \r\nSpiel mit Klavierbegleitung, \r\nMitwirken im Jugendorchester'),
(993, 218, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(994, 218, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min \r\nFörderstufe 45 min\r\n'),
(995, 218, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(996, 218, 'instrument_ergaenzende_facher', ''),
(997, 218, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(998, 218, 'instrument_by_dozenten', ''),
(999, 218, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1000, 218, 'instrument_links', 'fagott.de - Das Forum rund um das Fagott\r\nAlles rund um das Fagott, aus Hochschule, Musikschule, Orchester, über Komponisten, Organisationen, mit einer umfangreichen Notendatenbank und Kurstermine.'),
(1001, 218, '_instrument_links', 'field_5656f2422905e'),
(1002, 219, '_edit_last', '1'),
(1003, 219, '_edit_lock', '1450193483:1'),
(1004, 219, 'instrument_bild', ''),
(1005, 219, '_instrument_bild', 'field_5656f1c469a43'),
(1006, 219, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Ansatz, Grifftechnik), Spielliteratur von Barock bis zum 20. Jahrhundert, Atemführung und Musikalische Gestaltung. Die Musikschule Havixbeck bietet auch die Möglichkeit verwandten Instrumente Es-Klarinette, Altklarinette oder Bassklarinette zu lernen.\r\n'),
(1007, 219, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1008, 219, 'instrument_unterrichtsform', 'Einzelunterricht, \r\nEnsemblespiel, \r\nSpiel mit Klavierbegleitung, \r\nMitwirken im Jugendorchester'),
(1009, 219, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1010, 219, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min \r\nFörderstufe 45 min\r\n'),
(1011, 219, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1012, 219, 'instrument_ergaenzende_facher', ''),
(1013, 219, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1014, 219, 'instrument_by_dozenten', ''),
(1015, 219, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1016, 219, 'instrument_links', 'www.die-klarinetten.de\r\nAlles über das vielseitige Blasinstrument.'),
(1017, 219, '_instrument_links', 'field_5656f2422905e'),
(1018, 220, '_edit_last', '1'),
(1019, 220, '_edit_lock', '1450193484:1'),
(1020, 220, 'instrument_bild', ''),
(1021, 220, '_instrument_bild', 'field_5656f1c469a43') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1022, 220, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Ansatz, Grifftechnik), Spielliteratur von Barock bis zum 20. Jahrhundert, Atemführung und Musikalische Gestaltung. Die Musikschule Havixbeck bietet auch die Möglichkeit das verwandte Instrument Englisch Horn zu lernen.'),
(1023, 220, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1024, 220, 'instrument_unterrichtsform', 'Einzelunterricht, \r\nEnsemblespiel, \r\nSpiel mit Klavierbegleitung, \r\nMitwirken im Jugendorchester'),
(1025, 220, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1026, 220, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min \r\nFörderstufe 45 min'),
(1027, 220, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1028, 220, 'instrument_ergaenzende_facher', ''),
(1029, 220, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1030, 220, 'instrument_by_dozenten', ''),
(1031, 220, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1032, 220, 'instrument_links', ''),
(1033, 220, '_instrument_links', 'field_5656f2422905e'),
(1034, 221, '_edit_last', '1'),
(1035, 221, '_edit_lock', '1450193484:1'),
(1036, 221, 'instrument_bild', ''),
(1037, 221, '_instrument_bild', 'field_5656f1c469a43'),
(1038, 221, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Ansatz, Grifftechnik), Spielliteratur von Barock bis zum 20. Jahrhundert, Atemführung und Musikalische Gestaltung.'),
(1039, 221, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1040, 221, 'instrument_unterrichtsform', 'Einzelunterricht, \r\nEnsemblespiel, \r\nSpiel mit Klavierbegleitung, \r\nMitwirken im Jugendorchester'),
(1041, 221, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1042, 221, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min \r\nFörderstufe 45 min'),
(1043, 221, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1044, 221, 'instrument_ergaenzende_facher', ''),
(1045, 221, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1046, 221, 'instrument_by_dozenten', ''),
(1047, 221, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1048, 221, 'instrument_links', 'www.flutepage.de\r\nPrivate Homepage von über Querflöten, deren Geschichte und Entwicklung, Komponisten, Interpreten, Links, Bücher, Repertoire.'),
(1049, 221, '_instrument_links', 'field_5656f2422905e'),
(1050, 222, '_edit_last', '1'),
(1051, 222, '_edit_lock', '1450193485:1'),
(1052, 222, 'instrument_bild', ''),
(1053, 222, '_instrument_bild', 'field_5656f1c469a43'),
(1054, 222, 'instrument_unterrichtsschwerpunkte', 'Ansatztechnik, Körperhaltung,\r\nFingertechnik, Atmung und Luftführung, Klangfarbengestaltung, Zungentechnik, Vibrato, Artikulation und Interpretation, Rhythmik.\r\nDie Musikschule Havixbeck bietet die Möglichkeit "Klassisches Saxophon" und "Jazz-Saxophon" zu erlernen.\r\nSpielliteratur: Standardliteratur (Schulen, Etüden, Instrumentalwerke etc.) für Klassisches Saxophon bzw. Jazz-Saxophon. '),
(1055, 222, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1056, 222, 'instrument_unterrichtsform', 'Einzelunterricht, \r\nSaxophonensemble "Saxonata", \r\nMitwirken im Jugendorchester'),
(1057, 222, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1058, 222, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min \r\nFörderstufe 45 min'),
(1059, 222, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1060, 222, 'instrument_ergaenzende_facher', ''),
(1061, 222, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1062, 222, 'instrument_by_dozenten', 'a:1:{i:0;s:2:"93";}'),
(1063, 222, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1064, 222, 'instrument_links', 'saxophon.com - Home of the saxophone\r\nEin umfangreiches Online-Projekt "rund um das Saxophon" des Musikverlages "Chili Notes".\r\n\r\nArbeitsgemeinschaft Deutsche Saxophonisten e.V.\r\nPortal für Klassisches Saxophon.\r\n\r\nZerluth - Holzbläserverlag\r\nNotenfachgeschäft für Saxophon.\r\n\r\nMenkenMusic'),
(1065, 222, '_instrument_links', 'field_5656f2422905e'),
(1066, 223, '_edit_last', '1'),
(1067, 223, '_edit_lock', '1450193649:1'),
(1068, 223, 'instrument_bild', ''),
(1069, 223, '_instrument_bild', 'field_5656f1c469a43'),
(1070, 223, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Ansatz, Grifftechnik), Spielliteratur von Klassik bis zum 20. Jahrhundert, Atemführung und Musikalische Gestaltung.\r\n'),
(1071, 223, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1072, 223, 'instrument_unterrichtsform', 'Einzelunterricht, \r\nEnsemblespiel, \r\nSpiel mit Klavierbegleitung, \r\nMitwirken im Jugendorchester\r\n'),
(1073, 223, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1074, 223, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30min \r\nFörderstufe 45 min\r\n'),
(1075, 223, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1076, 223, 'instrument_ergaenzende_facher', ''),
(1077, 223, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1078, 223, 'instrument_by_dozenten', ''),
(1079, 223, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1080, 223, 'instrument_links', 'TubaEuph\r\nenglischsprachige Homepage mit vielen Informationen zu den tiefen Blechblasinstrumenten\r\n\r\nEuphonium Net\r\ndie Homepage von Steven Mead einem der hervorragensten Euphonium Solisten der Welt\r\n\r\nInternational Tuba Euphonium Association'),
(1081, 223, '_instrument_links', 'field_5656f2422905e'),
(1082, 224, '_edit_last', '1'),
(1083, 224, '_edit_lock', '1450193648:1'),
(1084, 224, 'instrument_bild', ''),
(1085, 224, '_instrument_bild', 'field_5656f1c469a43'),
(1086, 224, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Ansatz, Grifftechnik), Spielliteratur von Barock bis zum 21. Jahrhundert, Atemführung und Musikalische Gestaltung.'),
(1087, 224, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1088, 224, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nSpiel mit Klavierbegleitung,\r\nMitwirken im Jugendorchester'),
(1089, 224, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1090, 224, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30min\r\nFörderstufe 45 min'),
(1091, 224, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1092, 224, 'instrument_ergaenzende_facher', ''),
(1093, 224, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1094, 224, 'instrument_by_dozenten', ''),
(1095, 224, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1096, 224, 'instrument_links', 'Hornweb.ch\r\nSchweizer Homepage zum Thema Waldhorn mit vielen Informationen und Musikerbiografien.\r\n\r\nInternational Horn Society'),
(1097, 224, '_instrument_links', 'field_5656f2422905e'),
(1098, 225, '_edit_last', '1'),
(1099, 225, '_edit_lock', '1450193648:1'),
(1100, 225, 'instrument_bild', ''),
(1101, 225, '_instrument_bild', 'field_5656f1c469a43'),
(1102, 225, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Ansatz, Grifftechnik), Spielliteratur von Barock bis zum 20. Jahrhundert, Atemführung und Musikalische Gestaltung'),
(1103, 225, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1104, 225, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nSpiel mit Klavierbegleitung,\r\nMitwirken im Jugendorchester'),
(1105, 225, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1106, 225, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1107, 225, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1108, 225, 'instrument_ergaenzende_facher', ''),
(1109, 225, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1110, 225, 'instrument_by_dozenten', ''),
(1111, 225, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1112, 225, 'instrument_links', 'Internationale Posaunen-Vereinigung e.V\r\n\r\nOnline Trombone Journal\r\nEnglischsprachige hochinteressante und informative Posaunenhomepage!'),
(1113, 225, '_instrument_links', 'field_5656f2422905e'),
(1114, 226, '_edit_last', '1'),
(1115, 226, '_edit_lock', '1450193647:1'),
(1116, 226, 'instrument_bild', ''),
(1117, 226, '_instrument_bild', 'field_5656f1c469a43'),
(1118, 226, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Ansatz, Grifftechnik), Spielliteratur von Barock bis zum 21. Jahrhundert, Atemführung und Musikalische Gestaltung.'),
(1119, 226, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1120, 226, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nSpiel mit Klavierbegleitung,\r\nMitwirken im Jugendorchester'),
(1121, 226, '_instrument_unterrichtsform', 'field_566952391f9a0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1122, 226, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30min,\r\nFörderstufe 45min'),
(1123, 226, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1124, 226, 'instrument_ergaenzende_facher', ''),
(1125, 226, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1126, 226, 'instrument_by_dozenten', ''),
(1127, 226, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1128, 226, 'instrument_links', 'Deutsches Tubaforum e.V.\r\n\r\nInternational Tuba Euphonium Association'),
(1129, 226, '_instrument_links', 'field_5656f2422905e'),
(1130, 227, '_edit_last', '1'),
(1131, 227, '_edit_lock', '1450193667:1'),
(1132, 227, 'instrument_bild', ''),
(1133, 227, '_instrument_bild', 'field_5656f1c469a43'),
(1134, 227, 'instrument_unterrichtsschwerpunkte', 'Stockhaltung, Schlagtechniken, Klangmöglichkeiten, Rhythmische Stilrichtungen, Improvisation, Sololiteratur, Ensembleliteratur\r\nDie Musikschule Havixbeck bietet alle notwendigen Instrumente um alle Bereiche des Schlagwerkes erlernen zu können.'),
(1135, 227, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1136, 227, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nMitwirken im Jugendorchester'),
(1137, 227, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1138, 227, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1139, 227, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1140, 227, 'instrument_ergaenzende_facher', ''),
(1141, 227, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1142, 227, 'instrument_by_dozenten', ''),
(1143, 227, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1144, 227, 'instrument_links', 'percussion creativ\r\nDeutschsprachiges Netzwerk von Schlagzeugern für Schlagzeuger.\r\n\r\nSchlagwerk Percussion\r\nBilder, Kurzbeschreibungen und Klangbeispiele verschiedenster Percussioninstrumente.\r\n\r\nstickcontrol.de - Schlagzeugnoten umsonst\r\nSehr informative Seite für Schlagzeuger mit vielen kostenlosen Noten-und Hörbeispielen.'),
(1145, 227, '_instrument_links', 'field_5656f2422905e'),
(1146, 228, '_edit_last', '1'),
(1147, 228, '_edit_lock', '1450193488:1'),
(1148, 228, 'instrument_bild', ''),
(1149, 228, '_instrument_bild', 'field_5656f1c469a43'),
(1150, 228, 'instrument_unterrichtsschwerpunkte', 'Saitenweise ... schöne Klänge - ob Klassik, Jazz, Popularmusik oder Volksmusik.'),
(1151, 228, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1152, 228, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nSpiel mit Klavierbegleitung,\r\nMitwirken im Jugendorchester'),
(1153, 228, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1154, 228, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1155, 228, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1156, 228, 'instrument_ergaenzende_facher', ''),
(1157, 228, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1158, 228, 'instrument_by_dozenten', ''),
(1159, 228, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1160, 228, 'instrument_links', '<a href="#">INTERNET CELLO SOCIETY</a>'),
(1161, 228, '_instrument_links', 'field_5656f2422905e'),
(1162, 229, '_edit_last', '1'),
(1163, 229, '_edit_lock', '1450193487:1'),
(1164, 229, 'instrument_bild', ''),
(1165, 229, '_instrument_bild', 'field_5656f1c469a43'),
(1166, 229, 'instrument_unterrichtsschwerpunkte', 'Einzelunterricht,\r\nEnsemblespiel,\r\nMitwirken im Jugendorchester (E-Bassgitarre)'),
(1167, 229, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1168, 229, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nEnsemblespiel mit anderen Instrumenten'),
(1169, 229, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1170, 229, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30min\r\nFörderstufe 45 min'),
(1171, 229, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1172, 229, 'instrument_ergaenzende_facher', ''),
(1173, 229, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1174, 229, 'instrument_by_dozenten', ''),
(1175, 229, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1176, 229, 'instrument_links', 'GuitarNet\r\nEiniges zum Thema E-Gitarre: Präsentation, historische Entwick-lung, Midis für Gitarristen, Tabulaturen, Workshops, Entwicklung von Lernsoftware für die Schule.'),
(1177, 229, '_instrument_links', 'field_5656f2422905e'),
(1178, 230, '_edit_last', '1'),
(1179, 230, '_edit_lock', '1450193487:1'),
(1180, 230, 'instrument_bild', ''),
(1181, 230, '_instrument_bild', 'field_5656f1c469a43'),
(1182, 230, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Fingerstyle, Grifftechnik), Spielliteratur von Renaissance bis zum 20. Jahrhundert (Rock, Jazz, Flamenco), Musikalische Gestaltung und Liedbegleitung.'),
(1183, 230, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1184, 230, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nEnsemblespiel mit anderen Instrumenten'),
(1185, 230, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1186, 230, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1187, 230, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1188, 230, 'instrument_ergaenzende_facher', ''),
(1189, 230, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1190, 230, 'instrument_by_dozenten', ''),
(1191, 230, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1192, 230, 'instrument_links', 'Akustik Gitarre\r\nFachzeitschrift für Gitarristinnen und Gitarristen.\r\n\r\nGitarre - Guitarre - Guitar\r\nÄußerst umfangreiche Homepage zu diesem vielsaitigen Zupfinstrument. Technik, Instrumente, Musikstile.'),
(1193, 230, '_instrument_links', 'field_5656f2422905e'),
(1194, 231, '_edit_last', '1'),
(1195, 231, '_edit_lock', '1450193486:1'),
(1196, 231, 'instrument_bild', ''),
(1197, 231, '_instrument_bild', 'field_5656f1c469a43'),
(1198, 231, 'instrument_unterrichtsschwerpunkte', 'Saitenweise ... schöne Klänge - ob Klassik, Jazz, Popularmusik oder Volksmusik.'),
(1199, 231, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1200, 231, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nSpiel mit Klavierbegleitung,\r\nMitwirken im Jugendorchester'),
(1201, 231, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1202, 231, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1203, 231, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1204, 231, 'instrument_ergaenzende_facher', ''),
(1205, 231, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1206, 231, 'instrument_by_dozenten', ''),
(1207, 231, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1208, 231, 'instrument_links', 'GeBa\r\nGesellschaft der Bassisten in Deutschland'),
(1209, 231, '_instrument_links', 'field_5656f2422905e'),
(1211, 232, '_edit_last', '1'),
(1212, 232, '_edit_lock', '1450193485:1'),
(1213, 232, 'instrument_bild', ''),
(1214, 232, '_instrument_bild', 'field_5656f1c469a43'),
(1215, 232, 'instrument_unterrichtsschwerpunkte', 'Saitenweise ...\r\n... schöne Klänge -\r\nob Klassik, Jazz, Popularmusik oder Volksmusik.'),
(1216, 232, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1217, 232, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nSpiel mit Klavierbegleitung,\r\nMitwirken im Jugendorchester'),
(1218, 232, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1219, 232, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1220, 232, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1221, 232, 'instrument_ergaenzende_facher', ''),
(1222, 232, '_instrument_ergaenzende_facher', 'field_566951a61f99f') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1223, 232, 'instrument_by_dozenten', ''),
(1224, 232, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1225, 232, 'instrument_links', ''),
(1226, 232, '_instrument_links', 'field_5656f2422905e'),
(1227, 233, '_edit_last', '1'),
(1228, 233, '_edit_lock', '1450191782:1'),
(1229, 233, 'instrument_bild', ''),
(1230, 233, '_instrument_bild', 'field_5656f1c469a43'),
(1231, 233, 'instrument_unterrichtsschwerpunkte', 'Abwechslungsreich geht es in unseren Lehrfach Keyboard zu: Jazz, Rock, Blues, Latin Pop, Funk, Dance-Floor, Hip-Hop, Salsa, Mambo, Boogie und vieles mehr steht am Programm.'),
(1232, 233, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1233, 233, 'instrument_unterrichtsform', 'Einzelunterricht'),
(1234, 233, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1235, 233, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1236, 233, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1237, 233, 'instrument_ergaenzende_facher', ''),
(1238, 233, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1239, 233, 'instrument_by_dozenten', ''),
(1240, 233, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1241, 233, 'instrument_links', ''),
(1242, 233, '_instrument_links', 'field_5656f2422905e'),
(1243, 234, '_edit_last', '1'),
(1244, 234, '_edit_lock', '1450191785:1'),
(1245, 234, 'instrument_bild', ''),
(1246, 234, '_instrument_bild', 'field_5656f1c469a43'),
(1247, 234, 'instrument_unterrichtsschwerpunkte', 'Technische Fertigkeiten (Anschlag, Fingersätze, Spieltechnik), Spielliteratur von Barock bis zum 21. Jahrhundert, Musikalische Gestaltung.'),
(1248, 234, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1249, 234, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel mit Instrumenten oder SängerInnen'),
(1250, 234, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1251, 234, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1252, 234, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1253, 234, 'instrument_ergaenzende_facher', ''),
(1254, 234, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1255, 234, 'instrument_by_dozenten', ''),
(1256, 234, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1257, 234, 'instrument_links', ''),
(1258, 234, '_instrument_links', 'field_5656f2422905e'),
(1259, 235, '_edit_last', '1'),
(1260, 235, '_edit_lock', '1450191734:1'),
(1261, 235, 'instrument_bild', ''),
(1262, 235, '_instrument_bild', 'field_5656f1c469a43'),
(1263, 235, 'instrument_unterrichtsschwerpunkte', 'Der Schwerpunkt im Unterrichtsfach Orgel liegt auf Musik aus dem 16. bis 21. Jahrhundert und Improvisation für Kirchenmusik.'),
(1264, 235, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1265, 235, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,'),
(1266, 235, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1267, 235, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1268, 235, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1269, 235, 'instrument_ergaenzende_facher', ''),
(1270, 235, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1271, 235, 'instrument_by_dozenten', ''),
(1272, 235, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1273, 235, 'instrument_links', '<a class="underlined" href="http://www.orgelmagazin.com" target="_blank">orgelmagazin.com</a>\r\nOnline- Orgelmagazin aus Viersen am Niederrhein. Aktuelles um Pfeifen und Tasten.\r\n\r\n<a class="underlined" href="http://www.klosterkirchengemeinde.de/html/sauerorgel.html" target="_blank">Sauer-Orgel in Cottbus</a>\r\nDie oben abgebildeten Orgelpfeifen (fotografiert von Klaus Gärtner) stammen aus der Sauer-Orgel in der Klosterkirche zu Cottbus.'),
(1274, 235, '_instrument_links', 'field_5656f2422905e'),
(1277, 236, '_edit_last', '1'),
(1278, 236, '_edit_lock', '1450191714:1'),
(1279, 236, 'instrument_bild', ''),
(1280, 236, '_instrument_bild', 'field_5656f1c469a43'),
(1281, 236, 'instrument_unterrichtsschwerpunkte', ''),
(1282, 236, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1283, 236, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nSpiel mit Klavierbegleitung,\r\nMitwirken im Jugendorchester'),
(1284, 236, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1285, 236, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1286, 236, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1287, 236, 'instrument_ergaenzende_facher', ''),
(1288, 236, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1289, 236, 'instrument_by_dozenten', ''),
(1290, 236, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1291, 236, 'instrument_links', '<a class="underlined" href="http://www.akkordeon.de" target="_blank">Akkordeon.de</a>\r\nAuf dieser Seite finden Sie alles was sie schon immer über das Akkordeon wissen wollte. Von der Geschichte, der Entstehung und der Entwicklung. Dazu finden Sie Nachrichten und Veranstaltungstipps rund ums Akkordeon\r\n\r\n<a class="underlined" href="http://www.akkordeon-online.de" target="_blank">Akkordeon-online.de</a>\r\nInformationen über deutsche Akkordeonkomponisten, kostenlose Akkordeonnoten (mit Vorschau, Anmerkungen und zum Anhören als MP3), Links zu weiteren Akkordeonseiten.'),
(1292, 236, '_instrument_links', 'field_5656f2422905e'),
(1293, 237, '_edit_last', '1'),
(1294, 237, '_edit_lock', '1450024830:1'),
(1296, 238, '_wp_attached_file', '2015/12/artsjasper3234.jpg'),
(1297, 238, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:179;s:4:"file";s:26:"2015/12/artsjasper3234.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"artsjasper3234-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1298, 237, 'dozenten_bild', '238'),
(1299, 237, '_dozenten_bild', 'field_5656f0dfab497'),
(1300, 237, 'dozenten_geburtsdatum', ''),
(1301, 237, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1302, 237, 'dozenten_email', ''),
(1303, 237, '_dozenten_email', 'field_5656f0feab498'),
(1304, 237, 'dozent_spielt_instrument', 'a:1:{i:0;s:3:"224";}'),
(1305, 237, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1306, 237, 'dozenten_links', ''),
(1307, 237, '_dozenten_links', 'field_566953f721491'),
(1308, 239, '_wp_attached_file', '2015/12/ralfbachmann1.gif'),
(1309, 239, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:132;s:4:"file";s:25:"2015/12/ralfbachmann1.gif";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1310, 240, '_edit_last', '1'),
(1311, 240, '_edit_lock', '1450025071:1'),
(1312, 240, 'dozenten_bild', '241'),
(1313, 240, '_dozenten_bild', 'field_5656f0dfab497'),
(1314, 240, 'dozenten_geburtsdatum', ''),
(1315, 240, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1316, 240, 'dozenten_email', ''),
(1317, 240, '_dozenten_email', 'field_5656f0feab498'),
(1318, 240, 'dozent_spielt_instrument', 'a:1:{i:0;s:3:"221";}'),
(1319, 240, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1320, 240, 'dozenten_links', ''),
(1321, 240, '_dozenten_links', 'field_566953f721491'),
(1322, 241, '_wp_attached_file', '2015/12/becken.jpg'),
(1323, 241, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:145;s:4:"file";s:18:"2015/12/becken.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1324, 242, '_edit_last', '1'),
(1325, 242, '_edit_lock', '1450025125:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1326, 242, 'dozenten_bild', '243'),
(1327, 242, '_dozenten_bild', 'field_5656f0dfab497'),
(1328, 242, 'dozenten_geburtsdatum', '1979'),
(1329, 242, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1330, 242, 'dozenten_email', ''),
(1331, 242, '_dozenten_email', 'field_5656f0feab498'),
(1332, 242, 'dozent_spielt_instrument', ''),
(1333, 242, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1334, 242, 'dozenten_links', ''),
(1335, 242, '_dozenten_links', 'field_566953f721491'),
(1336, 243, '_wp_attached_file', '2015/12/beckerjudith1060.jpg'),
(1337, 243, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:160;s:4:"file";s:28:"2015/12/beckerjudith1060.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"beckerjudith1060-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1338, 244, '_edit_last', '1'),
(1339, 244, '_edit_lock', '1450025292:1'),
(1340, 245, '_wp_attached_file', '2015/12/rainerbecker02.jpg'),
(1341, 245, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:145;s:4:"file";s:26:"2015/12/rainerbecker02.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1343, 244, 'dozenten_bild', '245'),
(1344, 244, '_dozenten_bild', 'field_5656f0dfab497'),
(1345, 244, 'dozenten_geburtsdatum', '1971'),
(1346, 244, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1347, 244, 'dozenten_email', ''),
(1348, 244, '_dozenten_email', 'field_5656f0feab498'),
(1349, 244, 'dozent_spielt_instrument', 'a:2:{i:0;s:3:"223";i:1;s:3:"225";}'),
(1350, 244, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1351, 244, 'dozenten_links', ''),
(1352, 244, '_dozenten_links', 'field_566953f721491'),
(1353, 246, '_edit_last', '1'),
(1354, 246, '_edit_lock', '1450025367:1'),
(1355, 247, '_wp_attached_file', '2015/12/byermatthias2423.jpg'),
(1356, 247, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:180;s:4:"file";s:28:"2015/12/byermatthias2423.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"byermatthias2423-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1357, 246, 'dozenten_bild', '247'),
(1358, 246, '_dozenten_bild', 'field_5656f0dfab497'),
(1359, 246, 'dozenten_geburtsdatum', '1965'),
(1360, 246, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1361, 246, 'dozenten_email', ''),
(1362, 246, '_dozenten_email', 'field_5656f0feab498'),
(1363, 246, 'dozent_spielt_instrument', 'a:1:{i:0;s:3:"222";}'),
(1364, 246, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1365, 246, 'dozenten_links', '<a class="underlined" href="http://www.matthias-boeyer.de/" target="_blank">Homepage von Matthias Böyer</a>'),
(1366, 246, '_dozenten_links', 'field_566953f721491'),
(1367, 248, '_edit_last', '1'),
(1368, 248, '_edit_lock', '1450025427:1'),
(1369, 249, '_wp_attached_file', '2015/12/boinayjuliette9501.jpg'),
(1370, 249, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:161;s:4:"file";s:30:"2015/12/boinayjuliette9501.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"boinayjuliette9501-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1371, 248, 'dozenten_bild', '249'),
(1372, 248, '_dozenten_bild', 'field_5656f0dfab497'),
(1373, 248, 'dozenten_geburtsdatum', ''),
(1374, 248, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1375, 248, 'dozenten_email', ''),
(1376, 248, '_dozenten_email', 'field_5656f0feab498'),
(1377, 248, 'dozent_spielt_instrument', ''),
(1378, 248, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1379, 248, 'dozenten_links', ''),
(1380, 248, '_dozenten_links', 'field_566953f721491'),
(1381, 250, '_edit_last', '1'),
(1382, 250, '_edit_lock', '1450025483:1'),
(1383, 250, 'dozenten_bild', '251'),
(1384, 250, '_dozenten_bild', 'field_5656f0dfab497'),
(1385, 250, 'dozenten_geburtsdatum', '25.07.1989'),
(1386, 250, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1387, 250, 'dozenten_email', ''),
(1388, 250, '_dozenten_email', 'field_5656f0feab498'),
(1389, 250, 'dozent_spielt_instrument', 'a:1:{i:0;s:2:"97";}'),
(1390, 250, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1391, 250, 'dozenten_links', ''),
(1392, 250, '_dozenten_links', 'field_566953f721491'),
(1393, 251, '_wp_attached_file', '2015/12/bhnnina4201.jpg'),
(1394, 251, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:160;s:4:"file";s:23:"2015/12/bhnnina4201.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"bhnnina4201-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1395, 252, '_edit_last', '1'),
(1396, 252, '_edit_lock', '1450026865:1'),
(1397, 252, 'dozenten_bild', '253'),
(1398, 252, '_dozenten_bild', 'field_5656f0dfab497'),
(1399, 252, 'dozenten_geburtsdatum', ''),
(1400, 252, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1401, 252, 'dozenten_email', ''),
(1402, 252, '_dozenten_email', 'field_5656f0feab498'),
(1403, 252, 'dozent_spielt_instrument', 'a:2:{i:0;s:3:"229";i:1;s:3:"230";}'),
(1404, 252, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1405, 252, 'dozenten_links', '<a href="http://www.bukov.de">www.bukov.de</a>'),
(1406, 252, '_dozenten_links', 'field_566953f721491'),
(1407, 253, '_wp_attached_file', '2015/12/bukovboian7435.jpg'),
(1408, 253, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:110;s:4:"file";s:26:"2015/12/bukovboian7435.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1409, 254, '_edit_last', '1'),
(1410, 254, '_edit_lock', '1450027788:1'),
(1411, 255, '_wp_attached_file', '2015/12/lotharesser.jpg'),
(1412, 255, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:145;s:4:"file";s:23:"2015/12/lotharesser.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1413, 254, 'dozenten_bild', '255'),
(1414, 254, '_dozenten_bild', 'field_5656f0dfab497'),
(1415, 254, 'dozenten_geburtsdatum', '1964, Düren'),
(1416, 254, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1417, 254, 'dozenten_email', ''),
(1418, 254, '_dozenten_email', 'field_5656f0feab498'),
(1419, 254, 'dozent_spielt_instrument', 'a:2:{i:0;s:3:"223";i:1;s:3:"226";}'),
(1420, 254, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1421, 254, 'dozenten_links', '<a class="underlined" href="http://www.theaterdo.de/index.php?tpl=b9f0c4ed8ca2" target="_blank">Dortmunder Philharmoniker</a>'),
(1422, 254, '_dozenten_links', 'field_566953f721491'),
(1423, 256, '_edit_last', '1'),
(1424, 256, '_edit_lock', '1450109911:1'),
(1425, 257, '_wp_attached_file', '2015/12/fabritiusnorbert5557.jpg'),
(1426, 257, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:159;s:4:"file";s:32:"2015/12/fabritiusnorbert5557.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"fabritiusnorbert5557-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1427, 256, 'dozenten_bild', '257'),
(1428, 256, '_dozenten_bild', 'field_5656f0dfab497'),
(1429, 256, 'dozenten_geburtsdatum', '1970, Bensberg'),
(1430, 256, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1431, 256, 'dozenten_email', ''),
(1432, 256, '_dozenten_email', 'field_5656f0feab498'),
(1433, 256, 'dozent_spielt_instrument', 'a:1:{i:0;s:2:"97";}'),
(1434, 256, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1435, 256, 'dozenten_links', ''),
(1436, 256, '_dozenten_links', 'field_566953f721491'),
(1437, 258, '_edit_last', '1'),
(1438, 258, '_edit_lock', '1450027977:1'),
(1439, 259, '_wp_attached_file', '2015/12/glvezleonardo5576.jpg'),
(1440, 259, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:90;s:4:"file";s:29:"2015/12/glvezleonardo5576.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1441, 258, 'dozenten_bild', '259'),
(1442, 258, '_dozenten_bild', 'field_5656f0dfab497'),
(1443, 258, 'dozenten_geburtsdatum', ''),
(1444, 258, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1445, 258, 'dozenten_email', ''),
(1446, 258, '_dozenten_email', 'field_5656f0feab498'),
(1447, 258, 'dozent_spielt_instrument', 'a:1:{i:0;s:3:"234";}'),
(1448, 258, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1449, 258, 'dozenten_links', ''),
(1450, 258, '_dozenten_links', 'field_566953f721491'),
(1451, 260, '_edit_last', '1'),
(1452, 260, '_edit_lock', '1450028043:1'),
(1453, 261, '_wp_attached_file', '2015/12/garlikjasmin8589.jpg'),
(1454, 261, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:160;s:4:"file";s:28:"2015/12/garlikjasmin8589.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"garlikjasmin8589-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1455, 260, 'dozenten_bild', '261'),
(1456, 260, '_dozenten_bild', 'field_5656f0dfab497'),
(1457, 260, 'dozenten_geburtsdatum', '1989'),
(1458, 260, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1459, 260, 'dozenten_email', ''),
(1460, 260, '_dozenten_email', 'field_5656f0feab498'),
(1461, 260, 'dozent_spielt_instrument', 'a:1:{i:0;s:3:"219";}'),
(1462, 260, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1463, 260, 'dozenten_links', ''),
(1464, 260, '_dozenten_links', 'field_566953f721491'),
(1465, 262, '_edit_last', '1'),
(1466, 262, '_edit_lock', '1450028193:1'),
(1467, 263, '_wp_attached_file', '2015/12/haeckerjenny4853.jpg'),
(1468, 263, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:179;s:4:"file";s:28:"2015/12/haeckerjenny4853.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"haeckerjenny4853-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1469, 262, 'dozenten_bild', '263'),
(1470, 262, '_dozenten_bild', 'field_5656f0dfab497'),
(1471, 262, 'dozenten_geburtsdatum', '1978'),
(1472, 262, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1473, 262, 'dozenten_email', ''),
(1474, 262, '_dozenten_email', 'field_5656f0feab498'),
(1475, 262, 'dozent_spielt_instrument', ''),
(1476, 262, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1477, 262, 'dozenten_links', ''),
(1478, 262, '_dozenten_links', 'field_566953f721491'),
(1479, 264, '_edit_last', '1'),
(1480, 264, '_edit_lock', '1450028278:1'),
(1481, 265, '_wp_attached_file', '2015/12/haxhikadrijataulant7810.jpg'),
(1482, 265, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:180;s:4:"file";s:35:"2015/12/haxhikadrijataulant7810.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:35:"haxhikadrijataulant7810-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1483, 264, 'dozenten_bild', '265'),
(1484, 264, '_dozenten_bild', 'field_5656f0dfab497'),
(1485, 264, 'dozenten_geburtsdatum', ''),
(1486, 264, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1487, 264, 'dozenten_email', ''),
(1488, 264, '_dozenten_email', 'field_5656f0feab498'),
(1489, 264, 'dozent_spielt_instrument', 'a:1:{i:0;s:3:"219";}'),
(1490, 264, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1491, 264, 'dozenten_links', ''),
(1492, 264, '_dozenten_links', 'field_566953f721491'),
(1493, 266, '_edit_last', '1'),
(1494, 266, '_edit_lock', '1450029233:1'),
(1495, 267, '_wp_attached_file', '2015/12/heemann.jpg'),
(1496, 267, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:80;s:6:"height";i:116;s:4:"file";s:19:"2015/12/heemann.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1497, 266, 'dozenten_bild', '267'),
(1498, 266, '_dozenten_bild', 'field_5656f0dfab497'),
(1499, 266, 'dozenten_geburtsdatum', ''),
(1500, 266, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1501, 266, 'dozenten_email', ''),
(1502, 266, '_dozenten_email', 'field_5656f0feab498'),
(1503, 266, 'dozent_spielt_instrument', 'a:1:{i:0;s:3:"222";}'),
(1504, 266, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1505, 266, 'dozenten_links', ''),
(1506, 266, '_dozenten_links', 'field_566953f721491'),
(1507, 268, '_edit_last', '1'),
(1508, 268, '_edit_lock', '1450029295:1'),
(1509, 269, '_wp_attached_file', '2015/12/heidbrink_burkhardt.jpg'),
(1510, 269, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:80;s:6:"height";i:100;s:4:"file";s:31:"2015/12/heidbrink_burkhardt.jpg";s:5:"sizes";a:0:{}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1511, 268, 'dozenten_bild', '269'),
(1512, 268, '_dozenten_bild', 'field_5656f0dfab497'),
(1513, 268, 'dozenten_geburtsdatum', ''),
(1514, 268, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1515, 268, 'dozenten_email', ''),
(1516, 268, '_dozenten_email', 'field_5656f0feab498'),
(1517, 268, 'dozent_spielt_instrument', 'a:2:{i:0;s:3:"230";i:1;s:3:"231";}'),
(1518, 268, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1519, 268, 'dozenten_links', ''),
(1520, 268, '_dozenten_links', 'field_566953f721491'),
(1521, 270, '_edit_last', '1'),
(1522, 270, '_edit_lock', '1450029441:1'),
(1523, 271, '_wp_attached_file', '2015/12/hvelmannvanessa2071.jpg'),
(1524, 271, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:120;s:6:"height";i:151;s:4:"file";s:31:"2015/12/hvelmannvanessa2071.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"hvelmannvanessa2071-120x150.jpg";s:5:"width";i:120;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1525, 270, 'dozenten_bild', '271'),
(1526, 270, '_dozenten_bild', 'field_5656f0dfab497') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1527, 270, 'dozenten_geburtsdatum', ''),
(1528, 270, '_dozenten_geburtsdatum', 'field_5656f0adab496'),
(1529, 270, 'dozenten_email', ''),
(1530, 270, '_dozenten_email', 'field_5656f0feab498'),
(1531, 270, 'dozent_spielt_instrument', 'a:1:{i:0;s:3:"219";}'),
(1532, 270, '_dozent_spielt_instrument', 'field_56670063e61c4'),
(1533, 270, 'dozenten_links', '<a class="underlined" href="http://www.ensemble-hoersinn.de/" target="_blank">Ensemble Hörsinn</a>'),
(1534, 270, '_dozenten_links', 'field_566953f721491'),
(1535, 274, '_EventOrigin', 'events-calendar'),
(1536, 274, '_edit_last', '1'),
(1537, 274, '_edit_lock', '1450105498:1'),
(1538, 274, '_EventShowMapLink', ''),
(1539, 274, '_EventShowMap', ''),
(1540, 275, '_VenueOrigin', 'events-calendar'),
(1541, 275, '_EventShowMapLink', ''),
(1542, 275, '_EventShowMap', ''),
(1543, 275, '_VenueVenue', 'Garage'),
(1544, 275, '_VenueAddress', 'Kuhweg 12'),
(1545, 275, '_VenueCity', 'Havixbeck'),
(1546, 275, '_VenueCountry', ''),
(1547, 275, '_VenueProvince', ''),
(1548, 275, '_VenueState', ''),
(1549, 275, '_VenueZip', ''),
(1550, 275, '_VenuePhone', '0800 191919'),
(1551, 275, '_VenueURL', ''),
(1552, 275, '_VenueShowMap', 'true'),
(1553, 275, '_VenueShowMapLink', 'true'),
(1554, 275, '_VenueStateProvince', ''),
(1555, 274, '_EventStartDate', '2015-12-14 15:00:00'),
(1556, 274, '_EventEndDate', '2015-12-14 17:00:00'),
(1557, 274, '_EventStartDateUTC', '2015-12-14 14:00:00'),
(1558, 274, '_EventEndDateUTC', '2015-12-14 16:00:00'),
(1559, 274, '_EventDuration', '7200'),
(1560, 274, '_EventVenueID', '275'),
(1561, 274, '_EventCurrencySymbol', '€'),
(1562, 274, '_EventCurrencyPosition', 'prefix'),
(1563, 274, '_EventCost', '3'),
(1564, 274, '_EventURL', ''),
(1565, 274, '_EventOrganizerID', '0'),
(1566, 274, '_EventTimezone', 'Europe/Berlin'),
(1567, 274, '_EventTimezoneAbbr', 'CET'),
(1568, 282, '_edit_last', '1'),
(1569, 282, 'field_566ee74586157', 'a:11:{s:3:"key";s:19:"field_566ee74586157";s:5:"label";s:4:"Bild";s:4:"name";s:14:"ensembles_bild";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(1570, 282, 'field_566ee78b86158', 'a:14:{s:3:"key";s:19:"field_566ee78b86158";s:5:"label";s:6:"Dozent";s:4:"name";s:16:"ensembles_dozent";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"return_format";s:6:"object";s:9:"post_type";a:1:{i:0;s:8:"dozenten";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(1571, 282, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:9:"ensembles";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(1572, 282, 'position', 'normal'),
(1573, 282, 'layout', 'no_box'),
(1574, 282, 'hide_on_screen', ''),
(1575, 282, '_edit_lock', '1450110447:1'),
(1576, 283, '_edit_last', '1'),
(1577, 283, '_edit_lock', '1450109318:1'),
(1578, 283, 'ensembles_bild', ''),
(1579, 283, '_ensembles_bild', 'field_566ee74586157'),
(1580, 283, 'ensembles_dozent', 'a:1:{i:0;s:3:"256";}'),
(1581, 283, '_ensembles_dozent', 'field_566ee78b86158'),
(1583, 60, 'field_566eea2a32c1c', 'a:14:{s:3:"key";s:19:"field_566eea2a32c1c";s:5:"label";s:8:"Ensemble";s:4:"name";s:17:"dozenten_ensemble";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"return_format";s:6:"object";s:9:"post_type";a:1:{i:0;s:9:"ensembles";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(1584, 60, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:8:"dozenten";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(1585, 256, 'dozenten_ensemble', 'a:1:{i:0;s:3:"283";}'),
(1586, 256, '_dozenten_ensemble', 'field_566eea2a32c1c'),
(1587, 285, '_edit_last', '1'),
(1588, 285, 'field_566eed0307b82', 'a:11:{s:3:"key";s:19:"field_566eed0307b82";s:5:"label";s:4:"Bild";s:4:"name";s:9:"elar_bild";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(1589, 285, 'field_566eed1007b83', 'a:13:{s:3:"key";s:19:"field_566eed1007b83";s:5:"label";s:15:"Unterrichtsform";s:4:"name";s:20:"elar_unterrichtsform";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:11:"Gruppenkurs";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:1:"2";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(1590, 285, 'field_566eed3b07b84', 'a:13:{s:3:"key";s:19:"field_566eed3b07b84";s:5:"label";s:18:"Unterrichtseinheit";s:4:"name";s:23:"elar_unterrichtseinheit";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:1:"1";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(1591, 285, 'field_566eed6c07b85', 'a:14:{s:3:"key";s:19:"field_566eed6c07b85";s:5:"label";s:5:"Alter";s:4:"name";s:10:"elar_alter";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'),
(1593, 285, 'position', 'normal'),
(1594, 285, 'layout', 'no_box'),
(1595, 285, 'hide_on_screen', ''),
(1596, 285, '_edit_lock', '1450191577:1'),
(1597, 285, 'field_566eed8746fd5', 'a:14:{s:3:"key";s:19:"field_566eed8746fd5";s:5:"label";s:6:"Dozent";s:4:"name";s:11:"elar_dozent";s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"return_format";s:6:"object";s:9:"post_type";a:1:{i:0;s:8:"dozenten";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'),
(1599, 286, '_edit_last', '1'),
(1600, 286, '_edit_lock', '1450193489:1'),
(1601, 286, 'elar_bild', '98'),
(1602, 286, '_elar_bild', 'field_566eed0307b82'),
(1603, 286, 'elar_unterrichtsform', 'Gruppenkurs'),
(1604, 286, '_elar_unterrichtsform', 'field_566eed1007b83'),
(1605, 286, 'elar_unterrichtseinheit', '60 Min. wöchentl. über ein Schuljahr'),
(1606, 286, '_elar_unterrichtseinheit', 'field_566eed3b07b84'),
(1607, 286, 'elar_alter', '3 - 4 Jahre'),
(1608, 286, '_elar_alter', 'field_566eed6c07b85'),
(1609, 286, 'elar_dozent', 'a:1:{i:0;s:3:"252";}'),
(1610, 286, '_elar_dozent', 'field_566eed8746fd5'),
(1611, 285, 'field_56701ba3e6e8d', 'a:13:{s:3:"key";s:19:"field_56701ba3e6e8d";s:5:"label";s:16:"Kurzbeschreibung";s:4:"name";s:21:"elar_kurzbeschreibung";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:1:"4";s:10:"formatting";s:2:"br";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(1612, 285, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:19:"elementarausbildung";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(1613, 286, 'elar_kurzbeschreibung', 'Für Kinder im Alter von 3-4 Jahren gibt es ein besonderes Modell mit dem Namen „Die Musikzwerge“, das einen Übergang zwischen der "Musikwiese" und der "Musikalischen Früherziehung" bildet. '),
(1614, 286, '_elar_kurzbeschreibung', 'field_56701ba3e6e8d'),
(1615, 291, '_edit_last', '1'),
(1616, 291, '_edit_lock', '1450189642:1'),
(1617, 291, 'elar_bild', ''),
(1618, 291, '_elar_bild', 'field_566eed0307b82'),
(1619, 291, 'elar_kurzbeschreibung', 'Die Musikwiese ist ein Programm für Kinder zwischen 1 und 3 Jahren. Durch gemeinsames Musizieren wird die Gesamtentwicklung Ihres Kindes positiv unterstützt und die Musik in das Familienleben integriert. Der musik- und bewegungspädagogische Gruppenunterricht vermittelt erste Erlebnisse, Erfahrungen und Fertigkeiten im Umgang mit den Elementen der Musik. '),
(1620, 291, '_elar_kurzbeschreibung', 'field_56701ba3e6e8d'),
(1621, 291, 'elar_unterrichtsform', 'Gruppenkurs'),
(1622, 291, '_elar_unterrichtsform', 'field_566eed1007b83'),
(1623, 291, 'elar_unterrichtseinheit', '45 Min. wöchentl. über ein Schuljahr'),
(1624, 291, '_elar_unterrichtseinheit', 'field_566eed3b07b84'),
(1625, 291, 'elar_alter', '1 - 3 Jahre'),
(1626, 291, '_elar_alter', 'field_566eed6c07b85'),
(1627, 291, 'elar_dozent', ''),
(1628, 291, '_elar_dozent', 'field_566eed8746fd5'),
(1629, 61, 'field_56702b72b3f9e', 'a:12:{s:3:"key";s:19:"field_56702b72b3f9e";s:5:"label";s:9:"Kategorie";s:4:"name";s:20:"instrument_kategorie";s:4:"type";s:6:"select";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:7:"choices";a:6:{s:19:"Holzblasinstrumente";s:19:"Holzblasinstrumente";s:20:"Blechblasinstrumente";s:20:"Blechblasinstrumente";s:17:"Schlaginstrumente";s:17:"Schlaginstrumente";s:17:"Saiteninstrumente";s:17:"Saiteninstrumente";s:17:"Tasteninstrumente";s:17:"Tasteninstrumente";s:20:"Harmonikainstrumente";s:20:"Harmonikainstrumente";}s:13:"default_value";s:0:"";s:10:"allow_null";s:1:"0";s:8:"multiple";s:1:"0";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1630, 61, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:11:"instrumente";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(1631, 236, 'instrument_kategorie', 'Harmonikainstrumente'),
(1632, 236, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1633, 235, 'instrument_kategorie', 'Tasteninstrumente'),
(1634, 235, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1635, 234, 'instrument_kategorie', 'Tasteninstrumente'),
(1636, 234, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1637, 233, 'instrument_kategorie', 'Tasteninstrumente'),
(1638, 233, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1639, 232, 'instrument_kategorie', 'Saiteninstrumente'),
(1640, 232, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1641, 231, 'instrument_kategorie', 'Saiteninstrumente'),
(1642, 231, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1643, 230, 'instrument_kategorie', 'Saiteninstrumente'),
(1644, 230, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1645, 229, 'instrument_kategorie', 'Saiteninstrumente'),
(1646, 229, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1647, 228, 'instrument_kategorie', 'Saiteninstrumente'),
(1648, 228, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1649, 217, 'instrument_kategorie', 'Holzblasinstrumente'),
(1650, 217, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1651, 218, 'instrument_kategorie', 'Holzblasinstrumente'),
(1652, 218, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1653, 219, 'instrument_kategorie', 'Holzblasinstrumente'),
(1654, 219, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1655, 220, 'instrument_kategorie', 'Holzblasinstrumente'),
(1656, 220, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1657, 221, 'instrument_kategorie', 'Holzblasinstrumente'),
(1658, 221, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1659, 222, 'instrument_kategorie', 'Holzblasinstrumente'),
(1660, 222, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1661, 223, 'instrument_kategorie', 'Blechblasinstrumente'),
(1662, 223, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1663, 224, 'instrument_kategorie', 'Blechblasinstrumente'),
(1664, 224, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1665, 225, 'instrument_kategorie', 'Blechblasinstrumente'),
(1666, 225, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1667, 97, 'instrument_kategorie', 'Blechblasinstrumente'),
(1668, 97, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1669, 226, 'instrument_kategorie', 'Blechblasinstrumente'),
(1670, 226, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1671, 227, 'instrument_kategorie', 'Schlaginstrumente'),
(1672, 227, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1673, 292, '_wp_attached_file', '2015/11/orchester_fullscreen.jpg'),
(1674, 292, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2886;s:6:"height";i:1259;s:4:"file";s:32:"2015/11/orchester_fullscreen.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"orchester_fullscreen-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"orchester_fullscreen-300x131.jpg";s:5:"width";i:300;s:6:"height";i:131;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:33:"orchester_fullscreen-1024x447.jpg";s:5:"width";i:1024;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";d:4.5;s:6:"credit";s:0:"";s:6:"camera";s:9:"NIKON D40";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1327006029;s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"36";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:4:"0.02";s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1675, 19, '_thumbnail_id', '292'),
(1676, 295, '_edit_last', '1'),
(1677, 295, '_edit_lock', '1450203401:1'),
(1678, 295, 'instrument_kategorie', 'Harmonikainstrumente'),
(1679, 295, '_instrument_kategorie', 'field_56702b72b3f9e'),
(1680, 295, 'instrument_bild', ''),
(1681, 295, '_instrument_bild', 'field_5656f1c469a43'),
(1682, 295, 'instrument_unterrichtsschwerpunkte', 'aASD'),
(1683, 295, '_instrument_unterrichtsschwerpunkte', 'field_5656f21669a46'),
(1684, 295, 'instrument_unterrichtsform', 'Einzelunterricht,\r\nEnsemblespiel,\r\nSpiel mit Klavierbegleitung,\r\nMitwirken im Jugendorchester'),
(1685, 295, '_instrument_unterrichtsform', 'field_566952391f9a0'),
(1686, 295, 'instrument_unterrichtseinheiten', 'Einzelunterricht 30 min\r\nFörderstufe 45 min'),
(1687, 295, '_instrument_unterrichtseinheiten', 'field_5656f1da69a45'),
(1688, 295, 'instrument_ergaenzende_facher', ''),
(1689, 295, '_instrument_ergaenzende_facher', 'field_566951a61f99f'),
(1690, 295, 'instrument_by_dozenten', 'a:1:{i:0;s:3:"254";}'),
(1691, 295, '_instrument_by_dozenten', 'field_5656f25c2905f'),
(1692, 295, 'instrument_links', ''),
(1693, 295, '_instrument_links', 'field_5656f2422905e'),
(1694, 295, '_wp_trash_meta_status', 'publish'),
(1695, 295, '_wp_trash_meta_time', '1450203551'),
(1696, 25, '_wp_page_template', 'default') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=310 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2015-10-22 09:58:38', '2015-10-22 07:58:38', 'Willkommen zur deutschen Version von WordPress. Dies ist der erste Beitrag. Du kannst ihn bearbeiten oder löschen. Und dann starte mit dem Schreiben!', 'Hallo Welt!', '', 'publish', 'open', 'open', '', 'hallo-welt', '', '', '2015-11-26 12:00:55', '2015-11-26 11:00:55', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=1', 0, 'post', '', 1),
(4, 1, '2015-11-08 23:36:50', '2015-11-08 22:36:50', '', 'Startseite', '', 'publish', 'closed', 'closed', '', 'startseite', '', '', '2015-12-15 19:31:02', '2015-12-15 18:31:02', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=4', 1, 'page', '', 0),
(5, 1, '2015-11-08 23:36:50', '2015-11-08 22:36:50', '<!-- Main hero unit for a primary marketing message or call to action -->\r\n<div class="hero-unit">\r\n	<h1>Hello, world!</h1>\r\n	<p>This is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.</p>\r\n	<p><a class="btn btn-primary btn-large">Learn more &raquo;</a></p>\r\n</div>\r\n\r\n<!-- Example row of columns -->\r\n<div class="row">\r\n	<div class="span4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="span4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="span4">\r\n		<h2>Heading</h2>\r\n		<p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-11-08 23:36:50', '2015-11-08 22:36:50', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/08/4-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2015-11-09 17:40:18', '2015-11-09 16:40:18', '<!-- Main hero unit for a primary marketing message or call to action -->\r\n<div class="hero-unit">\r\n	<h1>Hello, world!</h1>\r\n	<p>This is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.</p>\r\n	<p><a class="btn btn-primary btn-large">Learn more &raquo;</a></p>\r\n</div>\r\n\r\n<!-- Example row of columns -->\r\n<div class="row">\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="span4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="span4">\r\n		<h2>Heading</h2>\r\n		<p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-11-09 17:40:18', '2015-11-09 16:40:18', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/4-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2015-11-11 16:43:26', '2015-11-11 15:43:26', '<!-- Main hero unit for a primary marketing message or call to action -->\n<div class="jumbotron text-justify">\n<div> <h1>Hello, world!</h1></div>\nThis is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.\n\n<a class="btn btn-primary btn-large">Learn more »</a>\n\n</div>\n<!-- Example row of columns -->\n<div class="row">\n<div class="col-lg-4 text-justify">\n<h2>Heading</h2>\nDonec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.\n\n<a class="btn" href="#">View details »</a>\n\n</div>\n<div class="col-lg-4">\n<h2>Heading</h2>\nDonec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.\n\n<a class="btn" href="#">View details »</a>\n\n</div>\n<div class="col-lg-4">\n<h2>Heading</h2>\nDonec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.\n\n<a class="btn" href="#">View details »</a>\n\n</div>\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-autosave-v1', '', '', '2015-11-11 16:43:26', '2015-11-11 15:43:26', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/4-autosave-v1/', 0, 'revision', '', 0),
(9, 1, '2015-11-09 17:40:37', '2015-11-09 16:40:37', '<!-- Main hero unit for a primary marketing message or call to action -->\r\n<div class="hero-unit">\r\n	<h1>Hello, world!</h1>\r\n	<p>This is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.</p>\r\n	<p><a class="btn btn-primary btn-large">Learn more &raquo;</a></p>\r\n</div>\r\n\r\n<!-- Example row of columns -->\r\n<div class="row">\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-11-09 17:40:37', '2015-11-09 16:40:37', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/4-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2015-11-09 17:42:20', '2015-11-09 16:42:20', '<!-- Main hero unit for a primary marketing message or call to action -->\r\n<div class="jumbotron">\r\n	<h1>Hello, world!</h1>\r\n	<p>This is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.</p>\r\n	<p><a class="btn btn-primary btn-large">Learn more &raquo;</a></p>\r\n</div>\r\n\r\n<!-- Example row of columns -->\r\n<div class="row">\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-11-09 17:42:20', '2015-11-09 16:42:20', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/4-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2015-11-09 17:48:12', '2015-11-09 16:48:12', '<!-- Main hero unit for a primary marketing message or call to action -->\r\n<div class="jumbotron text-justify">\r\n	<h1>Hello, world!</h1>\r\n	<p>This is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.</p>\r\n	<p><a class="btn btn-primary btn-large">Learn more &raquo;</a></p>\r\n</div>\r\n\r\n<!-- Example row of columns -->\r\n<div class="row">\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-11-09 17:48:12', '2015-11-09 16:48:12', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/4-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2015-11-09 17:48:31', '2015-11-09 16:48:31', '<!-- Main hero unit for a primary marketing message or call to action -->\r\n<div class="jumbotron text-justify">\r\n	<h1>Hello, world!</h1>\r\n	<p>This is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.</p>\r\n	<p><a class="btn btn-primary btn-large">Learn more &raquo;</a></p>\r\n</div>\r\n\r\n<!-- Example row of columns -->\r\n<div class="row">\r\n	<div class="col-lg-4 text-justify">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n	<div class="col-lg-4">\r\n		<h2>Heading</h2>\r\n		<p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>\r\n		<p><a class="btn" href="#">View details &raquo;</a></p>\r\n	</div>\r\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-11-09 17:48:31', '2015-11-09 16:48:31', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/4-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2015-11-09 17:49:54', '2015-11-09 16:49:54', '', 'Aktuelles', '', 'publish', 'closed', 'closed', '', 'aktuelles', '', '', '2015-12-11 16:12:24', '2015-12-11 15:12:24', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=15', 2, 'page', '', 0),
(16, 1, '2015-11-09 17:49:54', '2015-11-09 16:49:54', '', 'Aktuelles', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2015-11-09 17:49:54', '2015-11-09 16:49:54', '', 15, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/15-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2015-11-09 17:50:03', '2015-11-09 16:50:03', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam quis risus eget urna mollis ornare vel eu leo. Curabitur blandit tempus porttitor. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean lacinia bibendum nulla sed consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Etiam porta sem malesuada magna mollis euismod. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla vitae elit libero, a pharetra augue. Vestibulum id ligula porta felis euismod semper. Sed posuere consectetur est at lobortis.', 'Verein', '', 'publish', 'closed', 'closed', '', 'verein', '', '', '2015-12-11 16:13:54', '2015-12-11 15:13:54', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=17', 4, 'page', '', 0),
(18, 1, '2015-11-09 17:50:03', '2015-11-09 16:50:03', '', 'Der Verein', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2015-11-09 17:50:03', '2015-11-09 16:50:03', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2015-11-09 17:50:14', '2015-11-09 16:50:14', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:', 'Musikschule', '', 'publish', 'closed', 'closed', '', 'musikschule', '', '', '2015-12-15 17:45:30', '2015-12-15 16:45:30', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=19', 6, 'page', '', 0),
(20, 1, '2015-11-09 17:50:14', '2015-11-09 16:50:14', '', 'Musikschule', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2015-11-09 17:50:14', '2015-11-09 16:50:14', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2015-11-09 17:50:22', '2015-11-09 16:50:22', '', 'Orchester', '', 'publish', 'closed', 'closed', '', 'orchester', '', '', '2015-12-11 16:13:54', '2015-12-11 15:13:54', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=21', 5, 'page', '', 0),
(22, 1, '2015-11-09 17:50:22', '2015-11-09 16:50:22', '', 'Orchester', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2015-11-09 17:50:22', '2015-11-09 16:50:22', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2015-11-09 17:50:35', '2015-11-09 16:50:35', '', 'Organisation', '', 'trash', 'closed', 'closed', '', 'organisation', '', '', '2015-12-11 16:23:06', '2015-12-11 15:23:06', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=23', 7, 'page', '', 0),
(24, 1, '2015-11-09 17:50:35', '2015-11-09 16:50:35', '', 'Organisation', '', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2015-11-09 17:50:35', '2015-11-09 16:50:35', '', 23, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/23-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2015-11-09 17:50:51', '2015-11-09 16:50:51', '<div class="row text-center">\r\n<div class="col-lg-12">\r\njugendorchester havixbeck\r\nTRÄGER DER\r\nmusikschule havixbeck\r\n\r\nbellegarde platz\r\n48329 havixbeck\r\n\r\ntel. 02507 - 2285\r\nfax 02507 - 4075\r\n\r\nmail@musikschule-havixbeck.de\r\n</div>\r\n</div>\r\n<div class="container">\r\n<div class="row">\r\n<div class="col-lg-6">\r\n[wpgmza id="1"] \r\n</div>\r\n</div>\r\n</div>\r\n\r\n[si-contact-form form=\'1\']', 'Kontakt', '', 'publish', 'closed', 'closed', '', 'kontakt', '', '', '2016-01-07 09:34:53', '2016-01-07 08:34:53', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=25', 8, 'page', '', 0),
(26, 1, '2015-11-09 17:50:51', '2015-11-09 16:50:51', '', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2015-11-09 17:50:51', '2015-11-09 16:50:51', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/2015/11/09/25-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2015-11-09 18:34:46', '2015-11-09 17:34:46', 'Anlässlich des Herbstkonzerts erschien in den Westfälischen Nachrichten folgender Artikel:\r\n„Aus Havixbeck kommt die Musik“, sollte es heißen. Im original Egerländer Schunkelhit von Ernst Mosch ist zwar von Böhmen die Rede, aber wer am Samstagabend das Herbstkonzert des Jugendorchesters besucht hat, weiß, dass diese Strophe problemlos so umgedichtet werden kann. Was Dirigent Rainer Becker und sein Orchester da vor ausverkauftem Haus präsentierten, war ein Hörerlebnis auf absolut höchstem Niveau.\r\n\r\nZum Weiterlesen und zum Betrachten der Fotostrecke:\r\n<a href="http://www.wn.de/Muensterland/Kreis-Coesfeld/Havixbeck/2155988-Jugendorchester-Havixbeck-Grandioses-Musikerlebnis" target="_blank">http://www.wn.de/Muensterland/Kreis-Coesfeld/Havixbeck/2155988-Jugendorchester-Havixbeck-Grandioses-Musikerlebnis</a>', 'Pressereaktionen zum Herbstkonzert: "Grandioses Musikereignis"', '', 'publish', 'open', 'open', '', 'pressereaktionen-zum-herbstkonzert-grandioses-musikereignis', '', '', '2015-11-09 18:49:32', '2015-11-09 17:49:32', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=28', 0, 'post', '', 0),
(29, 1, '2015-11-09 18:34:46', '2015-11-09 17:34:46', 'Anlässlich des Herbstkonzerts erschien in den Westfälischen Nachrichten folgender Artikel:\r\n„Aus Havixbeck kommt die Musik“, sollte es heißen. Im original Egerländer Schunkelhit von Ernst Mosch ist zwar von Böhmen die Rede, aber wer am Samstagabend das Herbstkonzert des Jugendorchesters besucht hat, weiß, dass diese Strophe problemlos so umgedichtet werden kann. Was Dirigent Rainer Becker und sein Orchester da vor ausverkauftem Haus präsentierten, war ein Hörerlebnis auf absolut höchstem Niveau.\r\n\r\nZum Weiterlesen und zum Betrachten der Fotostrecke:\r\n<a href="http://www.wn.de/Muensterland/Kreis-Coesfeld/Havixbeck/2155988-Jugendorchester-Havixbeck-Grandioses-Musikerlebnis" target="_blank">http://www.wn.de/Muensterland/Kreis-Coesfeld/Havixbeck/2155988-Jugendorchester-Havixbeck-Grandioses-Musikerlebnis</a>', 'Pressereaktionen zum Herbstkonzert: "Grandioses Musikereignis"', '', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2015-11-09 18:34:46', '2015-11-09 17:34:46', '', 28, 'http://localhost/musikschule-wp-theme/wordpress/28-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2015-11-09 18:49:27', '2015-11-09 17:49:27', '', 'post_thumbnail', '', 'inherit', 'open', 'closed', '', 'post_thumbnail', '', '', '2015-11-09 18:49:27', '2015-11-09 17:49:27', '', 28, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/11/post_thumbnail1.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2015-11-10 13:38:49', '2015-11-10 12:38:49', '<!-- Main hero unit for a primary marketing message or call to action -->\r\n<div class="jumbotron text-justify">\r\n<div>[smartslider2 slider="1"]</div>\r\n<h1>Hello, world!</h1>\r\nThis is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.\r\n\r\n<a class="btn btn-primary btn-large">Learn more »</a>\r\n\r\n</div>\r\n<!-- Example row of columns -->\r\n<div class="row">\r\n<div class="col-lg-4 text-justify">\r\n<h2>Heading</h2>\r\nDonec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.\r\n\r\n<a class="btn" href="#">View details »</a>\r\n\r\n</div>\r\n<div class="col-lg-4">\r\n<h2>Heading</h2>\r\nDonec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.\r\n\r\n<a class="btn" href="#">View details »</a>\r\n\r\n</div>\r\n<div class="col-lg-4">\r\n<h2>Heading</h2>\r\nDonec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.\r\n\r\n<a class="btn" href="#">View details »</a>\r\n\r\n</div>\r\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-11-10 13:38:49', '2015-11-10 12:38:49', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/4-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2015-11-10 13:40:07', '2015-11-10 12:40:07', '', 'Musikschule-Klick', '', 'inherit', 'open', 'closed', '', 'musikschule-klick', '', '', '2015-11-10 13:40:07', '2015-11-10 12:40:07', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/11/Musikschule-Klick.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2015-11-11 16:30:47', '2015-11-11 15:30:47', '<!-- Main hero unit for a primary marketing message or call to action -->\r\n<div class="jumbotron text-justify">\r\n<div>Hello, world!</div>\r\nThis is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.\r\n\r\n<a class="btn btn-primary btn-large">Learn more »</a>\r\n\r\n</div>\r\n<!-- Example row of columns -->\r\n<div class="row">\r\n<div class="col-lg-4 text-justify">\r\n<h2>Heading</h2>\r\nDonec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.\r\n\r\n<a class="btn" href="#">View details »</a>\r\n\r\n</div>\r\n<div class="col-lg-4">\r\n<h2>Heading</h2>\r\nDonec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.\r\n\r\n<a class="btn" href="#">View details »</a>\r\n\r\n</div>\r\n<div class="col-lg-4">\r\n<h2>Heading</h2>\r\nDonec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.\r\n\r\n<a class="btn" href="#">View details »</a>\r\n\r\n</div>\r\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-11-11 16:30:47', '2015-11-11 15:30:47', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/4-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2015-11-11 16:43:44', '2015-11-11 15:43:44', '<!-- Main hero unit for a primary marketing message or call to action -->\r\n<div class="jumbotron text-justify">\r\n<div> <h1>Hello, world!</h1></div>\r\nThis is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.\r\n\r\n<a class="btn btn-primary btn-large">Learn more »</a>\r\n\r\n</div>\r\n<!-- Example row of columns -->\r\n<div class="row">\r\n<div class="col-lg-4 text-justify">\r\n<h2>Heading</h2>\r\nDonec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.\r\n\r\n<a class="btn" href="#">View details »</a>\r\n\r\n</div>\r\n<div class="col-lg-4">\r\n<h2>Heading</h2>\r\nDonec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.\r\n\r\n<a class="btn" href="#">View details »</a>\r\n\r\n</div>\r\n<div class="col-lg-4">\r\n<h2>Heading</h2>\r\nDonec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.\r\n\r\n<a class="btn" href="#">View details »</a>\r\n\r\n</div>\r\n</div>', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-11-11 16:43:44', '2015-11-11 15:43:44', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/4-revision-v1/', 0, 'revision', '', 0),
(44, 1, '2015-11-12 10:30:20', '2015-11-12 09:30:20', '', 'Besetzung', '', 'publish', 'closed', 'closed', '', 'besetzung', '', '', '2015-11-12 10:30:30', '2015-11-12 09:30:30', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=44', 0, 'page', '', 0),
(45, 1, '2015-11-12 10:30:20', '2015-11-12 09:30:20', '', 'Besetzung', '', 'inherit', 'closed', 'closed', '', '44-revision-v1', '', '', '2015-11-12 10:30:20', '2015-11-12 09:30:20', '', 44, 'http://localhost/musikschule-wp-theme/wordpress/44-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2015-11-13 16:47:37', '2015-11-13 15:47:37', 'Aasdasdasdasdas', 'Der Verein', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2015-11-13 16:47:37', '2015-11-13 15:47:37', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/17-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2015-11-13 16:48:07', '2015-11-13 15:48:07', '<p style="text-align: center;"><h1>Aasdasdasdasdas</h1></p>', 'Der Verein', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2015-11-13 16:48:07', '2015-11-13 15:48:07', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/17-revision-v1/', 0, 'revision', '', 0),
(49, 1, '2015-11-13 16:52:18', '2015-11-13 15:52:18', '<h1>Aasdasdasdasdas</h1>\r\n&nbsp;\r\n\r\nCum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam quis risus eget urna mollis ornare vel eu leo. Curabitur blandit tempus porttitor. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean lacinia bibendum nulla sed consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Etiam porta sem malesuada magna mollis euismod. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla vitae elit libero, a pharetra augue. Vestibulum id ligula porta felis euismod semper. Sed posuere consectetur est at lobortis.', 'Der Verein', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2015-11-13 16:52:18', '2015-11-13 15:52:18', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/17-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2015-11-13 16:53:29', '2015-11-13 15:53:29', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam quis risus eget urna mollis ornare vel eu leo. Curabitur blandit tempus porttitor. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean lacinia bibendum nulla sed consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Etiam porta sem malesuada magna mollis euismod. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla vitae elit libero, a pharetra augue. Vestibulum id ligula porta felis euismod semper. Sed posuere consectetur est at lobortis.', 'Gebühren', '', 'publish', 'closed', 'closed', '', 'gebuehren', '', '', '2015-12-11 17:16:59', '2015-12-11 16:16:59', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=50', 2, 'page', '', 0),
(51, 1, '2015-11-13 16:53:29', '2015-11-13 15:53:29', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam quis risus eget urna mollis ornare vel eu leo. Curabitur blandit tempus porttitor. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean lacinia bibendum nulla sed consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Etiam porta sem malesuada magna mollis euismod. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla vitae elit libero, a pharetra augue. Vestibulum id ligula porta felis euismod semper. Sed posuere consectetur est at lobortis.', 'Gebühren', '', 'inherit', 'closed', 'closed', '', '50-revision-v1', '', '', '2015-11-13 16:53:29', '2015-11-13 15:53:29', '', 50, 'http://localhost/musikschule-wp-theme/wordpress/50-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2015-11-13 17:00:14', '2015-11-13 16:00:14', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam quis risus eget urna mollis ornare vel eu leo. Curabitur blandit tempus porttitor. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean lacinia bibendum nulla sed consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Etiam porta sem malesuada magna mollis euismod. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla vitae elit libero, a pharetra augue. Vestibulum id ligula porta felis euismod semper. Sed posuere consectetur est at lobortis.', 'Der Verein', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2015-11-13 17:00:14', '2015-11-13 16:00:14', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/17-revision-v1/', 0, 'revision', '', 0),
(53, 1, '2015-11-13 17:17:55', '2015-11-13 16:17:55', 'Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nullam quis risus eget urna mollis ornare vel eu leo. Curabitur blandit tempus porttitor. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Aenean lacinia bibendum nulla sed consectetur. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Sed posuere consectetur est at lobortis. Etiam porta sem malesuada magna mollis euismod. Etiam porta sem malesuada magna mollis euismod. Aenean lacinia bibendum nulla sed consectetur. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla vitae elit libero, a pharetra augue. Vestibulum id ligula porta felis euismod semper. Sed posuere consectetur est at lobortis.', 'Verein', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2015-11-13 17:17:55', '2015-11-13 16:17:55', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/17-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2015-11-26 12:00:55', '2015-11-26 11:00:55', 'Willkommen zur deutschen Version von WordPress. Dies ist der erste Beitrag. Du kannst ihn bearbeiten oder löschen. Und dann starte mit dem Schreiben!', 'Hallo Welt!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2015-11-26 12:00:55', '2015-11-26 11:00:55', '', 1, 'http://localhost/musikschule-wp-theme/wordpress/1-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2015-11-26 12:47:57', '2015-11-26 11:47:57', '', 'Dozenten', '', 'publish', 'closed', 'closed', '', 'acf_dozenten', '', '', '2015-12-14 17:11:54', '2015-12-14 16:11:54', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=acf&#038;p=60', 0, 'acf', '', 0),
(61, 1, '2015-11-26 12:54:14', '2015-11-26 11:54:14', '', 'Instrument', '', 'publish', 'closed', 'closed', '', 'acf_instrument', '', '', '2015-12-15 16:03:47', '2015-12-15 15:03:47', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=acf&#038;p=61', 0, 'acf', '', 0),
(63, 1, '2015-12-08 09:22:56', '2015-12-08 08:22:56', '[ecs-list-events]', 'Aktuelle Termine', '', 'publish', 'closed', 'closed', '', 'aktuelle-termine', '', '', '2015-12-11 16:13:54', '2015-12-11 15:13:54', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=63', 3, 'page', '', 0),
(64, 1, '2015-12-08 09:22:56', '2015-12-08 08:22:56', '[ecs-list-events]', 'Aktuelle Termine', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2015-12-08 09:22:56', '2015-12-08 08:22:56', '', 63, 'http://localhost/musikschule-wp-theme/wordpress/63-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2015-12-08 09:35:58', '2015-12-08 08:35:58', 'Ja und sonst so?', 'Musikfest', '', 'publish', 'open', 'closed', '', 'musikfest', '', '', '2015-12-08 09:35:58', '2015-12-08 08:35:58', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=tribe_events&#038;p=65', 0, 'tribe_events', '', 0),
(66, 1, '2015-12-08 09:35:58', '2015-12-08 08:35:58', '', 'Unnamed Veranstalter', '', 'publish', 'closed', 'closed', '', 'unnamed-veranstalter', '', '', '2015-12-08 09:35:58', '2015-12-08 08:35:58', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/veranstalter/unnamed-veranstalter/', 0, 'tribe_organizer', '', 0),
(67, 1, '2015-12-08 09:35:58', '2015-12-08 08:35:58', '', 'JUH', '', 'publish', 'closed', 'closed', '', 'juh', '', '', '2015-12-08 09:35:58', '2015-12-08 08:35:58', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/veranstaltungsort/juh/', 0, 'tribe_venue', '', 0),
(68, 1, '2015-12-08 13:35:30', '2015-12-08 12:35:30', 'asdaklsjdlkasjdjaskdlasjdl', 'Test', '', 'publish', 'open', 'closed', '', 'test', '', '', '2015-12-08 13:35:30', '2015-12-08 12:35:30', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=tribe_events&#038;p=68', 0, 'tribe_events', '', 0),
(69, 1, '2015-12-08 13:42:24', '2015-12-08 12:42:24', '', 'Termine', '', 'publish', 'closed', 'closed', '', 'termine', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=69', 3, 'nav_menu_item', '', 0),
(70, 1, '2015-12-08 14:29:32', '2015-12-08 13:29:32', 'Vestibulum id ligula porta felis euismod semper. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Cras mattis consectetur purus sit amet fermentum. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Etiam porta sem malesuada magna mollis euismod. Nullam quis risus eget urna mollis ornare vel eu leo. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.\r\n\r\nCurabitur blandit tempus porttitor. Vestibulum id ligula porta felis euismod semper. Donec sed odio dui. Maecenas sed diam eget risus varius blandit sit amet non magna.\r\n\r\nVestibulum id ligula porta felis euismod semper. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed posuere consectetur est at lobortis. Donec id elit non mi porta gravida at eget metus.\r\n\r\nDonec ullamcorper nulla non metus auctor fringilla. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Nulla vitae elit libero, a pharetra augue. Vestibulum id ligula porta felis euismod semper. Aenean lacinia bibendum nulla sed consectetur.', 'Anmeldung', '', 'publish', 'closed', 'closed', '', 'anmeldung', '', '', '2015-12-11 17:00:51', '2015-12-11 16:00:51', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=70', 1, 'page', '', 0),
(71, 1, '2015-12-08 14:29:32', '2015-12-08 13:29:32', '', 'Anmeldung', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2015-12-08 14:29:32', '2015-12-08 13:29:32', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/70-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2015-12-08 14:31:04', '2015-12-08 13:31:04', 'An der Musikschule Havixbeck kann man über 20 Instrumente erlernen - Von Klassik bis Jazz, vom Klavier bis zur E-Gitarre, findet sich hier Traditionsreiches wie Modernes unter einem Dach. Stöbern Sie in unserem umfangreichen Angebot und informieren Sie sich zusätzlich über Unterrichtsformen, ergänzende Lehrveranstaltungen und Dozenten.', 'Instrumente', '', 'publish', 'closed', 'closed', '', 'instrumente', '', '', '2015-12-14 15:40:37', '2015-12-14 14:40:37', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=72', 1, 'page', '', 0),
(73, 1, '2015-12-08 14:31:04', '2015-12-08 13:31:04', '', 'Instrumente', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-12-08 14:31:04', '2015-12-08 13:31:04', '', 72, 'http://localhost/musikschule-wp-theme/wordpress/72-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2015-12-08 14:31:45', '2015-12-08 13:31:45', 'AASD', 'Trompete', '', 'trash', 'closed', 'closed', '', 'trompete', '', '', '2015-12-08 17:18:16', '2015-12-08 16:18:16', '', 72, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=74', 0, 'page', '', 0),
(75, 1, '2015-12-08 14:31:45', '2015-12-08 13:31:45', '', 'Trompete', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2015-12-08 14:31:45', '2015-12-08 13:31:45', '', 74, 'http://localhost/musikschule-wp-theme/wordpress/74-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2015-12-08 14:33:01', '2015-12-08 13:33:01', '<p><?php the_field(\'field_name\'); ?></p>', 'Trompete', '', 'inherit', 'closed', 'closed', '', '74-autosave-v1', '', '', '2015-12-08 14:33:01', '2015-12-08 13:33:01', '', 74, 'http://localhost/musikschule-wp-theme/wordpress/74-autosave-v1/', 0, 'revision', '', 0),
(77, 1, '2015-12-08 14:33:39', '2015-12-08 13:33:39', '<p><?php the_field(\'name\'); ?></p>', 'Trompete', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2015-12-08 14:33:39', '2015-12-08 13:33:39', '', 74, 'http://localhost/musikschule-wp-theme/wordpress/74-revision-v1/', 0, 'revision', '', 0),
(78, 1, '2015-12-08 14:46:23', '2015-12-08 13:46:23', 'AASD', 'Trompete', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2015-12-08 14:46:23', '2015-12-08 13:46:23', '', 74, 'http://localhost/musikschule-wp-theme/wordpress/74-revision-v1/', 0, 'revision', '', 0),
(84, 1, '2015-12-08 16:17:25', '2015-12-08 15:17:25', 'asddd', 'Instrumente', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-12-08 16:17:25', '2015-12-08 15:17:25', '', 72, 'http://localhost/musikschule-wp-theme/wordpress/72-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2015-12-08 16:49:52', '2015-12-08 15:49:52', 'Ralf Bachmann kam schon sehr früh in der musikalischen Früherziehung, im Blockflötenensemble und im „Günztaler Jugendchor“ mit Musik in Berührung.\r\n\r\nMit 12 Jahren bekam er seinen ersten Schlagzeugunterricht und wurde Schlagzeuger in der Blaskapelle Ronsberg. Die folgenden Jahre standen voll im Zeichen der Blasmusik: Egerländer, Böhmisch-Mährisch und die Sinfonische Blasorchesterliteratur. Er war in dieser Zeit in nahezu allen größeren Ensembles und Orchester im Umkreis tätig. In dieser Zeit nahm er auch an mehreren Wettbewerben und Funk- und Fernsehaufnahmen teil.\r\nNach seiner Lehre zum Industriemechaniker, entschied er sich 2001 für das Studium des klassischen Schlagwerks in Münster bei Armin Weigert und Stephan Frohleycks und in Berlin bei Prof. Punto, welches er 2006 mit der Gesamtnote 1,2 erfolgreich beendete.\r\n\r\nWährend seines Studiums nahm er an zahlreichen Meisterkursen teil, unter anderem bei Terry Bozzio, Rick Latham, Luis Conte, Mamady Keita, Hakim Ludin, Dudu Tucci u. Udo Dahmen. Im Sommer 2002 war er aktiver Teilnehmer bei einem Marimbaworkshop bei Prof. Peter Sadlo und Prof. Peter Prommel.\r\n\r\n2003-2005 war er Praktikant im Sinfonieorchester Münster und danach ständige Aushilfe bei den Sinfonieorchestern der Städte Münster, Hagen, Osnabrück, der Nordwestdeutschen Philharmonie Herford und Neue Philharmonie Westfalen. Er konzentriet sich seitdem zunehmend auf das klassische Orchesterschlagwerk.\r\n\r\nIm Frühjahr 2008 war spielte er als Solist das „Konzert für Schlagzeug und Orchester“ von Andre Jolivet mit der „Alten Philharmonie Münster“.\r\n\r\nSeit einigen Jahren unterrichtet Ralf Bachmann an verschiedenen Musikschulen, spielt in verschiedenen Kammerbesetzungen und leitet das Percussionensemble der Musikschule Havixbeck.', 'Ralf Bachmann', '', 'publish', 'closed', 'closed', '', 'ralf-bachmann', '', '', '2015-12-13 17:45:50', '2015-12-13 16:45:50', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=93', 0, 'dozenten', '', 0),
(95, 1, '2015-12-08 17:01:10', '2015-12-08 16:01:10', 'ALLE AUF EINEN BLICK!\r\n\r\nMit über 60 Lehrpersonen bietet die Musikschule Havixbeck qualifizierten Unterricht in allen Musiksparten. Sie sind bei uns also in besten musikalischen Händen ...\r\nHier finden Sie alle DozentInnen der Musikschule Havixbeck in alphabetischer Reihenfolge. Klicken Sie auf den Namen, um zur betreffenden Lehrperson zu gelangen.', 'Dozenten', '', 'publish', 'closed', 'closed', '', 'dozenten', '', '', '2015-12-11 18:19:57', '2015-12-11 17:19:57', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=95', 3, 'page', '', 0),
(96, 1, '2015-12-08 17:01:10', '2015-12-08 16:01:10', 'ALLE AUF EINEN BLICK!\r\n\r\nMit über 60 Lehrpersonen bietet die Musikschule Havixbeck qualifizierten Unterricht in allen Musiksparten. Sie sind bei uns also in besten musikalischen Händen ...\r\nHier finden Sie alle DozentInnen der Musikschule Havixbeck in alphabetischer Reihenfolge. Klicken Sie auf den Namen, um zur betreffenden Lehrperson zu gelangen.', 'Dozenten', '', 'inherit', 'closed', 'closed', '', '95-revision-v1', '', '', '2015-12-08 17:01:10', '2015-12-08 16:01:10', '', 95, 'http://localhost/musikschule-wp-theme/wordpress/95-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2015-12-08 17:09:35', '2015-12-08 16:09:35', 'Geschichtlich entstammt die Trompete den Tierhörnern. Diese wurden in archaischen Zeiten ausgehöhlt und die Spitze abgesägt. Wenn man sie am Mund ansetzt und hineinbläst beginnen die Lippen des Bläsers zu schwingen. Das Horn verstärkt diese Schwingungen. Mit einiger Übung lassen sich die Schwingungen modulieren. Dadurch entstehen höhere und tiefere Töne. In der Bronzezeit wurden die Tierhörner erstmals aus Metall nachgebaut. Wegen ihrer Schalleigenschaften wurde sie schon in der Antike als Signalinstrument eingesetzt. Die Trompete kann strahlend hell, aber auch weich und samtig klingen. Die Trompete findet man heute in nahezu allen Musikstilen und in vielen Besetzungen. Virtuose Trompetenmusik komponierten u. a. Arcangelo Corelli, Antonio Vivaldi und Georg Friedrich Händel. Im Jazz hat die Trompete seit den 20er Jahren ihren Stellenwert mit Jazztrompetern wie Louis Armstrong, Dizzy Gillespie und Miles Davis.', 'Trompete', '', 'publish', 'closed', 'closed', '', 'trompete', '', '', '2015-12-15 16:35:00', '2015-12-15 15:35:00', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=97', 0, 'instrumente', '', 0),
(98, 1, '2015-12-08 17:09:17', '2015-12-08 16:09:17', '', 'trompete', '', 'inherit', 'open', 'closed', '', 'trompete-2', '', '', '2015-12-08 17:09:17', '2015-12-08 16:09:17', '', 97, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/trompete.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 1, '2015-12-08 17:12:42', '2015-12-08 16:12:42', 'INSTRUMENTALUNTERICHT\r\n\r\nAn der Musikschule Havixbeck kann man über 20 Instrumente erlernen - Von Klassik bis Jazz, vom Klavier bis zur E-Gitarre, findet sich hier Traditionsreiches wie Modernes unter einem Dach. Stöbern Sie in unserem umfangreichen Angebot und informieren Sie sich zusätzlich über Unterrichtsformen, ergänzende Lehrveranstaltungen und Dozenten.', 'Instrumente', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-12-08 17:12:42', '2015-12-08 16:12:42', '', 72, 'http://localhost/musikschule-wp-theme/wordpress/72-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(105, 1, '2015-12-10 11:30:43', '2015-12-10 10:30:43', 'Ralf Bachmann (, Obergünzburg im Allgäu) kam schon sehr früh in der musikalischen Früherziehung, im Blockflötenensemble und im „Günztaler Jugendchor“ mit Musik in Berührung.\n\nMit 12 Jahren bekam er seinen ersten Schlagzeugunterricht und wurde Schlagzeuger in der Blaskapelle Ronsberg. Die folgenden Jahre standen voll im Zeichen der Blasmusik: Egerländer, Böhmisch-Mährisch und die Sinfonische Blasorchesterliteratur. Er war in dieser Zeit in nahezu allen größeren Ensembles und Orchester im Umkreis tätig. In dieser Zeit nahm er auch an mehreren Wettbewerben und Funk- und Fernsehaufnahmen teil.\nNach seiner Lehre zum Industriemechaniker, entschied er sich 2001 für das Studium des klassischen Schlagwerks in Münster bei Armin Weigert und Stephan Frohleycks und in Berlin bei Prof. Punto, welches er 2006 mit der Gesamtnote 1,2 erfolgreich beendete.\n\nWährend seines Studiums nahm er an zahlreichen Meisterkursen teil, unter anderem bei Terry Bozzio, Rick Latham, Luis Conte, Mamady Keita, Hakim Ludin, Dudu Tucci u. Udo Dahmen. Im Sommer 2002 war er aktiver Teilnehmer bei einem Marimbaworkshop bei Prof. Peter Sadlo und Prof. Peter Prommel.\n\n2003-2005 war er Praktikant im Sinfonieorchester Münster und danach ständige Aushilfe bei den Sinfonieorchestern der Städte Münster, Hagen, Osnabrück, der Nordwestdeutschen Philharmonie Herford und Neue Philharmonie Westfalen. Er konzentriet sich seitdem zunehmend auf das klassische Orchesterschlagwerk.\n\nIm Frühjahr 2008 war spielte er als Solist das „Konzert für Schlagzeug und Orchester“ von Andre Jolivet mit der „Alten Philharmonie Münster“.\n\nSeit einigen Jahren unterrichtet Ralf Bachmann an verschiedenen Musikschulen, spielt in verschiedenen Kammerbesetzungen und leitet das Percussionensemble der Musikschule Havixbeck.', 'Ralf Bachmann', '', 'inherit', 'closed', 'closed', '', '93-autosave-v1', '', '', '2015-12-10 11:30:43', '2015-12-10 10:30:43', '', 93, 'http://localhost/musikschule-wp-theme/wordpress/93-autosave-v1/', 0, 'revision', '', 0),
(106, 1, '2015-12-11 16:15:21', '2015-12-11 15:15:21', '', 'Archiv', '', 'publish', 'closed', 'closed', '', 'archiv', '', '', '2015-12-11 16:15:21', '2015-12-11 15:15:21', '', 15, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=106', 0, 'page', '', 0),
(107, 1, '2015-12-11 16:15:21', '2015-12-11 15:15:21', '', 'Archiv', '', 'inherit', 'closed', 'closed', '', '106-revision-v1', '', '', '2015-12-11 16:15:21', '2015-12-11 15:15:21', '', 106, 'http://localhost/musikschule-wp-theme/wordpress/106-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2015-12-11 16:15:40', '2015-12-11 15:15:40', '', 'Organisation', '', 'publish', 'closed', 'closed', '', 'organisation', '', '', '2015-12-11 16:15:40', '2015-12-11 15:15:40', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=108', 0, 'page', '', 0),
(109, 1, '2015-12-11 16:15:40', '2015-12-11 15:15:40', '', 'Organisation', '', 'inherit', 'closed', 'closed', '', '108-revision-v1', '', '', '2015-12-11 16:15:40', '2015-12-11 15:15:40', '', 108, 'http://localhost/musikschule-wp-theme/wordpress/108-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2015-12-11 16:16:00', '2015-12-11 15:16:00', '', 'Förderer', '', 'publish', 'closed', 'closed', '', 'foerderer', '', '', '2015-12-11 16:16:00', '2015-12-11 15:16:00', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=110', 0, 'page', '', 0),
(111, 1, '2015-12-11 16:16:00', '2015-12-11 15:16:00', '', 'Förderer', '', 'inherit', 'closed', 'closed', '', '110-revision-v1', '', '', '2015-12-11 16:16:00', '2015-12-11 15:16:00', '', 110, 'http://localhost/musikschule-wp-theme/wordpress/110-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2015-12-11 16:16:37', '2015-12-11 15:16:37', '', 'Dirigent', '', 'publish', 'closed', 'closed', '', 'dirigent', '', '', '2015-12-11 16:16:37', '2015-12-11 15:16:37', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=112', 0, 'page', '', 0),
(113, 1, '2015-12-11 16:16:37', '2015-12-11 15:16:37', '', 'Dirigent', '', 'inherit', 'closed', 'closed', '', '112-revision-v1', '', '', '2015-12-11 16:16:37', '2015-12-11 15:16:37', '', 112, 'http://localhost/musikschule-wp-theme/wordpress/112-revision-v1/', 0, 'revision', '', 0),
(114, 1, '2015-12-11 16:17:00', '2015-12-11 15:17:00', '', 'Ehemalige Dirigenten', '', 'publish', 'closed', 'closed', '', 'ehemalige-dirigenten', '', '', '2015-12-11 16:17:00', '2015-12-11 15:17:00', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=114', 0, 'page', '', 0),
(115, 1, '2015-12-11 16:17:00', '2015-12-11 15:17:00', '', 'Ehemalige Dirigenten', '', 'inherit', 'closed', 'closed', '', '114-revision-v1', '', '', '2015-12-11 16:17:00', '2015-12-11 15:17:00', '', 114, 'http://localhost/musikschule-wp-theme/wordpress/114-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2015-12-11 16:17:19', '2015-12-11 15:17:19', '', 'Tonträger', '', 'publish', 'closed', 'closed', '', 'tontraeger', '', '', '2015-12-11 16:17:19', '2015-12-11 15:17:19', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=116', 0, 'page', '', 0),
(117, 1, '2015-12-11 16:17:19', '2015-12-11 15:17:19', '', 'Tonträger', '', 'inherit', 'closed', 'closed', '', '116-revision-v1', '', '', '2015-12-11 16:17:19', '2015-12-11 15:17:19', '', 116, 'http://localhost/musikschule-wp-theme/wordpress/116-revision-v1/', 0, 'revision', '', 0),
(118, 1, '2015-12-11 16:17:32', '2015-12-11 15:17:32', '', 'Presse', '', 'publish', 'closed', 'closed', '', 'presse', '', '', '2015-12-11 16:17:32', '2015-12-11 15:17:32', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=118', 0, 'page', '', 0),
(119, 1, '2015-12-11 16:17:32', '2015-12-11 15:17:32', '', 'Presse', '', 'inherit', 'closed', 'closed', '', '118-revision-v1', '', '', '2015-12-11 16:17:32', '2015-12-11 15:17:32', '', 118, 'http://localhost/musikschule-wp-theme/wordpress/118-revision-v1/', 0, 'revision', '', 0),
(120, 1, '2015-12-11 16:17:46', '2015-12-11 15:17:46', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:\r\n\r\n<a>Musikalische Elementarausbildung</a>\r\n<a>Instrumentalunterricht</a>\r\n<a>Vokalunterricht</a>\r\n<a>Ensemble- und Orchesterspiel</a>\r\n<a>Fachübergreifende musikalische Fortbildung</a>\r\n\r\n<hr />\r\n\r\n<strong>Fragen zum Angebot?</strong>\r\n\r\n&nbsp;\r\n\r\nSollten Sie weitere Informationen zu unserem Angebot benötigen, <a>kontaktieren</a> Sie uns bitte oder besuchen Sie uns doch einfach in der Musikschule bei einer unserer regelmäßig stattfindenden <a>Schnupperstunden</a>.', 'Angebot', '', 'publish', 'closed', 'closed', '', 'angebot', '', '', '2015-12-11 18:50:08', '2015-12-11 17:50:08', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=120', 0, 'page', '', 0),
(121, 1, '2015-12-11 16:17:46', '2015-12-11 15:17:46', '', 'Angebot', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2015-12-11 16:17:46', '2015-12-11 15:17:46', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/120-revision-v1/', 0, 'revision', '', 0),
(122, 1, '2015-12-11 16:18:43', '2015-12-11 15:18:43', '<strong>Ist Gesangunterricht das Richtige für mich?</strong>\r\n\r\nJeder Mensch kann singen. Singen ist die ursprünglichste Form des Musizierens und gleichzeitig auch die unmittelbarste, denn: Der Körper selbst ist das Instrument. Im Gegensatz zu allen anderen Musikinstrumenten kann jeder Mensch dieses "Instrument" von Natur aus mehr oder weniger gut "spielen".\r\n\r\nWer sich die Frage stellt, ob er Gesangunterricht nehmen soll, muss sich gleichzeitig fragen, zu welchem Ziel er damit gelangen will. Wer zu Hause gerne singt - ob in der Badewanne, zur CD oder einfach so braucht nicht unbedingt Gesangunterricht.\r\n\r\nAber das Unterrichtsangebot im Bereich Gesang richtet sich nicht nur an diejenigen, die sich auf ein Berufsstudium als Sänger vorbereiten wollen, sondern an alle, die lernen wollen, ihre eigenen stimmlichen und musikalischen Ausdrucksmöglichkeiten auf- und auszubauen oder zu verbessern, um dann z.B. im Kammerchor oder in einem Vokalensemble mitzusingen, oder an die, die Singen einfach aus Spaß erlernen möchten, um sich im persönlichen Ausdruck zu fördern: Gesang ist auf jeden Fall das Richtige zur Stimmbildung und -pflege für alle musisch und musikalisch Interessierten.\r\n\r\nDie Musikschule Havixbeck bietet das Fach sowohl im Gruppen- als auch im Einzelunterricht an:\r\n<strong>Einzelunterricht</strong>\r\n<p class="eingerueckt"><a class="underlined" href="http://jugendorchester-havixbeck.de/musikschule/sologesang.php">Sologesang</a></p>\r\n<strong>Ensemble / Gruppenunterricht</strong>\r\n<p class="eingerueckt">Young Voices</p>\r\n<a class="underlined" href="http://jugendorchester-havixbeck.de/musikschule/kontaktmain.php">Kontaktieren</a> Sie uns bitte für weitere Informationen zum Fachangebot Gesang.', 'Gesang', '', 'publish', 'closed', 'closed', '', 'gesang', '', '', '2015-12-11 18:51:55', '2015-12-11 17:51:55', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=122', 10, 'page', '', 0),
(123, 1, '2015-12-11 16:18:43', '2015-12-11 15:18:43', '', 'Gesang', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2015-12-11 16:18:43', '2015-12-11 15:18:43', '', 122, 'http://localhost/musikschule-wp-theme/wordpress/122-revision-v1/', 0, 'revision', '', 0),
(124, 1, '2015-12-11 16:19:14', '2015-12-11 15:19:14', '', 'Ensembles', '', 'publish', 'closed', 'closed', '', 'ensembles', '', '', '2015-12-11 18:19:38', '2015-12-11 17:19:38', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=124', 6, 'page', '', 0),
(125, 1, '2015-12-11 16:19:14', '2015-12-11 15:19:14', '', 'Ensembles', '', 'inherit', 'closed', 'closed', '', '124-revision-v1', '', '', '2015-12-11 16:19:14', '2015-12-11 15:19:14', '', 124, 'http://localhost/musikschule-wp-theme/wordpress/124-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2015-12-11 16:19:33', '2015-12-11 15:19:33', 'Kinder sind neugierig und versuchen, die Welt zu erfahren. Dazu gehört auch die Klangwelt. Unmusikalische Kinder gibt es nicht! Sie besitzen eine ursprüngliche Musikalität. Für Kinder sind Stimme und Bewegung Möglichkeiten des Ausdrucks und der Mitteilung. Die nachfolgenden Veranstaltungen dienen dazu, diese Grundbedürfnisse zu stärken.', 'Elementarausbildung', '', 'publish', 'closed', 'closed', '', 'elementarausbildung', '', '', '2015-12-15 14:57:17', '2015-12-15 13:57:17', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=126', 5, 'page', '', 0),
(127, 1, '2015-12-11 16:19:33', '2015-12-11 15:19:33', '', 'Elementarausbildung', '', 'inherit', 'closed', 'closed', '', '126-revision-v1', '', '', '2015-12-11 16:19:33', '2015-12-11 15:19:33', '', 126, 'http://localhost/musikschule-wp-theme/wordpress/126-revision-v1/', 0, 'revision', '', 0),
(128, 1, '2015-12-11 16:20:05', '2015-12-11 15:20:05', '', 'Fachübergreifend', '', 'publish', 'closed', 'closed', '', 'fachuebergreifend', '', '', '2015-12-11 18:19:38', '2015-12-11 17:19:38', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=128', 8, 'page', '', 0),
(129, 1, '2015-12-11 16:20:05', '2015-12-11 15:20:05', '', 'Fachübergreifend', '', 'inherit', 'closed', 'closed', '', '128-revision-v1', '', '', '2015-12-11 16:20:05', '2015-12-11 15:20:05', '', 128, 'http://localhost/musikschule-wp-theme/wordpress/128-revision-v1/', 0, 'revision', '', 0),
(130, 1, '2015-12-11 16:20:23', '2015-12-11 15:20:23', 'Die Einrichtung einer Musikklasse zum Schuljahr 2006/07 an der Anne-Frank-Gesamtschule ist beschlossen. Die Musikklasse wird stark mit der Musikschule kooperieren und bietet den teilnehmenden Schülerinnen und Schüler der 5. Klasse an, ein Instrument im regulären Schulunterricht über zwei Schuljahre zu erlernen. Dazu gehören die Instrumente Querflöte, Klarinette, Saxophon, Trompete, Horn, Euphonium und Tuba. Die musikalische Leitung der Bläserklasse wird die Gesamtschullehrerin Stefanie Aehlen übernehmen. Weiterhin werden sechs Instrumentalpädagogen den Unterricht der Bläserklasse mitgestalten. Für den Unterricht stellt die Musikschule Havixbeck ihre Räumlichkeiten und die Mietinstrumente zu Verfügung.\r\n\r\n<strong>Weitere Infos:</strong>\r\n\r\n• In der 5. und 6. Jahrgangsstufe wird eine BläserKlasse im  Klassenverband gegründet.\r\n• Der reguläre Musikunterricht wird zum Erlernen eines Orchesterinstrumentes genutzt.\r\n• Wir wollen eine gezielte Kooperation mit der Anne-Frank-Gesamtschule eingehen.\r\n\r\n<strong>Instrumente</strong>\r\n\r\n• Werden gemietet: im Mietpreis ist die Grundausstattung sowie eine Instrumentenversicherung inbegriffen.\r\n\r\n<strong>Wie kommen die Kinder zu ihren Instrumenten?</strong>\r\n\r\n• Ausprobieren aller Instrumente\r\n• Wahl der 3 Wunschinstrumente\r\n• Entscheidung bis zum nächsten Tag\r\n   \r\n4 Stunden Musikunterricht bestehen aus:\r\n– 2 Stunden Orchesterunterricht im Klassenverband\r\n– 1 Stunde Instrumentalunterricht in Kleingruppen\r\n– 1 Stunde Theorieunterricht im Klassenverband ohne Instrumente\r\n\r\n<strong>Räume</strong>\r\n\r\n• Die Musikschule stellt für den Orchesterunterricht im Klassenverband den großen Probenraum zur Verfügung.\r\n• Für den Instrumentalunterricht in Kleingruppen stellt die Musikschule entsprechende Übungsräume zur Verfügung.\r\n• Der Theorieunterricht findet in den Musikräumen der AFG statt.\r\n\r\n<strong>Wer unterrichtet was?</strong>\r\n\r\n• Orchesterunterricht: Frau Kneip, Herr Weißer\r\n• Instrumentalunterricht in Kleingruppen: 6 zusätzliche Instrumentalpädagogen\r\n• Theorieunterricht:  Frau Kneip, Herr Weißer\r\n\r\n<strong>Lehrwerke</strong>\r\n\r\n• Für den Instrumentalunterricht wird das Yamaha-Lehrwerk „Essential Elements“ angeschafft.\r\n• Für den Theorieunterricht wird das D1-Heft für Blasorchester angeschafft.\r\nDie Schülerinnen und Schüler haben die Möglichkeit, die theoretische D1-Zertifikatsprüfung abzulegen\r\n\r\n<strong>Finanzierung</strong>\r\n\r\n• Monatliche Elternbeiträge für die Instrumentenmiete und anteilig für die Bezahlung der \r\n\r\n<strong>Instrumentalpädagogen</strong>\r\n\r\n• Einmalige Kosten für Notenmaterial', 'Bläserklasse', '', 'publish', 'closed', 'closed', '', 'blaeserklasse', '', '', '2015-12-14 16:41:44', '2015-12-14 15:41:44', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=130', 2, 'page', '', 0),
(131, 1, '2015-12-11 16:20:23', '2015-12-11 15:20:23', '', 'Bläserklasse', '', 'inherit', 'closed', 'closed', '', '130-revision-v1', '', '', '2015-12-11 16:20:23', '2015-12-11 15:20:23', '', 130, 'http://localhost/musikschule-wp-theme/wordpress/130-revision-v1/', 0, 'revision', '', 0),
(132, 1, '2015-12-11 16:20:40', '2015-12-11 15:20:40', '', 'Fächer A-Z', '', 'publish', 'closed', 'closed', '', 'faecher-a-z', '', '', '2015-12-11 18:19:38', '2015-12-11 17:19:38', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=132', 7, 'page', '', 0),
(133, 1, '2015-12-11 16:20:40', '2015-12-11 15:20:40', '', 'Fächer A-Z', '', 'inherit', 'closed', 'closed', '', '132-revision-v1', '', '', '2015-12-11 16:20:40', '2015-12-11 15:20:40', '', 132, 'http://localhost/musikschule-wp-theme/wordpress/132-revision-v1/', 0, 'revision', '', 0),
(134, 1, '2015-12-11 16:20:56', '2015-12-11 15:20:56', 'ALLE AUF EINEN BLICK!\r\n\r\nMit über 60 Lehrpersonen bietet die Musikschule Havixbeck qualifizierten Unterricht in allen Musiksparten. Sie sind bei uns also in besten musikalischen Händen ...\r\nHier finden Sie alle DozentInnen der Musikschule Havixbeck in alphabetischer Reihenfolge. Klicken Sie auf den Namen, um zur betreffenden Lehrperson zu gelangen.', 'Dozenten A-Z', '', 'publish', 'closed', 'closed', '', 'dozenten-a-z', '', '', '2015-12-11 18:37:59', '2015-12-11 17:37:59', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=134', 4, 'page', '', 0),
(135, 1, '2015-12-11 16:20:56', '2015-12-11 15:20:56', '', 'Dozenten A-Z', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2015-12-11 16:20:56', '2015-12-11 15:20:56', '', 134, 'http://localhost/musikschule-wp-theme/wordpress/134-revision-v1/', 0, 'revision', '', 0),
(136, 1, '2015-12-11 16:21:12', '2015-12-11 15:21:12', '', 'Förderstufe', '', 'publish', 'closed', 'closed', '', 'foerderstufe', '', '', '2015-12-11 18:19:38', '2015-12-11 17:19:38', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=136', 9, 'page', '', 0),
(137, 1, '2015-12-11 16:21:12', '2015-12-11 15:21:12', '', 'Förderstufe', '', 'inherit', 'closed', 'closed', '', '136-revision-v1', '', '', '2015-12-11 16:21:12', '2015-12-11 15:21:12', '', 136, 'http://localhost/musikschule-wp-theme/wordpress/136-revision-v1/', 0, 'revision', '', 0),
(138, 1, '2015-12-11 16:22:00', '2015-12-11 15:22:00', '', 'Unterrichtsvereinbarungen', '', 'publish', 'closed', 'closed', '', 'unterrichtsvereinbarungen', '', '', '2015-12-11 17:16:54', '2015-12-11 16:16:54', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=138', 0, 'page', '', 0),
(139, 1, '2015-12-11 16:22:00', '2015-12-11 15:22:00', '', 'Unterrichtsvereinbarungen', '', 'inherit', 'closed', 'closed', '', '138-revision-v1', '', '', '2015-12-11 16:22:00', '2015-12-11 15:22:00', '', 138, 'http://localhost/musikschule-wp-theme/wordpress/138-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2015-12-11 16:22:15', '2015-12-11 15:22:15', '', 'Mietinstrumente', '', 'publish', 'closed', 'closed', '', 'mietinstrumente', '', '', '2015-12-11 17:16:50', '2015-12-11 16:16:50', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=140', 0, 'page', '', 0),
(141, 1, '2015-12-11 16:22:15', '2015-12-11 15:22:15', '', 'Mietinstrumente', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2015-12-11 16:22:15', '2015-12-11 15:22:15', '', 140, 'http://localhost/musikschule-wp-theme/wordpress/140-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(142, 1, '2015-12-11 16:22:28', '2015-12-11 15:22:28', '', 'Formulare', '', 'publish', 'closed', 'closed', '', 'formulare', '', '', '2015-12-11 17:16:46', '2015-12-11 16:16:46', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?page_id=142', 0, 'page', '', 0),
(143, 1, '2015-12-11 16:22:28', '2015-12-11 15:22:28', '', 'Formulare', '', 'inherit', 'closed', 'closed', '', '142-revision-v1', '', '', '2015-12-11 16:22:28', '2015-12-11 15:22:28', '', 142, 'http://localhost/musikschule-wp-theme/wordpress/142-revision-v1/', 0, 'revision', '', 0),
(144, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=144', 1, 'nav_menu_item', '', 0),
(145, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=145', 1, 'nav_menu_item', '', 0),
(146, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=146', 1, 'nav_menu_item', '', 0),
(147, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=147', 1, 'nav_menu_item', '', 0),
(148, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=148', 1, 'nav_menu_item', '', 0),
(149, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=149', 1, 'nav_menu_item', '', 0),
(150, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=150', 1, 'nav_menu_item', '', 0),
(151, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=151', 1, 'nav_menu_item', '', 0),
(152, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=152', 1, 'nav_menu_item', '', 0),
(153, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=153', 1, 'nav_menu_item', '', 0),
(154, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=154', 1, 'nav_menu_item', '', 0),
(155, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/?p=155', 1, 'nav_menu_item', '', 0),
(156, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?p=156', 1, 'nav_menu_item', '', 0),
(157, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?p=157', 1, 'nav_menu_item', '', 0),
(158, 1, '2015-12-11 16:25:10', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:25:10', '0000-00-00 00:00:00', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?p=158', 1, 'nav_menu_item', '', 0),
(159, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '159', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=159', 1, 'nav_menu_item', '', 0),
(160, 1, '2015-12-11 16:28:01', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-11 16:28:01', '0000-00-00 00:00:00', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=160', 1, 'nav_menu_item', '', 0),
(161, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '161', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=161', 2, 'nav_menu_item', '', 0),
(162, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '162', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 15, 'http://localhost/musikschule-wp-theme/wordpress/?p=162', 5, 'nav_menu_item', '', 0),
(163, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '163', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=163', 4, 'nav_menu_item', '', 0),
(164, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '164', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=164', 6, 'nav_menu_item', '', 0),
(165, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '165', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/?p=165', 7, 'nav_menu_item', '', 0),
(166, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '166', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 17, 'http://localhost/musikschule-wp-theme/wordpress/?p=166', 8, 'nav_menu_item', '', 0),
(167, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '167', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=167', 9, 'nav_menu_item', '', 0),
(168, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '168', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?p=168', 10, 'nav_menu_item', '', 0),
(169, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '169', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?p=169', 11, 'nav_menu_item', '', 0),
(170, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '170', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?p=170', 12, 'nav_menu_item', '', 0),
(171, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '171', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?p=171', 13, 'nav_menu_item', '', 0),
(172, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '172', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 21, 'http://localhost/musikschule-wp-theme/wordpress/?p=172', 14, 'nav_menu_item', '', 0),
(173, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '173', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=173', 15, 'nav_menu_item', '', 0),
(174, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '174', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/?p=174', 16, 'nav_menu_item', '', 0),
(175, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '175', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=175', 19, 'nav_menu_item', '', 0),
(176, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '176', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=176', 24, 'nav_menu_item', '', 0),
(177, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '177', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=177', 21, 'nav_menu_item', '', 0),
(178, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '178', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=178', 20, 'nav_menu_item', '', 0),
(179, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '179', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=179', 25, 'nav_menu_item', '', 0),
(180, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '180', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=180', 22, 'nav_menu_item', '', 0),
(181, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '181', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=181', 26, 'nav_menu_item', '', 0),
(182, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '182', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=182', 18, 'nav_menu_item', '', 0),
(183, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '183', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/?p=183', 27, 'nav_menu_item', '', 0),
(184, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '184', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=184', 28, 'nav_menu_item', '', 0),
(185, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '185', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=185', 29, 'nav_menu_item', '', 0),
(186, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '186', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=186', 30, 'nav_menu_item', '', 0),
(187, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '187', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=187', 31, 'nav_menu_item', '', 0),
(188, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '188', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/?p=188', 23, 'nav_menu_item', '', 0),
(189, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '189', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/?p=189', 17, 'nav_menu_item', '', 0),
(190, 1, '2015-12-11 16:30:15', '2015-12-11 15:30:15', ' ', '', '', 'publish', 'closed', 'closed', '', '190', '', '', '2015-12-11 16:30:15', '2015-12-11 15:30:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=190', 32, 'nav_menu_item', '', 0),
(191, 1, '2015-12-11 16:36:08', '2015-12-11 15:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '191', '', '', '2015-12-11 16:36:08', '2015-12-11 15:36:08', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=191', 6, 'nav_menu_item', '', 0),
(192, 1, '2015-12-11 16:36:08', '2015-12-11 15:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '192', '', '', '2015-12-11 16:36:08', '2015-12-11 15:36:08', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=192', 8, 'nav_menu_item', '', 0),
(193, 1, '2015-12-11 16:36:08', '2015-12-11 15:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '193', '', '', '2015-12-11 16:36:08', '2015-12-11 15:36:08', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=193', 4, 'nav_menu_item', '', 0),
(194, 1, '2015-12-11 16:36:08', '2015-12-11 15:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '194', '', '', '2015-12-11 16:36:08', '2015-12-11 15:36:08', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=194', 3, 'nav_menu_item', '', 0),
(195, 1, '2015-12-11 16:36:08', '2015-12-11 15:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '195', '', '', '2015-12-11 16:36:08', '2015-12-11 15:36:08', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=195', 9, 'nav_menu_item', '', 0),
(196, 1, '2015-12-11 16:36:08', '2015-12-11 15:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '196', '', '', '2015-12-11 16:36:08', '2015-12-11 15:36:08', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=196', 5, 'nav_menu_item', '', 0),
(197, 1, '2015-12-11 16:36:08', '2015-12-11 15:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '197', '', '', '2015-12-11 16:36:08', '2015-12-11 15:36:08', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=197', 7, 'nav_menu_item', '', 0),
(198, 1, '2015-12-11 16:36:08', '2015-12-11 15:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '198', '', '', '2015-12-11 16:36:08', '2015-12-11 15:36:08', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/?p=198', 2, 'nav_menu_item', '', 0),
(199, 1, '2015-12-11 16:36:08', '2015-12-11 15:36:08', ' ', '', '', 'publish', 'closed', 'closed', '', '199', '', '', '2015-12-11 16:36:08', '2015-12-11 15:36:08', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/?p=199', 1, 'nav_menu_item', '', 0),
(200, 1, '2015-12-11 16:41:07', '2015-12-11 15:41:07', ' ', '', '', 'publish', 'closed', 'closed', '', '200', '', '', '2015-12-11 16:41:07', '2015-12-11 15:41:07', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=200', 1, 'nav_menu_item', '', 0),
(201, 1, '2015-12-11 16:41:07', '2015-12-11 15:41:07', ' ', '', '', 'publish', 'closed', 'closed', '', '201', '', '', '2015-12-11 16:41:07', '2015-12-11 15:41:07', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=201', 2, 'nav_menu_item', '', 0),
(202, 1, '2015-12-11 16:41:07', '2015-12-11 15:41:07', ' ', '', '', 'publish', 'closed', 'closed', '', '202', '', '', '2015-12-11 16:41:07', '2015-12-11 15:41:07', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=202', 3, 'nav_menu_item', '', 0),
(203, 1, '2015-12-11 16:41:07', '2015-12-11 15:41:07', ' ', '', '', 'publish', 'closed', 'closed', '', '203', '', '', '2015-12-11 16:41:07', '2015-12-11 15:41:07', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/?p=203', 4, 'nav_menu_item', '', 0),
(204, 1, '2015-12-11 17:00:51', '2015-12-11 16:00:51', 'Vestibulum id ligula porta felis euismod semper. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Cras mattis consectetur purus sit amet fermentum. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Etiam porta sem malesuada magna mollis euismod. Nullam quis risus eget urna mollis ornare vel eu leo. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor.\r\n\r\nCurabitur blandit tempus porttitor. Vestibulum id ligula porta felis euismod semper. Donec sed odio dui. Maecenas sed diam eget risus varius blandit sit amet non magna.\r\n\r\nVestibulum id ligula porta felis euismod semper. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed posuere consectetur est at lobortis. Donec id elit non mi porta gravida at eget metus.\r\n\r\nDonec ullamcorper nulla non metus auctor fringilla. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Nulla vitae elit libero, a pharetra augue. Vestibulum id ligula porta felis euismod semper. Aenean lacinia bibendum nulla sed consectetur.', 'Anmeldung', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2015-12-11 17:00:51', '2015-12-11 16:00:51', '', 70, 'http://localhost/musikschule-wp-theme/wordpress/70-revision-v1/', 0, 'revision', '', 0),
(205, 1, '2015-12-11 18:37:59', '2015-12-11 17:37:59', 'ALLE AUF EINEN BLICK!\r\n\r\nMit über 60 Lehrpersonen bietet die Musikschule Havixbeck qualifizierten Unterricht in allen Musiksparten. Sie sind bei uns also in besten musikalischen Händen ...\r\nHier finden Sie alle DozentInnen der Musikschule Havixbeck in alphabetischer Reihenfolge. Klicken Sie auf den Namen, um zur betreffenden Lehrperson zu gelangen.', 'Dozenten A-Z', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2015-12-11 18:37:59', '2015-12-11 17:37:59', '', 134, 'http://localhost/musikschule-wp-theme/wordpress/134-revision-v1/', 0, 'revision', '', 0),
(206, 1, '2015-12-11 18:45:04', '2015-12-11 17:45:04', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:', 'Angebot', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2015-12-11 18:45:04', '2015-12-11 17:45:04', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/120-revision-v1/', 0, 'revision', '', 0),
(207, 1, '2015-12-11 18:45:47', '2015-12-11 17:45:47', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:\r\n\r\n<a href="">Musikalische Elementarausbildung</a>\r\nInstrumentalunterricht\r\nVokalunterricht\r\nEnsemble- und Orchesterspiel\r\nFachübergreifende musikalische Fortbildung\r\n\r\nFragen zum Angebot? \r\n\r\nSollten Sie weitere Informationen zu unserem Angebot benötigen, kontaktieren Sie uns bitte oder besuchen Sie uns doch einfach in der Musikschule bei einer unserer regelmäßig stattfindenden Schnupperstunden - die nächste findet schon am 27. November 2015 um 16:30 Uhr statt.', 'Angebot', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2015-12-11 18:45:47', '2015-12-11 17:45:47', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/120-revision-v1/', 0, 'revision', '', 0),
(208, 1, '2015-12-11 18:46:14', '2015-12-11 17:46:14', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\n\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\n\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:\n\n<a href="">Musikalische Elementarausbildung</a>\n<a href="">Instrumentalunterricht</a>\n<a href="">Vokalunterricht</a>\n<a href="">Ensemble- und Orchesterspiel</a>\n<a href="">Fachübergreifende musikalische Fortbildung</a>\n\nFragen zum Angebot? \n\nSollten Sie weitere Informationen zu unserem Angebot benötigen, kontaktieren Sie uns bitte oder besuchen Sie uns doch einfach in der Musikschule bei einer unserer regelmäßig stattfindenden Schnupperstunden - die nächste findet schon am 27. November 2015 um 16:30 Uhr statt.', 'Angebot', '', 'inherit', 'closed', 'closed', '', '120-autosave-v1', '', '', '2015-12-11 18:46:14', '2015-12-11 17:46:14', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/120-autosave-v1/', 0, 'revision', '', 0),
(209, 1, '2015-12-11 18:46:15', '2015-12-11 17:46:15', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:\r\n\r\n<a href="">Musikalische Elementarausbildung</a>\r\n<a href="">Instrumentalunterricht</a>\r\n<a href="">Vokalunterricht</a>\r\n<a href="">Ensemble- und Orchesterspiel</a>\r\n<a href="">Fachübergreifende musikalische Fortbildung</a>\r\n\r\nFragen zum Angebot? \r\n\r\nSollten Sie weitere Informationen zu unserem Angebot benötigen, kontaktieren Sie uns bitte oder besuchen Sie uns doch einfach in der Musikschule bei einer unserer regelmäßig stattfindenden Schnupperstunden - die nächste findet schon am 27. November 2015 um 16:30 Uhr statt.', 'Angebot', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2015-12-11 18:46:15', '2015-12-11 17:46:15', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/120-revision-v1/', 0, 'revision', '', 0),
(210, 1, '2015-12-11 18:47:14', '2015-12-11 17:47:14', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:\r\n\r\n<a href="">Musikalische Elementarausbildung</a>\r\n<a href="">Instrumentalunterricht</a>\r\n<a href="">Vokalunterricht</a>\r\n<a href="">Ensemble- und Orchesterspiel</a>\r\n<a href="">Fachübergreifende musikalische Fortbildung</a>\r\n\r\nFragen zum Angebot? \r\n\r\nSollten Sie weitere Informationen zu unserem Angebot benötigen, <a href="">kontaktieren</a> Sie uns bitte oder besuchen Sie uns doch einfach in der Musikschule bei einer unserer regelmäßig stattfindenden <a href="">Schnupperstunden</a>.', 'Angebot', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2015-12-11 18:47:14', '2015-12-11 17:47:14', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/120-revision-v1/', 0, 'revision', '', 0),
(211, 1, '2015-12-11 18:47:45', '2015-12-11 17:47:45', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:\r\n\r\n<a>Musikalische Elementarausbildung</a>\r\n<a>Instrumentalunterricht</a>\r\n<a>Vokalunterricht</a>\r\n<a>Ensemble- und Orchesterspiel</a>\r\n<a>Fachübergreifende musikalische Fortbildung</a>\r\n\r\n<strong>Fragen zum Angebot?</strong>\r\n\r\nSollten Sie weitere Informationen zu unserem Angebot benötigen, <a>kontaktieren</a> Sie uns bitte oder besuchen Sie uns doch einfach in der Musikschule bei einer unserer regelmäßig stattfindenden <a>Schnupperstunden</a>.', 'Angebot', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2015-12-11 18:47:45', '2015-12-11 17:47:45', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/120-revision-v1/', 0, 'revision', '', 0),
(212, 1, '2015-12-11 18:49:14', '2015-12-11 17:49:14', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:\r\n\r\n<a>Musikalische Elementarausbildung</a>\r\n<a>Instrumentalunterricht</a>\r\n<a>Vokalunterricht</a>\r\n<a>Ensemble- und Orchesterspiel</a>\r\n<a>Fachübergreifende musikalische Fortbildung</a>\r\n\r\n<hr />\r\n\r\n&nbsp;\r\n\r\n<strong>Fragen zum Angebot?</strong>\r\n\r\n&nbsp;\r\n\r\nSollten Sie weitere Informationen zu unserem Angebot benötigen, <a>kontaktieren</a> Sie uns bitte oder besuchen Sie uns doch einfach in der Musikschule bei einer unserer regelmäßig stattfindenden <a>Schnupperstunden</a>.', 'Angebot', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2015-12-11 18:49:14', '2015-12-11 17:49:14', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/120-revision-v1/', 0, 'revision', '', 0),
(213, 1, '2015-12-11 18:50:08', '2015-12-11 17:50:08', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:\r\n\r\n<a>Musikalische Elementarausbildung</a>\r\n<a>Instrumentalunterricht</a>\r\n<a>Vokalunterricht</a>\r\n<a>Ensemble- und Orchesterspiel</a>\r\n<a>Fachübergreifende musikalische Fortbildung</a>\r\n\r\n<hr />\r\n\r\n<strong>Fragen zum Angebot?</strong>\r\n\r\n&nbsp;\r\n\r\nSollten Sie weitere Informationen zu unserem Angebot benötigen, <a>kontaktieren</a> Sie uns bitte oder besuchen Sie uns doch einfach in der Musikschule bei einer unserer regelmäßig stattfindenden <a>Schnupperstunden</a>.', 'Angebot', '', 'inherit', 'closed', 'closed', '', '120-revision-v1', '', '', '2015-12-11 18:50:08', '2015-12-11 17:50:08', '', 120, 'http://localhost/musikschule-wp-theme/wordpress/120-revision-v1/', 0, 'revision', '', 0),
(214, 1, '2015-12-11 18:51:07', '2015-12-11 17:51:07', '<strong>Ist Gesangunterricht das Richtige für mich?</strong>\r\n\r\nJeder Mensch kann singen. Singen ist die ursprünglichste Form des Musizierens und gleichzeitig auch die unmittelbarste, denn: Der Körper selbst ist das Instrument. Im Gegensatz zu allen anderen Musikinstrumenten kann jeder Mensch dieses "Instrument" von Natur aus mehr oder weniger gut "spielen".\r\n\r\nWer sich die Frage stellt, ob er Gesangunterricht nehmen soll, muss sich gleichzeitig fragen, zu welchem Ziel er damit gelangen will. Wer zu Hause gerne singt - ob in der Badewanne, zur CD oder einfach so braucht nicht unbedingt Gesangunterricht.\r\n\r\nAber das Unterrichtsangebot im Bereich Gesang richtet sich nicht nur an diejenigen, die sich auf ein Berufsstudium als Sänger vorbereiten wollen, sondern an alle, die lernen wollen, ihre eigenen stimmlichen und musikalischen Ausdrucksmöglichkeiten auf- und auszubauen oder zu verbessern, um dann z.B. im Kammerchor oder in einem Vokalensemble mitzusingen, oder an die, die Singen einfach aus Spaß erlernen möchten, um sich im persönlichen Ausdruck zu fördern: Gesang ist auf jeden Fall das Richtige zur Stimmbildung und -pflege für alle musisch und musikalisch Interessierten.\r\n\r\nDie Musikschule Havixbeck bietet das Fach sowohl im Gruppen- als auch im Einzelunterricht an:\r\n<table border="0" width="100%" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td valign="top"><strong>Einzelunterricht</strong>\r\n<p class="eingerueckt"><a class="underlined" href="http://jugendorchester-havixbeck.de/musikschule/sologesang.php">Sologesang</a></p>\r\n<strong>Ensemble / Gruppenunterricht</strong>\r\n<p class="eingerueckt">Young Voices</p>\r\n<a class="underlined" href="http://jugendorchester-havixbeck.de/musikschule/kontaktmain.php">Kontaktieren</a> Sie uns bitte für weitere Informationen zum Fachangebot Gesang.</td>\r\n</tr>\r\n</tbody>\r\n</table>', 'Gesang', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2015-12-11 18:51:07', '2015-12-11 17:51:07', '', 122, 'http://localhost/musikschule-wp-theme/wordpress/122-revision-v1/', 0, 'revision', '', 0),
(215, 1, '2015-12-11 18:52:57', '2015-12-11 17:52:57', '<strong>Ist Gesangunterricht das Richtige für mich?</strong>\n\nJeder Mensch kann singen. Singen ist die ursprünglichste Form des Musizierens und gleichzeitig auch die unmittelbarste, denn: Der Körper selbst ist das Instrument. Im Gegensatz zu allen anderen Musikinstrumenten kann jeder Mensch dieses "Instrument" von Natur aus mehr oder weniger gut "spielen".\n\nWer sich die Frage stellt, ob er Gesangunterricht nehmen soll, muss sich gleichzeitig fragen, zu welchem Ziel er damit gelangen will. Wer zu Hause gerne singt - ob in der Badewanne, zur CD oder einfach so braucht nicht unbedingt Gesangunterricht.\n\nAber das Unterrichtsangebot im Bereich Gesang richtet sich nicht nur an diejenigen, die sich auf ein Berufsstudium als Sänger vorbereiten wollen, sondern an alle, die lernen wollen, ihre eigenen stimmlichen und musikalischen Ausdrucksmöglichkeiten auf- und auszubauen oder zu verbessern, um dann z.B. im Kammerchor oder in einem Vokalensemble mitzusingen, oder an die, die Singen einfach aus Spaß erlernen möchten, um sich im persönlichen Ausdruck zu fördern: Gesang ist auf jeden Fall das Richtige zur Stimmbildung und -pflege für alle musisch und musikalisch Interessierten.\n\nDie Musikschule Havixbeck bietet das Fach sowohl im Gruppen- als auch im Einzelunterricht an:\n<strong>Einzelunterricht</strong>\n<p class="eingerueckt"><a href="">Sologesang</a></p>\n<strong>Ensemble / Gruppenunterricht</strong>\n<p class="eingerueckt">Young Voices</p>\n<a class="underlined" href="http://jugendorchester-havixbeck.de/musikschule/kontaktmain.php">Kontaktieren</a> Sie uns bitte für weitere Informationen zum Fachangebot Gesang.', 'Gesang', '', 'inherit', 'closed', 'closed', '', '122-autosave-v1', '', '', '2015-12-11 18:52:57', '2015-12-11 17:52:57', '', 122, 'http://localhost/musikschule-wp-theme/wordpress/122-autosave-v1/', 0, 'revision', '', 0),
(216, 1, '2015-12-11 18:51:55', '2015-12-11 17:51:55', '<strong>Ist Gesangunterricht das Richtige für mich?</strong>\r\n\r\nJeder Mensch kann singen. Singen ist die ursprünglichste Form des Musizierens und gleichzeitig auch die unmittelbarste, denn: Der Körper selbst ist das Instrument. Im Gegensatz zu allen anderen Musikinstrumenten kann jeder Mensch dieses "Instrument" von Natur aus mehr oder weniger gut "spielen".\r\n\r\nWer sich die Frage stellt, ob er Gesangunterricht nehmen soll, muss sich gleichzeitig fragen, zu welchem Ziel er damit gelangen will. Wer zu Hause gerne singt - ob in der Badewanne, zur CD oder einfach so braucht nicht unbedingt Gesangunterricht.\r\n\r\nAber das Unterrichtsangebot im Bereich Gesang richtet sich nicht nur an diejenigen, die sich auf ein Berufsstudium als Sänger vorbereiten wollen, sondern an alle, die lernen wollen, ihre eigenen stimmlichen und musikalischen Ausdrucksmöglichkeiten auf- und auszubauen oder zu verbessern, um dann z.B. im Kammerchor oder in einem Vokalensemble mitzusingen, oder an die, die Singen einfach aus Spaß erlernen möchten, um sich im persönlichen Ausdruck zu fördern: Gesang ist auf jeden Fall das Richtige zur Stimmbildung und -pflege für alle musisch und musikalisch Interessierten.\r\n\r\nDie Musikschule Havixbeck bietet das Fach sowohl im Gruppen- als auch im Einzelunterricht an:\r\n<strong>Einzelunterricht</strong>\r\n<p class="eingerueckt"><a class="underlined" href="http://jugendorchester-havixbeck.de/musikschule/sologesang.php">Sologesang</a></p>\r\n<strong>Ensemble / Gruppenunterricht</strong>\r\n<p class="eingerueckt">Young Voices</p>\r\n<a class="underlined" href="http://jugendorchester-havixbeck.de/musikschule/kontaktmain.php">Kontaktieren</a> Sie uns bitte für weitere Informationen zum Fachangebot Gesang.', 'Gesang', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2015-12-11 18:51:55', '2015-12-11 17:51:55', '', 122, 'http://localhost/musikschule-wp-theme/wordpress/122-revision-v1/', 0, 'revision', '', 0),
(217, 1, '2015-12-13 13:46:27', '2015-12-13 12:46:27', 'Die Blockflöte zählt, besonders im Anfängerunterricht, zu den beliebtesten Instrumenten. An der Musikschule Havixbeck wird weiterführender Unterricht bis zur Oberstufe angeboten - ob Sopran-, Alt-, Tenor- oder Bassblockflöte. Auch für Erwachsene ist ein Wieder- oder Neubeginn möglich.\r\n\r\nDie Blockflöte hat eine lange Geschichte. Anfangs war sie nur ein einfaches Holzrohr; mit der Zeit wurde sie verbessert.\r\n\r\nIm 16. Jahrhundert war sie geradezu ein modisches Instrument. Wohlhabende Familien besaßen ganze Sammlungen von Blockflöten. Um 1700 veränderte Jacques Hotteterre die einfache Blockflöte von Grund auf; von da an waren Tonhöhe und Stimmung einander angeglichen. Und auf einmal nahmen auch große Komponisten sich ihrer an. Über hundert Jahre lang war die Blockflöte sehr beliebt. Dann wurde sie plötzlich durch die klangreichere Querflöte in den Schatten gestellt. Gegen die kräftigeren Instrumente wie Geige und Klavier, die damals in Mode kamen, konnte sich der sanfte Blockflötenton weniger behaupten. Eine Zeitlang gab es beide Flötentypen nebeneinander, dann führte die Blockflöte 150 Jahre lang ein Leben im Verborgenen. 1906 erwarb der Franzose Arnold Dolmetsch eine Blockflöte aus dem 18. Jahrhundert, die ihn so interessierte, dass er etwa 10 Jahre später die ersten modernen Blockflöten nach ihrem Vorbild bauen ließ.\r\n\r\nDer Spieler bläst durch ein pfeifenartiges Mundstück, in dem ein Holzblock mit scharfer Kante sitzt. Gegen diese Kante wird der Atem gepresst und bringt so die Luftsäule im Instrument zum Vibrieren. Schwierig ist es, den Luftstrom genau zu bemessen; bläst man etwas zu wenig, bleibt der Ton aus; ein bisschen zu viel Atem - und der Ton fiept. Die Blockflöte hat eine konische Bohrung und 8 Löcher, die sehr sorgfältig mit den Fingern bedeckt werden müssen, damit die Töne nicht quietschen', 'Blockflöte', '', 'publish', 'closed', 'closed', '', 'blockfloete', '', '', '2015-12-15 16:31:16', '2015-12-15 15:31:16', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=217', 0, 'instrumente', '', 0),
(218, 1, '2015-12-13 14:11:38', '2015-12-13 13:11:38', 'Das Fagott ist das Bassinstrument der Holzbläsergruppe mit einer außergewöhnlichen klanglichen Vielseitigkeit. Es hat einen Tonumfang von über drei Oktaven und besitzt 22-24 Klappen und sechs Grifflöcher. Angeblasen wird es mittels eines Bambusröhrchens, das der Fagottist meist selber baut. Mit seinen 140 cm ist es der Riese unter den Holzblasinstrumenten. Da in letzter Zeit auch "Kinderfagotte" (Quart- und Quintfagotte) hergestellt werden, kann der Unterricht mit 7 Jahren beginnen.\r\n', 'Fagott', '', 'publish', 'closed', 'closed', '', 'fagott', '', '', '2015-12-15 16:31:19', '2015-12-15 15:31:19', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=218', 0, 'instrumente', '', 0),
(219, 1, '2015-12-13 14:14:16', '2015-12-13 13:14:16', 'Die Klarinette wurde um das Jahr 1700 vom Nürnberger Instrumentenbauer Johann Christoph Denner entwickelt. Sehr schnell erfreute sich das Instrument bei Interpreten und Komponisten allergrößter Beliebtheit, da sie klanglich ein besonders vielseitiges Instrument ist. Sie besteht aus einer zylindrisch gebohrten Röhre (meist aus Hartholz) mit 18 Klappen und besitzt einen Tonumfang von dreieinhalb Oktaven. Sie wird in der klassischen Musik (Kammermusik und Sinfonieorchester) ebenso wie im Jazz, im Blasorchester und in der Folkloremusik vieler Länder z.B. in der jüdischen Klezmermusik eingesetzt.\r\n', 'Klarinette', '', 'publish', 'closed', 'closed', '', 'klarinette', '', '', '2015-12-15 16:31:21', '2015-12-15 15:31:21', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=219', 0, 'instrumente', '', 0),
(220, 1, '2015-12-13 14:15:05', '2015-12-13 13:15:05', 'Die Oboe (von frz. hautbois = hohes Holz) gehört zu den ältesten Blasinstrumenten und hat ihre Vorläufer im griechischen Aulos und der römischen Tibia. Sie ist ein Holzblasinstrumenten mit einem Doppelrohrblatt als Mundstück (Oboenrohr) und besteht aus einer dreiteiligen, konisch gebohrten Schallröhre aus Hartholz. Die Tonerzeugung erfolgt durch das Gegeneinanderschwingen der Rohrblattlamellen. Durch ein gut entwickeltes Klappensystem wird die Grifftechnik erleichtert.\r\n\r\nDie Modulationsskala des charakteristisch schalmeiartigen Oboentones ist weit gestreckt - anmutig bis herb, fröhlich bis schmerzvoll, voluminös bis dünn, spitz.\r\n\r\nSeit 1650 gehört die Oboe zu den Orchesterinstrumenten. Die Literatur für Solo-, Kammer- und Orchestermusik reicht vom Barock bis in die Gegenwart. Im Orchester kommt der Oboe eine besondere Aufgabe zu: Sie gibt seit dem 19. Jahrhundert den Stimmton an.\r\n', 'Oboe', '', 'publish', 'closed', 'closed', '', 'oboe', '', '', '2015-12-15 16:31:23', '2015-12-15 15:31:23', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=220', 0, 'instrumente', '', 0),
(221, 1, '2015-12-13 14:16:00', '2015-12-13 13:16:00', 'Die Querflöte ist ein sehr altes Blasinstrument (z.B. in China 9. Jh. v. Chr.). Die Boehm- oder Konzertflöte, wie sie auch genannt wird, besteht heutzutage meist aus Metall, seltener aus Holz. Sie wird nach rechts gehalten, die Klappen der Tonlöcher mit 8 (9) Fingern abgedeckt. Die Tonerzeugung erfolgt - vereinfacht ausgedrückt - nach dem Prinzip "auf einer Flasche Blasen". Für die Querflöte gibt es ein reichhaltiges Angebot von Kompositionen aller Jahrhunderte: Solistisch und in der Kombination mit allen anderen Instrumenten. Auch im Jazz und in der Popmusik wird sie eingesetzt.', 'Querflöte', '', 'publish', 'closed', 'closed', '', 'querfloete', '', '', '2015-12-15 16:31:26', '2015-12-15 15:31:26', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=221', 0, 'instrumente', '', 0),
(222, 1, '2015-12-13 14:17:15', '2015-12-13 13:17:15', 'Der Name "Saxophon" stammt von seinem Erfinder, dem Belgier Adolphe Sax, der um 1840 das erste Saxophon baute und bis kurz vor seinem Tode Saxophonprofessor am Pariser Konservatorium war. Das Instrument war sofort ein großer Erfolg. Nahezu in ganz Europa wurde das Saxophon in die Militärkapellen integriert. Der Weg in die europäische Konzertmusik wurde dem Saxophon allerdings erschwert. Populär als "Modeinstrument" wurde das Saxophon erst mit dessen Verwendung in der Jazz- und Tanzmusik ab ca. 1920. Daher ist das Saxophon für viele "das Jazzinstrument" par excellence. Doch schon viele Jahre zuvor schrieben viele Komponisten Werke für Klassisches Saxophon. Bereits ab Mitte des 19. Jh. entstanden Solokonzerte, Sonaten, Saxophonquartette etc., die bis heute zur Standardliteratur für Klassisches Saxophon zählen. Aber wie kaum ein anderes Instrument muss sich das Saxophon seine Anerkennung in der klassischen Musik bis heute erkämpfen.\r\nDas Saxophon gehört zu den Holzblasinstrumenten mit einfachem Rohrblatt. Sein Korpus besteht aus einer konischen, mit Klappen besetzten Metallröhre. \r\nDas Saxophon hat einen Tonumfang von über zweieinhalb Oktaven und wird in sieben verschiedenen Größen gebaut: Kontrabass-, Bass-, Bariton-, Tenor-, Alt-, Sopran- und Sopraninosaxophon. \r\nDas Saxophon findet heute Verwendung als Soloinstrument (auch mit Klavierbegleitung etc.), in Kammermusikbesetzungen (Saxophonquartett /  Saxophonensemble u.s.w.), im Sinfonischen Blasorchester, partiell im Sinfonieorchester, aber auch im Jazz oder der Popular- und Unterhaltungsmusik.\r\nMan unterscheidet, u.a. durch die Spielweise und das verwendete Material, das "Klassische Saxophon" vom "Jazz-Saxophon".', 'Saxophon', '', 'publish', 'closed', 'closed', '', 'saxophon', '', '', '2015-12-15 16:31:29', '2015-12-15 15:31:29', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=222', 0, 'instrumente', '', 0),
(223, 1, '2015-12-13 17:07:00', '2015-12-13 16:07:00', 'Das Euphonium ist eine Erfindung des englischen Raums. Die Form ist der Tuba nachempfunden.Es kann sicher wohl als das interessanteste aller Messingblasinstrumente angesehen werden. Es ist äußerst beweglich und somit wie das Flügelhorn für schwierige Läufe und Melodiepassagen besonders geeignet. Während es ein Stück mit der Melodie geht, marschiert es im nächsten Augenblick mit Macht an der Seite der Bässe. Das Euphonium ist ein Blasinstrument mit Kesselmundstück, ein ovales oder tubaförmiges Flügelhom in Tenorlage mit einem etwa 275 cm konischem Messingrohr und weiter Mensur, das ihm, besonders in der Tiefe, kräftige und große Tonfülle verleiht. Es wird in der Orchester ebenso wie in der Folkloremusik vieler Länder z.B. in der tschechisch-böhmische Blasmusik eingesetzt.\r\n', 'Euphonium, Bariton, Tenorhorn', '', 'publish', 'closed', 'closed', '', 'euphonium-bariton-tenorhorn', '', '', '2015-12-15 16:34:46', '2015-12-15 15:34:46', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=223', 0, 'instrumente', '', 0),
(224, 1, '2015-12-13 17:08:24', '2015-12-13 16:08:24', 'Vorläufer des heutigen Horns (Tierhörner) sind schon seit Urzeiten bekannt. Diese waren wurden als Signal- oder Zeremonie-Instrumente zu genutzt. Die heutige, runde Form ist seit dem 12. Jahrhundert bekannt. Das Horn ist eines der "längsten" Blasinstumente: Es besteht aus einem rundgebogenen Silber- oder Messing-Rohr von mehr als 3 Metern Länge. Das Horn bewährt sich durch seine Vielseitigkeit. Durch Einführen der rechten Hand in das Schallstück werden Ton-Abstufungen kontrolliert. Dieses , ist auch verantwortlich für den typischen weichen und romantischen Waldhornklang. Das Horn wird in der Blasmusik und im Blasorchester genauso eingesetzt wie im Sinfornieorchester und in der Kammermusik. Sein Klang mischt sich sowohl gut mit Blech- als auch mit Holzblasinstrumenten. Wunderschöne Hornkonzerte sind von Joseph Haydn, Wolfgang Amadeus Mozart und Richard Strauss überliefert', 'Horn', '', 'publish', 'closed', 'closed', '', 'horn', '', '', '2015-12-15 16:34:50', '2015-12-15 15:34:50', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=224', 0, 'instrumente', '', 0),
(225, 1, '2015-12-13 17:09:42', '2015-12-13 16:09:42', 'Die Posaune gehört zu den Blechblasinstrumenten und ist gewissermaßen eine sehr große Trompete mit tiefer Lage. Ihr Klang ist weich bis kraftvoll, und sie hat in fast jeder musikalischen Gattung ihren Stammplatz. Die Tonänderung erfolgt durch den Zug. Dadurch verlängert man die effektive Länge des Instrumentes, so dass der Ton tiefer wird. Der Zug ist das Merkmal, das die Posaune von allen anderen Blechblasinstrumenten unterscheidet und sie zum ältesten Blechblasinstrument mit chromatischem Tonumfang macht. Als Solo- und Ensembleinstrument, in Sinfonie- und Kammerorchestern ist die Posaune genauso unentbehrlich wie im Jazz, wo sie als Bassinstrument, aber auch als Träger der Gegenmelodie zu Klarinette und Trompete sowie als Soloinstrument ihre Funktion hat.', 'Posaune', '', 'publish', 'closed', 'closed', '', 'posaune', '', '', '2015-12-15 16:34:55', '2015-12-15 15:34:55', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=225', 0, 'instrumente', '', 0),
(226, 1, '2015-12-13 17:11:04', '2015-12-13 16:11:04', 'Tuba (lat. tubus, "Röhre") wurde das wichtigste Blechblasinstrument der römischen Antike genannt. Die heutige Form entstand im Jahre 1835. Die Tuba ist das tiefste Instrument des Orchesters.Angeblasen wird die Tuba durch ein großes Kesselmundstück. Sie klingt voluminös, schwer und wuchtig und ist weniger strahlend und durchdringend als andere Blechblasinstrumente. Mit der erstaunlich flexiblen Tuba lassen sich zudem auch sehr subtile Melodien spielen. Einige Komponisten unseres Jahrhunderts haben deshalb Werke eigens für die Tuba geschriebenSie wird im Sinfonie- und Blasorchester als Bass der Posaunengruppe eingesetzt. Die Harmoniemusik und Marschkapellen bevorzugen das ovale, um den Leib getragene Helikon und das Sousaphon, dessen großer Schalltrichter über den Kopf des Bläsers hinweg nach vorne ragt.', 'Tuba', '', 'publish', 'closed', 'closed', '', 'tuba', '', '', '2015-12-15 16:35:04', '2015-12-15 15:35:04', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=226', 0, 'instrumente', '', 0),
(227, 1, '2015-12-13 17:13:21', '2015-12-13 16:13:21', ' In keiner Instrumentengruppe herrscht eine solche Vielfalt wie bei den Schlaginstrumenten. Ihr Ursprung liegt im Klatschen, Stamp-fen und Schlagen und in den aus dieser natürlichen Bewegung geschaffenen Gegenständen. Einige Percussionsinstrumente gehören zu den ältesten Instrumenten überhaupt. Im Mittelalter entwickelten sich Rühr- oder Marschtrommeln. Aus diesen wie-derum entwickelte sich in New Orleans ab 1900 unser heutiges drum-set. In der klassi-schen Musik versteht man unter Schlag-zeug ein ganzes Arsenal von Schlaginstrumenten. Dem Material nach, das in Schwingungen versetzt wird, lässt sich das vielfarbige Instrumentarium in Fell-, Holz- und Metallinstru-mente ordnen. Innerhalb dieser Gruppen lassen sich wiederum Instrumente mit bestimmter Tonhöhe (auf denen verschiedene Töne oder gar ganze Melodien gespielt werden können) und Ge-räuschinstrumente (reine Rhythmus- und Effektinstrumente) unterscheiden. Nach Spieltechnik und Anwendungs-bereich lässt sich das Instrumentarium in vier Hauptgruppen unterteilen:\r\n\r\n- Drum-Set (kombiniertes Schlagzeug)\r\n- Percussion (z. B. Congas, Bongos, Rasseln, Triangel)\r\n- Pauken\r\n- Stabspiele bzw. Mallet-Instrumente (z. B. Vibraphon, Xylophon, Glockenspiel\r\n\r\nDas Schlagzeug wird allen Bereichen der Musik eingesetzt. Von der Klassik im Sinfonieorchester, ebenso wie im Jazz, der Folkloremusik oder der sinfonischen Blasmusik. Und für die heutige Populärmusik ist das Schlagzeug wohl das wichtigste Instrument.', 'Schlagzeug, Percussion, Pauken, Stabspiele', '', 'publish', 'closed', 'closed', '', 'schlagzeug-percussion-pauken-stabspiele', '', '', '2015-12-15 16:36:46', '2015-12-15 15:36:46', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=227', 0, 'instrumente', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(228, 1, '2015-12-13 17:14:27', '2015-12-13 16:14:27', 'Das Violoncello, ist im 16. Jahrhundert entstanden. Es wird sowohl als Tenor- als auch Bassinstrument der Violinenfamilie eingesetzt. Bevor im 18. Jahrhundert der verstellbare Stachel erfunden wurde, hielt man das Cello wegen seiner Größe zwischen den Beinen fest. Nachdem Antonio Stradivari um 1710 die ideale Mensur des Cellos gefunden hatte, wurden die mei-sten bestehenden Instrumente umgebaut. Im 16. und 17. Jahrhundert gab es neben dem Cello noch ein ähnliches Instrument mit der Stimmung B1-F-c-g, das aber zuerst in Italien, später auch in Frankreich verdrängt wurde. Das Violoncello wurde zunächst als reines Generalbassinstrument verwendet, 1680 hat Gabrieli mit seinen Solonoten das Cello aus dem Schatten der höheren Streichinstrumente gehoben. Heute ist das Cello ein fester Orchesterbestandteil.\r\n\r\nDas Violoncello ist durch seinen großen Tonumfang und seine Klangfarbe ein besonders schönes Instrument. Es hat seinen festen Platz in fast allen Musikensembles: als Begleitinstrument, im Orchester, im Streichquartett, aber auch als Soloinstrument. Es wurde mittlerweile auch für den Jazz entdeckt. und wird vermehrt als Klangfarbe in Blasorchestern eingestzt.', 'Cello', '', 'publish', 'closed', 'closed', '', 'cello', '', '', '2015-12-15 16:06:29', '2015-12-15 15:06:29', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=228', 0, 'instrumente', '', 0),
(229, 1, '2015-12-13 17:16:38', '2015-12-13 16:16:38', 'Die elektronische Gitarre wird vorwiegend in der Rock,- Pop- und Jazzmusik als Bass, Akkord- und Melodieinstrument eingesetzt. Ihr Aussehen hat sich gegenüber der normalen Gitarre sehr geändert - der brettartige, oft phantasievoll verzierte und kleine Korpus hat im Unterschied zur akustischen Gitarre keine klangliche Funktion und das Griffbrett ist länger. Die Stahlsaiten werden mit dem Plektrum angerissen. Die entstehenden Schwingungen der Saiten werden mit magnetischen Tonabnehmern abgenommen und elektronisch verstärkt. Der Klang der E-Gitarre kann durch Filter, Verzerrer, elektronische oder akustische Rückkopplung sehr weitgehend beeinflußt werden.', 'E-Gitarre', '', 'publish', 'closed', 'closed', '', 'e-gitarre', '', '', '2015-12-15 16:06:24', '2015-12-15 15:06:24', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=229', 0, 'instrumente', '', 0),
(230, 1, '2015-12-13 17:17:24', '2015-12-13 16:17:24', 'Die akustische Gitarre mit ihren sechs im Quartabstand gestimmten Saiten gab es schon im 18. Jahrhundert. Ihre Vorläufer gehen sogar auf das 13. Jahrhundert in Spanien zurück. Das Instrument wird viel mit spanischer und lateinamerikanischer Musik in Verbindung gebracht, bereichert aber auch die Volksmusik in vielen anderen Ländern. Im 17. Jahrhundert sowie gegen Ende des 18. Jahrhunderts war die Gitarre in Deutschland ein Modeinstrument. Sie ist wegen ihrer Vielseitigkeit ein sehr beliebtes Solo-, Begleit- und Kammermusikinstrument, das in nahezu allen Musikstilen zu Hause ist. Die Gitarre kann gezupft oder geschlagen werden. Man kann sowohl Melodien und Begleitung gleichzeitig spielen als auch andere Instrumente oder Sänger begleiten.\r\n\r\nEine Gitarre besteht aus einem beidseitig eingebuchteten Korpus mit flachen Zargen und offenem Schallloch und einem Hals. Über die Bünde am Hals wird die Tonhöhe der 6 Saiten bestimmt.', 'Gitarre', '', 'publish', 'closed', 'closed', '', 'gitarre', '', '', '2015-12-15 16:06:19', '2015-12-15 15:06:19', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=230', 0, 'instrumente', '', 0),
(231, 1, '2015-12-13 17:18:04', '2015-12-13 16:18:04', 'Der Kontrabass (Bassgeige) ist das größte Streichinstrument im Orchester. Er ist so groß, dass er im Stehen gespielt wird oder auf einem hohen Hocker sitzend. Mit seinem tiefen, warmen Klang bildet er das Fundament des gesamten Orchesters. Wirkungsvoll ist auch das Zupfen (Pizzicato), das vor allem im Jazz eine wichtige rhythmische und harmonische Rolle spielt. Seit dem 15. Jahrhundert kennt man Kontrabass-Instrumente. Vom Violone aus der Gambenfamilie stammend, hat sich aus einer Vielzahl von Formen, Seitenzahlen und Stimmungen der heutige Kontrabass – das tiefste Instrument der Streicherfamilie – entwickelt. Während man in Italien, Frankreich und England wie beim Violoncello einen Obergriffbogen benutzt, wird im deutsch-sprachigen Raum mit einem Untergriffbogen, ähnlich wie bei der Gambe gestrichen. Die Ausbildung gleicht im wesentlichen der aller Streichinstrumente.\r\n\r\nDer Kontrabass ist ein Ensembleinstrument, d.h. in fast jedem Musizierkreis, Kammermusikensemble, Orchester, Jazz-Formation oder sogar einem Blasorchester wird ein Kontrabass benötigt. Kein Orchester klingt komplett ohne Kontrabässe. Seine vorrangige Aufgabe ist das Erzeugen des rhythmischen und harmoniebildenden Fundaments. Kontrabassspieler sind gefragte Musiker in Ensembles oder Bands.', 'Kontrabass', '', 'publish', 'closed', 'closed', '', 'kontrabass', '', '', '2015-12-15 16:06:13', '2015-12-15 15:06:13', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=231', 0, 'instrumente', '', 0),
(232, 1, '2015-12-13 17:19:20', '2015-12-13 16:19:20', 'Die Violine, auch Geige genannt, ist das höchstentwickelte Streichinstrument und gehört zu den ausdrucksstärksten Instru-menten überhaupt. Seit etwa 300 Jahren ist es eines der wich-tigsten Musikinstrumente des Abendlandes und hat einen führenden Platz im Sinfonieorchester. Durch verschiedenen Spieltechniken werden unterschiedliche Wirkungen erreicht. Streicht man mit dem Bogen über die Saiten, entsteht der bekannte weiche Ton. Fährt man in kurzen Beweg-ungen über die Saiten, entsteht ein greller, harter Ton. Ein melan-cholisch stimmender Glissandoeffekt wird durch Gleiten der Fing-er auf den Saiten erreicht, während kurze, schnappende Klänge durch das Zupfen der Saiten erzeugt werden.\r\n\r\nIm Umkreis von Mailand entstand um 1520 die Frühform der Vio-line mit drei Saiten. Um 1550 wurde die Saitenzahl auf vier erhöht. Die klassische Form der Violine entstand vor 1600 in der Schule von Andrea Amati. Im 17. Jahrhundert entwickelte sich der italien-ische, deutsche und französische Geigenbau zu höchster Blüte. Amatis Stradivari-Modell von 1713 hat die noch heute gültigen Abmessungen.\r\n\r\nDie Violine ist nicht nur in der klassischen Musik vielseitig verwendbar: Man kann mit ihr auch zum Tanz aufspielen, in Cafe’s die Gäste unterhalten und Volkstänze begleiten. Schon im Mittelalter gab es fahrende Musikanten und Spielleute mit ihren Saiteninstrumenten. In den letzten Jahren wurde die Geige zunehmend in der Pop- und Jazzmusik eingesetzt, um einen weicheren Effekt zu erzielen.', 'Violine', '', 'publish', 'closed', 'closed', '', 'violine', '', '', '2015-12-15 16:06:08', '2015-12-15 15:06:08', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=232', 0, 'instrumente', '', 0),
(233, 1, '2015-12-13 17:19:59', '2015-12-13 16:19:59', 'Das Keyboard ist ein elektronisches Tasteninstrument, dessen Klänge digital verarbeitet und gespeichert werden.\r\n\r\nZu unterscheiden ist das Keyboard dabei von den Digital-Pianos, welche sich durch ihren größeren Tonumfang von 88 Tasten und durch den höheren Anschlagswiderstand einer gewichteten Tastatur sowie einer installierten Hammermechanik dem Klangbild des klassischen Klaviers annähern.\r\n\r\nDas eigentliche Keyboard mit einem Tonumfang von etwa fünf Oktaven ermöglicht im Melodiespiel die Wahl unterschiedlicher Sounds, welche den Klang der verschiedensten Instrumente imitieren. In der Begleitung sind vorgefertigte Styles oder Rhythms installiert und können während des Spielens passend in Harmonik und Rhythmus eingesetzt werden. Im Single-Finger-Modus wird der passende Style mit einfachsten Tastenkombinationen abgerufen. Der gespielte Song kann auf einen internen Speicher aufgenommen werden, wobei der Spieler im Mehrspurverfahren alle Instrumente eines Songs nacheinander einspielen kann.\r\n\r\nEntsprechend seiner technischen und klanglichen Vielseitigkeit ist das Keyboard im Unterricht auf keine musikalische Stilrichtung festgelegt. Der Schwerpunkt seines Repertoires liegt im Bereich Rock, Pop und Jazz - als Ensembleinstrument ist es in der Popularmusik unentbehrlich.', 'Keyboard', '', 'publish', 'closed', 'closed', '', 'keyboard', '', '', '2015-12-15 16:05:23', '2015-12-15 15:05:23', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=233', 0, 'instrumente', '', 0),
(234, 1, '2015-12-13 17:21:14', '2015-12-13 16:21:14', 'Im Fach Klavier gibt es bundesweit die meisten Schüler und Lehrer. Kein Wunder, denn es ist seit Jahrhunderten das beliebteste und meistgespielte Instrument. Komponisten aller Epochen und Stilrichtungen haben Stücke für dieses Instrument geschrieben, sowohl große Werke, die Musikgeschichte machten, als auch Übungsstücke für Anfänger von großem musikalischen Wert. Es ist das Instrument mit dem größten Tonumfang und durch die Hammermechanik und den Einsatz der Pedale sehr dynamisch und klangfarbenreich. Es bietet konkurrenzlose Möglichkeiten für die Übermittlung von Inhalten der Musiklehre und ist das Eigenständigste unter allen Instrumenten, denn schon ein einziger am Klavier kann sich eine ganze musikalische Welt erschaffen. Aber auch im Team macht es Spaß: zu zweit oder zu dritt an einem oder an mehreren Klavieren. Oder zusammen mit Streichern, Bläsern oder Sängern. Vielleicht sogar mit einem ganzen Orchester?', 'Klavier', '', 'publish', 'closed', 'closed', '', 'klavier', '', '', '2015-12-15 16:05:18', '2015-12-15 15:05:18', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=234', 0, 'instrumente', '', 0),
(235, 1, '2015-12-13 17:21:57', '2015-12-13 16:21:57', 'Die Orgel zählt zu den Tasteninstrumenten. Manche nennen die Pfeifenorgel (nicht zu verwechseln mit der elektronischen Orgel) die "Königin der Musikinstrumente". Sie ist das gewaltigste und komplizierteste Instrument und hat die Klangbreite eines ganzen Orchesters. Sie begeistert durch ihr imposantes Äusseres – im Gehäuse befinden sich hunderte von verschiedensten Pfeifen, welche mit Hilfe von Mechanik über Manuale und Pedal (mit Händen und Füssen) zum Klingen gebracht werden. Meist findet man sie in die Kirchem, denn dort hat sie, vor allem in den Gottesdiensten ihren "Platz". Seit dem 19. Jahrhundert findet man sie aber auch in vielen Konzerthäusern, denn die Säkularisierung hat eine Emanzipation des Instrumentes mit großer weltlicher Konzertliteratur mit sich gebracht.Hier bitte eine Beschreibung des Faches eingeben.', 'Orgel', '', 'publish', 'closed', 'closed', '', 'orgel', '', '', '2015-12-15 16:04:32', '2015-12-15 15:04:32', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=235', 0, 'instrumente', '', 0),
(236, 1, '2015-12-13 17:25:45', '2015-12-13 16:25:45', 'Seinen Namen hat es erhalten, weil nur ein Knopfdruck nötig ist, um einen harmonischen Akkord zu erzeugen. Für den Klang der Einzeltöne und Akkorde sind Zungen zuständig, die durch Luftströme in Schwingungen versetzt werden. Diese Luft wird durch einen Balg bewegt, und dieser Balg wird von Hand bedient.\r\n\r\nInstrumente mit diesen Eigenschaften nennt man Harmonikas, Instrumente mit durchschlagenden Zungen, Balginstrumente oder Handzuginstrumente, je nachdem, welche Eigenschaft im Vordergrund steht. Enge Verwandte des Akkordeons sind zum Beispiel das Bajan, das Bandoneon und die Concertina.\r\n\r\n1829 erfand Cyrill Demian das Accordion als erstes Instrument, das jede dieser vier Eigenschaften besaß. Es hatte äußerlich noch wenig Ähnlichkeit mit dem heutigen Akkordeon, wird aber als die Erfindung betrachtet, aus der es entstanden ist.', 'Akkordeon', '', 'publish', 'closed', 'closed', '', 'akkordeon', '', '', '2015-12-15 16:04:16', '2015-12-15 15:04:16', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=236', 0, 'instrumente', '', 0),
(237, 1, '2015-12-13 17:36:12', '2015-12-13 16:36:12', '', 'Jasper Arts', '', 'publish', 'closed', 'closed', '', 'jasper-arts', '', '', '2015-12-13 17:36:12', '2015-12-13 16:36:12', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=237', 0, 'dozenten', '', 0),
(238, 1, '2015-12-13 17:36:05', '2015-12-13 16:36:05', '', 'artsjasper3234', '', 'inherit', 'open', 'closed', '', 'artsjasper3234', '', '', '2015-12-13 17:36:05', '2015-12-13 16:36:05', '', 237, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/artsjasper3234.jpg', 0, 'attachment', 'image/jpeg', 0),
(239, 1, '2015-12-13 17:45:38', '2015-12-13 16:45:38', '', 'ralfbachmann', '', 'inherit', 'open', 'closed', '', 'ralfbachmann-2', '', '', '2015-12-13 17:45:38', '2015-12-13 16:45:38', '', 93, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/ralfbachmann1.gif', 0, 'attachment', 'image/gif', 0),
(240, 1, '2015-12-13 17:46:37', '2015-12-13 16:46:37', 'Die mehrfache Preisträgerin beim Wettbewerb »Jugend musiziert« begann 1997 ihr Studium an der Hochschule für Musik Detmold, Abteilung Münster, bei Prof. Ursula Wüst, Studienrichtung Instrumentalpädagogik mit Hauptfach Flöte. Nach der erfolgreichen Diplomprüfung beschloss sie, ihr musikalisches Studium bei Prof. Ursula Wüst im Studiengang Künstlerische Instrumentalausbildung zu vertiefen. Zusätzlich erhielt sie Flöten- und Piccolounterricht bei Konrad Hirzel (Städtische Bühnen Münster). Weiterführende Meisterkurse besuchte sie unter anderem bei Robert Aitken, Renate Greiss-Armin, Angela Firkins und Paul Meisen.\r\n\r\nCornelia Becken wirkte in verschiedenen Orchestern darunter auch dem Niederrheinisches Jugendsinfonieorchester, dem Jungen Sinfonieorchester der WWU Münster (Soloflötistin) und dem Pro-Musica-Orchester Münster (Soloflötistin) mit. Nebenher engagierte sie sich vermehrt im Bereich der Neuen Musik, z.B. 2001 bis 2010 im Ensemble Horizonte, Detmold.\r\n\r\nBelohnt wurde dies 2004 mit dem MUSIK Stipendiaium des Europäischen Zentrums der Künste in Dresden, welches hochqualifizierte Instrumentalisten, die sich im Bereich der Neuen Musik profiliert haben, beim Einstieg in den professionellen Bereich unterstützt.\r\n\r\nSeit August 2004 Unterrichtet Cornelia Becken an der Musikschule Havixbeck Querflöte.', 'Cornelia Becken', '', 'publish', 'closed', 'closed', '', 'cornelia-becken', '', '', '2015-12-13 17:46:48', '2015-12-13 16:46:48', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=240', 0, 'dozenten', '', 0),
(241, 1, '2015-12-13 17:46:45', '2015-12-13 16:46:45', '', 'becken', '', 'inherit', 'open', 'closed', '', 'becken', '', '', '2015-12-13 17:46:45', '2015-12-13 16:46:45', '', 240, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/becken.jpg', 0, 'attachment', 'image/jpeg', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(242, 1, '2015-12-13 17:47:28', '2015-12-13 16:47:28', 'Judith Becker begann ihre musikalische Ausbildung im Alter von acht Jahren an der Klarinette und wechselte später zum Saxophon. Nach dem Abitur 1999 setzte sie ihren musikalischen Schwerpunkt im Hauptfach "Klassisches Saxophon" und begann ein Saxophonstudium am „Conservatoire de Musique de Luxembourg“ bei Prof. Guy Goethals, das sie 2006 mit dem Diplôme abschloss.\r\n\r\nAm Konservatorium Luxemburg wirkte sie im Sinfonischen Blasorchester, im großen Saxophonensemble sowie im Saxophonquartett der Klasse von Prof. Guy Goethals mit. In den Jahren 2003 und 2004 nahm sie am UGDA-Wettbewerb „Jeunes solistes“ in Luxemburg in der Disziplin „Solo/Division Excellence“ teil und gewann die Bronzemedaille. Judith Becker spielte in verschiedenen Orchestern u.a. im Orchester der „Wind Academy Mannheim“ sowie im „WeltJugendBlasOrchester 2006“. Von 2007 bis 2009 war sie Saxophonistin im Osnabrücker Saxophonensemble „Saxperience“. Projektbezogen tritt sie als Solistin mit Klavier- bzw. Orgelbegleitung auf.\r\n\r\nJudith Becker besuchte Workshops und Meisterkurse bei Johan van der Linden (Enschede), Roy Hovens (Maastricht), Philippe Geiss (Straßburg) sowie Linda Bangs (Mainz). Weitere Impulse erhielt sie durch private Studien bei Simone Otto (Berlin).\r\n\r\nSeit ihrer Studienzeit arbeitet Judith Becker als freie Musikpädagogin an verschiedenen Musikschulen. An der Musikschule Havixbeck unterrichtet sie seit 2004 das Fach Saxophon. Seit Herbst 2007 leitet sie das Saxophonquartett „Saxonata“ und seit 2013 das Saxophonquartett "Sux-o-phun". Im Jahr 2012 gründete Judith Becker das "Saxophonorchester Havixbeck". Sie ist als Musiklehrerin in den „Bläserklassen“ der Anne-Frank-Gesamtschule und in der „Musizierklasse“ der Baumberge-Grundschule in Havixbeck tätig. Zudem ist sie Dozentin beim Kreisjugendorchester Münsterland. Seit dem Wintersemester 2013/14 hat sie einen Lehrauftrag an der Musikhochschule Münster für das Fach "Fachdidaktik Saxophon".\r\n\r\nNeben ihren musikalischen Tätigkeiten hat Judith Becker ein Studium an der Universität Trier in den Fächern Germanistik, Kunstgeschichte und Politikwissenschaft abgeschlossen und arbeitet als freie Germanistin im Kulturbereich.', 'Judith Becken', '', 'publish', 'closed', 'closed', '', 'judith-becken', '', '', '2015-12-13 17:47:46', '2015-12-13 16:47:46', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=242', 0, 'dozenten', '', 0),
(243, 1, '2015-12-13 17:47:42', '2015-12-13 16:47:42', '', 'beckerjudith1060', '', 'inherit', 'open', 'closed', '', 'beckerjudith1060', '', '', '2015-12-13 17:47:42', '2015-12-13 16:47:42', '', 242, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/beckerjudith1060.jpg', 0, 'attachment', 'image/jpeg', 0),
(244, 1, '2015-12-13 17:50:15', '2015-12-13 16:50:15', ' Rainer Becker absolvierte seine Studien in den Fächern „Blasorchesterdirigat“, „Euphonium“ (Patrick Krysatis) und „Posaune“ (Jean-Paul Frisch & Marc Meyers) am „Conservatoire de musique de la ville de Luxembourg“. Als Musiker spielte er u.a. im „Sinfonischen Blasorchester der EU“, dem „Sinfonischen Blasorchester des Konservatoriums Luxemburg“, der „Bläserphilharmonie Süd-West“ sowie bei „Luxemburg Philharmonia“.\r\n\r\nSeinen ersten Dirigierunterricht erhielt er an der Musikakademie in Marktoberdorf bei Wilhelm Koenen. Nach erfolgreichem Abschluss der staatlichen Dirigentenprüfung und des B-Lehrgangs für Blasorchesterdirigenten an der Bundesakademie in Trossingen, bei Prof. Felix Hauswirth, begann er ein Dirigatstudium am Konservatorium Luxemburg bei Prof. Carlo Jans. Weiterführende private Studien und Meisterkurse, z.B. bei Jan Cober, Pierre Kuijpers und Walter Ratzek, folgten. Als Dirigent sammelte er Erfahrungen beim „National Chamber Orchestra of Lettland“, dem „Sinfonischen Blasorchester des Konservatoriums Luxemburg“ der „Philharmonie Südwestfalen“ und dem „Rundfunkblasorchester Leipzig / Sächsische Bläserphilharmonie“. Besondere Impulse erhielt er im Jahr 2010 von Sir Colin Davis, im Rahmen einer Hospitation bei der „Staatskapelle Dresden“ an der Semperoper, sowie durch einen Meisterkurs bei Kurt Masur im Jahr 2011.\r\n\r\nRainer Becker ist seit Juni 2002 Leiter der Musikschule Havixbeck und Dirigent des „Jugendorchester Havixbeck“ - das seit dem „Deutschen Orchesterwettbewerb 2012“ den Titel „bestes deutsches Jugendblasorchester“ trägt. Der „Deutsche Musikrat“ zeichnete Rainer Becker bereits beim „Deutschen Orchesterwettbewerb 2004“ für seine Leistungen mit dem „Jugendorchester Havixbeck“ mit einem Förderstipendium aus.\r\n\r\nNeben seiner Tätigkeit in Havixbeck ist Rainer Becker als Gastdirigent bei verschiedenen Orchestern und Ensembles tätig. Seit 2006 hat er einen Lehrauftrag für Euphonium an der Universität Dortmund. Zudem verfügt er über Studienabschlüsse in den Fächern „Rechtswissenschaft“ und „Politikwissenschaft“.', 'Reiner Becker', '', 'publish', 'closed', 'closed', '', 'reiner-becker', '', '', '2015-12-13 17:50:15', '2015-12-13 16:50:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=244', 0, 'dozenten', '', 0),
(245, 1, '2015-12-13 17:48:24', '2015-12-13 16:48:24', '', 'rainerbecker02', '', 'inherit', 'open', 'closed', '', 'rainerbecker02', '', '', '2015-12-13 17:48:24', '2015-12-13 16:48:24', '', 244, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/rainerbecker02.jpg', 0, 'attachment', 'image/jpeg', 0),
(246, 1, '2015-12-13 17:51:48', '2015-12-13 16:51:48', 'im Alter von 9 Jahren erster Musikunterricht im Fach Klarinette\r\n- Klarinettist im Heeresmusikkorp 7 in Düsseldorf\r\n- Musikstudium in Enschede/NL im Fach Klassisches Saxophon bei Dozent Arno Bornkamp\r\n- Studium der Künstlerischen Ausbildungsklasse an der Hochschule für Musik und Theater in Hannover\r\n- Orchestertätigkeit im Sinfonieorchester Enschede, und bei den Rundfunkorchestern des WDR in Köln und SWR in Stuttgart\r\n- Mehrfacher Preisträger internationaler Wettbewerbe als Solist und mit dem "Quadrophonia Saxophonquartett"\r\n- Komponist und Musiker bei Hörspielproduktionen des WDR\r\n- Freiberuflicher Autor im AMA-Verlag\r\n- Deutscher Musikeditionspreis für das Buch "Saxophon ab 140"\r\n- Absolvent des Kontaktstudiengangs "Kultur- & Bildungsmanagement" an der Hochschule für Wirtschaft und Politik in Hamburg\r\n- Unterrichtstätigkeit an den Musikschulen in Nordhorn, Borken, Gronau und Havixbeck\r\n- Lehrertätigkeit an der Schönstätter Marienschule Borken und an der Christoph-Stöver-Realschule in Oer-Erkenschwick', 'Matthias Böyer', '', 'publish', 'closed', 'closed', '', 'matthias-boeyer', '', '', '2015-12-13 17:51:48', '2015-12-13 16:51:48', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=246', 0, 'dozenten', '', 0),
(247, 1, '2015-12-13 17:51:44', '2015-12-13 16:51:44', '', 'byermatthias2423', '', 'inherit', 'open', 'closed', '', 'byermatthias2423', '', '', '2015-12-13 17:51:44', '2015-12-13 16:51:44', '', 246, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/byermatthias2423.jpg', 0, 'attachment', 'image/jpeg', 0),
(248, 1, '2015-12-13 17:52:41', '2015-12-13 16:52:41', 'Juliette Boinay hat zunächst am „Conservatoire National“ in Paris Klassisches Ballett studiert und anschließend an der „Folkwang-Hochschule“ in Essen weiterführende Studien in „Zeitgenössischem Tanz“ abgeschlossen. Von 1996 bis 2004 war Juliette Boinay als Solo-Tänzerin, unter der Leitung von Daniel Goldin, bei den Städtischen Bühnen Münster engagiert. Inzwischen arbeitet sie als freiberufliche Tänzerin und Choreographin.', 'Juliette Boinay', '', 'publish', 'closed', 'closed', '', 'juliette-boinay', '', '', '2015-12-13 17:52:41', '2015-12-13 16:52:41', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=248', 0, 'dozenten', '', 0),
(249, 1, '2015-12-13 17:52:30', '2015-12-13 16:52:30', '', 'boinayjuliette9501', '', 'inherit', 'open', 'closed', '', 'boinayjuliette9501', '', '', '2015-12-13 17:52:30', '2015-12-13 16:52:30', '', 248, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/boinayjuliette9501.jpg', 0, 'attachment', 'image/jpeg', 0),
(250, 1, '2015-12-13 17:53:18', '2015-12-13 16:53:18', ' Nina Bühn erhielt ihren ersten Trompetenunterricht bereits im Alter von sechs Jahren. Erste musikalische Erfahrungen sammelte sie im Posaunenchor Nottuln und später in der Big Band. Mit zwölf Jahren kam als Zweitinstrument noch das Klavier hinzu.\r\n\r\n2005 führte Nina Bühns Weg an die Musikschule nach Havixbeck, wo sie von Rainer Becker mehrere Jahre Unterricht im Fach „Trompete“ erhielt und auch in das „Jugendorchester Havixbeck“ eintrat, in dem sie noch heute sehr aktiv ist.\r\n\r\nSeit Oktober 2009 studiert Nina Bühn Musik an der „Musikhochschule Münster“, im künstlerischen Hauptfach „Trompete“, in der Klasse von Herrn Albrecht Eichberger, dessen Schülerin sie bereits seit 2008 war.\r\n\r\nNeben dem „Jugendorchester Havixbeck“ wirkt Nina Bühn in landesweiten Auswahlorchestern wie z. B: der „Jungen Bläserphilharmonie NRW“ sowie der „Youth Brass Band NRW“ mit.\r\n\r\n2008 wurde schließlich ihr Interesse am Dirigieren geweckt und sie nahm Studien begleitenden Dirigierunterricht bei Rainer Becker. An der Musikschule Havixbeck leitete sie als Codirigentin das „Aufbaustufenorchester“ und im Mai 2009 übernahm sie auch noch die Leitung des „Vororchesters Laer“.\r\n\r\nSchon seit dem Jahr 2007 gibt Nina Bühn privaten Trompetenunterricht. An der Musikschule Havixbeck unterrichtet die Trompetenstudentin seit September 2009. Seit dem Schuljahr 2009/10 ist sie zudem als Dozentin in der „Musizierklasse“ der Baumberge Grundschule Havixbeck tätig und führt Kinder ab der 2. Klasse an das Trompetespielen heran.', 'Nina Bühn', '', 'publish', 'closed', 'closed', '', 'nina-buehn', '', '', '2015-12-13 17:53:38', '2015-12-13 16:53:38', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=250', 0, 'dozenten', '', 0),
(251, 1, '2015-12-13 17:53:33', '2015-12-13 16:53:33', '', 'bhnnina4201', '', 'inherit', 'open', 'closed', '', 'bhnnina4201', '', '', '2015-12-13 17:53:33', '2015-12-13 16:53:33', '', 250, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/bhnnina4201.jpg', 0, 'attachment', 'image/jpeg', 0),
(252, 1, '2015-12-13 17:54:54', '2015-12-13 16:54:54', ' Der Diplom-Musiklehrer und Diplom-Konzertgitarrist  studierte Gitarre an der Hochschule für Musik in Münster bei Prof. Reinbert Evers. Dort absolvierte er die Künstlerische Reife mit Auszeichnung und war Assistent für Kammermusik\r\n\r\nWährend des Studiums besuchte er Meisterkurse bei u. a. Olivier Chassain, Marco Socias, Anniello Desiderio, Yves Storms, Thomas Müller - Pering, Hubert Käppel und Eliot Fisk. Seine musikalische Ausbildung vervollständigte er in den Niederlanden an der Hogeschool Enschede, wo er bei Prof. Louis Ignatius Gall die staatliche Prüfung für Musikschullehrer und das Konzertexamen ablegte.  \r\n\r\nWeiterhin folgten zahlreiche Rundfunk- und CD-Produktionen. Als Solist und in verschiedenen Besetzungen gab er Konzerte in den Niederlanden, Deutschland, Spanien, Portugal, Griechenland, Bulgarien, auf Zypern und in Japan.\r\n\r\nBoian Bukov unterrichtet seit 1990 an verschiedenen städtischen und privaten Musikschulen. Viele seiner Schüler waren Preisträger beim Wettbewerb „Jugend musiziert “, spielen in etablierten Bands oder studieren Musik an Hochschulen und Universitäten.  \r\n\r\nGitarrenunterricht für Kinder, Jugendliche und Erwachsene, Anfänger und Fortgeschrittene. Gitarre (Klassik, Liedbegleitung, Fingerpicking, Flamenco), E-Gitarre, E-Bass (Pop, Rock, Blues, Jazz, Funk, Heavy Metal) und Ukulele.', 'Boian Bukav', '', 'publish', 'closed', 'closed', '', 'boian-bukav', '', '', '2015-12-13 17:55:14', '2015-12-13 16:55:14', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=252', 0, 'dozenten', '', 0),
(253, 1, '2015-12-13 17:55:09', '2015-12-13 16:55:09', '', 'bukovboian7435', '', 'inherit', 'open', 'closed', '', 'bukovboian7435', '', '', '2015-12-13 17:55:09', '2015-12-13 16:55:09', '', 252, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/bukovboian7435.jpg', 0, 'attachment', 'image/jpeg', 0),
(254, 1, '2015-12-13 18:29:29', '2015-12-13 17:29:29', 'Lothar studierte mit Hauptfach "Tuba" an den Musikhochschulen in Düsseldorf und Aachen. 1997 erlangte er zusätzlich das Konzertexamen der renomierten Essener Folkwang-Hochschule. Von 1988 bis 2000 war er Dozent für Tuba und Bariton an der Musikschule Düren und seit 1993 Mitglied des Philharmonischen Orchesters der Stadt Dortmund.', 'Esser, Lothar', '', 'publish', 'closed', 'closed', '', 'esser-lothar', '', '', '2015-12-13 18:29:29', '2015-12-13 17:29:29', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=254', 0, 'dozenten', '', 0),
(255, 1, '2015-12-13 18:29:25', '2015-12-13 17:29:25', '', 'lotharesser', '', 'inherit', 'open', 'closed', '', 'lotharesser', '', '', '2015-12-13 18:29:25', '2015-12-13 17:29:25', '', 254, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/lotharesser.jpg', 0, 'attachment', 'image/jpeg', 0),
(256, 1, '2015-12-13 18:34:03', '2015-12-13 17:34:03', 'Norbert Fabritius erhielt seinen Unterricht auf der Trompete bei Jürgen Schuster (WDR-Rundfunkorchester) und Fred Spliesger (Trompeter an der Bonner Oper). Später studierte er bei Albrecht Eichberger in Münster und bei Prof. Klaus Schuhwerk in Mainz.\r\n\r\nVon 1992 bis 1993 war Norbert Fabritius Trompeter beim Staabsmusikkorps der Bundeswehr. 1997 und 1998 besuchte er die internationale Orchesterakademie des „Collegium Musicum“ auf Schloss Pommersfelden. Neben seiner Aushilfstätigkeit an den Städtischen Bühnen in Münster wirkt er als Trompeter in vielen Orchestern und Ensembles mit.\r\n\r\nBereits mit dem Berufsstart begann auch sein pädagogisches Engagement. Neben seiner Anstellung an der Musikschule in Roxel als Trompetenlehrer leitet er Bläserklassenprojekte und Jugendensembles an verschiedenen Schulen.\r\n\r\nAls Solist musiziert Norbert Fabritius mit verschiedenen Ensembles u. a. mit der alten Philharmonie Münster, Symphonieorchester Rheine und mit seiner Solopartnerin Jutta Bitsch (Orgel). Als Kammermusikpartner spielt er in verschiedenen Kammermusikgruppen wie den Münsteraner Dombläsern, dem Ensemble „Hörsinn“, dem Ensemble „Neutonwerk“ und dem Blechblasquintett „Brass@5“.\r\n\r\nSeine Ausbildung als Dirigent erhielt er bei Werner Marihart in Münster und besuchte Meisterkurse u. a. bei Enrico Delamboye.\r\n\r\n2002 bis 2009 leitete Norbert Fabritius das Musikkorps der Freiwilligen Feuerwehr Münster und von 2003 bis 2010 den MV Loope. 2002 gründete er das Jugendblasorchester Roxel, welches bis heute unter seiner Leitung steht. Seit 2010 ist er musikalischer Leiter der Jugendmusik Havixbeck und der „Dombläser“ Münster.', 'Fabritius, Norbert', '', 'publish', 'closed', 'closed', '', 'fabritius-norbert', '', '', '2015-12-14 17:13:15', '2015-12-14 16:13:15', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=256', 0, 'dozenten', '', 0),
(257, 1, '2015-12-13 18:33:53', '2015-12-13 17:33:53', '', 'fabritiusnorbert5557', '', 'inherit', 'open', 'closed', '', 'fabritiusnorbert5557', '', '', '2015-12-13 18:33:53', '2015-12-13 17:33:53', '', 256, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/fabritiusnorbert5557.jpg', 0, 'attachment', 'image/jpeg', 0),
(258, 1, '2015-12-13 18:35:16', '2015-12-13 17:35:16', 'Leonardo Gálvez wurde in Los Angeles (Chile) geboren. Sein Musikstudium hat er an der Universität von Concepcion in Chile absolviert. Im Jahr 1980 legte er dort sein Staatsexamen als Musiklehrer ab und im Jahr 1985 seine Reifeprüfung im Fach Klavier bei der Professorin Marcella Mazzinni.\r\n\r\nZwischen 1980-1981 nahm Leonardo Gálvez in Chile Dirigierunterricht bei Professor Joahim Harder von der Detmolder Hochschule für Musik.\r\n\r\nIm Jahr 1983 und 1984 nahm er an der Universität von Cuyo Mendoza (Argentinien), an Dirigierkursen mit dem dortigen Sinfonieorchester, bei Professor Guillermo Scarabino teil.\r\n\r\nSeit 1986 lebt Leonardo Gálvez in der Bundesrepublik Deutschland. Er arbeitete als Dirigent des VHS Orchesters Warendorf (1991-2001), des Kammerorchesters Ars Musika (1993-2011) und des Mozart-Orchesters Münster (2000-2007).\r\n\r\nSeit 1990 arbeitet Leonardo Gálvez als Klavierlehrer an der Musikschule Bergkamen und seit Juni 2013 an der Musikschule in Havixbeck.', 'Gálvez, Leonardo', '', 'publish', 'closed', 'closed', '', 'galvez-leonardo', '', '', '2015-12-13 18:35:16', '2015-12-13 17:35:16', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=258', 0, 'dozenten', '', 0),
(259, 1, '2015-12-13 18:34:59', '2015-12-13 17:34:59', '', 'glvezleonardo5576', '', 'inherit', 'open', 'closed', '', 'glvezleonardo5576', '', '', '2015-12-13 18:34:59', '2015-12-13 17:34:59', '', 258, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/glvezleonardo5576.jpg', 0, 'attachment', 'image/jpeg', 0),
(260, 1, '2015-12-13 18:36:14', '2015-12-13 17:36:14', 'Jasmin Garlik absolvierte ihre musikalische Ausbildung an der Städtischen Musikschule Bergkamen in den Fächern Klarinette und Klavier. Nach dem Abitur begann sie 2008 ihr Studium „Instrumentalpädagogik im Hauptfach Klarinette“ an der Musikhochschule Münster in der Klasse von Prof. Werner Raabe.\r\n\r\nNeben der Mitwirkung in verschiedenen Münsteraner Orchestern, darunter die „Alte Philharmonie Münster“ unter der Leitung von Thorsten Schmid-Kapfenburg und das „Studentenorchester Münster“ unter der Leitung von Prof. Joachim Harder, war sie im WS 2009/2010 Mitglied im „Ensemble Neue Musik“ unter der Leitung von Prof. Rene Gulikers.\r\n\r\nSeit September 2010 unterrichtet Jasmin Garlik an der Musikschule Havixbeck Klarinette. Des Weiteren ist sie seit 2009 Klarinettenlehrerin an der Musikschule Münster e.V. und seit 2011 Lehrkraft an der Städtischen Musikschule Lünen. Seit dem Schuljahr 2010/2011 ist sie zudem als Lehrkraft im Bereich der „Musizierklasse“ an der Baumberge Grundschule Havixbeck tätig.', 'Garlik, Jasmin', '', 'publish', 'closed', 'closed', '', 'garlik-jasmin', '', '', '2015-12-13 18:36:14', '2015-12-13 17:36:14', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=260', 0, 'dozenten', '', 0),
(261, 1, '2015-12-13 18:36:06', '2015-12-13 17:36:06', '', 'garlikjasmin8589', '', 'inherit', 'open', 'closed', '', 'garlikjasmin8589', '', '', '2015-12-13 18:36:06', '2015-12-13 17:36:06', '', 260, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/garlikjasmin8589.jpg', 0, 'attachment', 'image/jpeg', 0),
(262, 1, '2015-12-13 18:37:50', '2015-12-13 17:37:50', 'Jenny Haecker ist in Münster geboren und aufgewachsen, studierte Gesang und Gesangspädagogik an der Musikhochschule Köln, Abteilung Wuppertal, in der Klasse von Prof. Barbara Schlick.\r\n\r\nIm Anschluss absolvierte sie den Aufbaustudiengang "Operngesang" bei Prof. Anna Maria Dur an der "Staatlichen Hochschule für Musik und Darstellende Kunst" in Mannheim.\r\n\r\nZu Beginn ihrer Studien sammelte sie vor allem Erfahrungen im Bereich der "Alten Musik", u.a. als Mitglied der "Rheinischen Kantorei" unter Hermann Max, wo sie auch solistische Partien übernahm. Nach und nach lenkte sich ihr Augenmerk auf den Bereich "Oper". An den "Städtischen Bühnen Wuppertal" und dem "Stadttheater Gießen" war sie sowohl als Mitglied des Chores als auch als Solistin zu hören.\r\n\r\nNeben ihrer regen Konzerttätigkeit ist Jenny Haecker seit 2007 sowohl privat als auch an Musikschulen als Gesangs- und Musikpädagogin tätig.\r\n\r\nAn der Musikschule Havixbeck unterrichtet Jenny Haecker das Fach Gesang.\r\n', 'Haecker, Jenny', '', 'publish', 'closed', 'closed', '', 'haecker-jenny', '', '', '2015-12-13 18:37:50', '2015-12-13 17:37:50', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=262', 0, 'dozenten', '', 0),
(263, 1, '2015-12-13 18:37:43', '2015-12-13 17:37:43', '', 'haeckerjenny4853', '', 'inherit', 'open', 'closed', '', 'haeckerjenny4853', '', '', '2015-12-13 18:37:43', '2015-12-13 17:37:43', '', 262, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/haeckerjenny4853.jpg', 0, 'attachment', 'image/jpeg', 0),
(264, 1, '2015-12-13 18:39:40', '2015-12-13 17:39:40', 'Taulant Haxhikadrija, geboren in Gjakova (Kosovo), bekam seinen ersten  Klarinettenunterricht mit 9 Jahren an der Musikschule seiner Geburtsstadt. Seine Ausbildung setzte er in Pristina am Gymnasium für Musik fort. Während dieser Zeit gewann er den ersten Preis des Jugendmusikwettbewerbes im Kosovo.\r\n\r\n2005 führte ihn das Musikstudium nach Deutschland. Seitdem studiert er an der Musikhochschule Münster bei Prof. Werner Raabe, Hauptfach Klarinette. Er widmet sich der klassischen Klarinettenliteratur, wie auch dem Jazz und anderen Stilrichtungen, u.a. auch der Folklore.\r\n\r\nEr tritt als Solist in verschiedenen Kammermusikensembles und als Orchestermusiker im Orchester der Musikhochschule Münster und dem Jugendsinfonieorchester Münster auf.', 'Haxhikadrija, Taulant', '', 'publish', 'closed', 'closed', '', 'haxhikadrija-taulant', '', '', '2015-12-13 18:39:40', '2015-12-13 17:39:40', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=264', 0, 'dozenten', '', 0),
(265, 1, '2015-12-13 18:39:33', '2015-12-13 17:39:33', '', 'haxhikadrijataulant7810', '', 'inherit', 'open', 'closed', '', 'haxhikadrijataulant7810', '', '', '2015-12-13 18:39:33', '2015-12-13 17:39:33', '', 264, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/haxhikadrijataulant7810.jpg', 0, 'attachment', 'image/jpeg', 0),
(266, 1, '2015-12-13 18:42:28', '2015-12-13 17:42:28', 'Martin Heemann versteht sich keinesfalls als Gralshüter der Jazz-Tradition, vielmehr bietet seine Musik eine reiche Palette an harmonischen Überraschungen und melodischen Ideen. So verbindet sich seine soulorientierte, kraftvolle Spielweise mit Elementen aus Avantgarde und Weltmusik zu einem besonderen musikalischen Cocktail.\r\nMartin Heeman hat sowohl klassisches Saxophon bei Werner Böckmann in Münster studiert, als auch Jazz bei Ferdinand Povel und Herman Schonderwolt am Konservatorium Hilversum. Desweiteren wurde er unterrichtet, von Jean-Marie Londeix und Eugene Rosseau.\r\n\r\nEr arbeitet als Saxophonist u. a. mit und für:\r\n<ul style="list-style-type:circle;">\r\n	<li>Städtische Bühnen Münster und Hagen</li>\r\n	<li>Barbara Dennerlein,</li>\r\n	<li>Kansas City Jazz Orchestra,</li>\r\n	<li>Starlight Express, Bochum</li>\r\n	<li>WWU Big Band,</li>\r\n	<li>Monday Night Jazz Orchestra;</li>\r\n	<li>Electric Brew</li>\r\n	<li>Rockorchester Ruhrgebeat</li>\r\n</ul>\r\n<strong>Aktuelle CD:</strong>\r\nHeemann/Wanning Quartett: "November"\r\nerschienen 12/2002', 'Heemann, Martin', '', 'publish', 'closed', 'closed', '', 'heemann-martin', '', '', '2015-12-13 18:55:29', '2015-12-13 17:55:29', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=266', 0, 'dozenten', '', 0),
(267, 1, '2015-12-13 18:42:17', '2015-12-13 17:42:17', '', 'heemann', '', 'inherit', 'open', 'closed', '', 'heemann', '', '', '2015-12-13 18:42:17', '2015-12-13 17:42:17', '', 266, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/heemann.jpg', 0, 'attachment', 'image/jpeg', 0),
(268, 1, '2015-12-13 18:56:56', '2015-12-13 17:56:56', 'Burkhard Heidbrink began mit 15 Jahren sich ernsthaft für den Kontrabass zu interessieren, und nahm ab diesem Zeitpunkt Unterricht im klassischen Kontrabassspiel. Nach dem Abitur studierte er Musik mit dem Hauptfach Kontrabass. Seine Lehrer und Mentoren waren Hein Czaske (Münster), Klaus Stoll (Berin) und heinz Hermann (Dresden/Köln). Nach dem Abschluss seines Studiums begann seine Lehrtätigkeit an der Westfälischen Schule für Musik. Burkhard Heidbrink spielt in verschidenen Ensembles: Kammerorchester, Slonorchester, Big Band und klein Jazzbesetzungen. als Dozent für Kontrabass unterrichtet er zurzeit an der Universität Münster.\r\n\r\nSchüler von Burkhard Heidbrink haben bereits mehrfach Preise bei "jugend Musiziert" bis hin zum bundeswettbewerb errungen und spielen in verschiedenen Auswahlorchestern wie dem Landes- oder dem Bundesjugendorchester.', 'Heidbrink, Burkhard', '', 'publish', 'closed', 'closed', '', 'heidbrink-burkhard', '', '', '2015-12-13 18:56:56', '2015-12-13 17:56:56', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=268', 0, 'dozenten', '', 0),
(269, 1, '2015-12-13 18:56:37', '2015-12-13 17:56:37', '', 'heidbrink_burkhardt', '', 'inherit', 'open', 'closed', '', 'heidbrink_burkhardt', '', '', '2015-12-13 18:56:37', '2015-12-13 17:56:37', '', 268, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/heidbrink_burkhardt.jpg', 0, 'attachment', 'image/jpeg', 0),
(270, 1, '2015-12-13 18:58:12', '2015-12-13 17:58:12', 'Vanessa Hövelmann erhielt ihre musikalische Ausbildung an der Westfälischen Schule für Musik in Münster, zunächst in den Fächern Klarinette und Klavier. Nach Landes- und Bundespreisen im Wettbewerb „Jugend Musiziert“ (Klarinette, Kammermusik und Klavierbegleitung) kam später als weiteres Instrument noch das Violoncello dazu.\r\n\r\nVon 1998 bis 2004 studierte Vanessa Hövelmann an der Musikhochschule Münster Violoncello (Instrumentalpädagogik) bei Frieder Lenz, seit 2004 Klarinette (künstlerische Ausbildung) bei Werner Raabe. Meisterkurse bei Karl Leister (Klarinette), Alexander Baillie (Cello) und Kurse in Resonanzlehre und Dispokinese sorgten für zusätzliche Impulse.\r\n\r\nNeben der Mitwirkung in verschiedenen Münsteraner Orchestern (Orchester der Musikhochschule, Alte Philharmonie Münster, Studentenorchester Münster, Junges Sinfonieorchester der WWU Münster, Pro-Musica-Orchester Münster) ist Vanessa Hövelmann vor allem in verschiedenen kammermusikalischen Ensembles künstlerisch tätig, insbesondere als Gründungsmitglied des seit 2005 bestehenden „ENSEMBLE:HÖRSINN“ für Neue Musik mit Konzerten und Schulprojekten in Münster und Umgebung. Der Unterhaltungsmusik widmet sie sich als Klarinettistin zusammen mit dem Pianisten Manfred Sasse als „Duo Dezim“ und, als Cellistin, in der Caféhausmusik-Formation „Espress-iv-o“ (Geige, Cello, Klavier).\r\n\r\nSeit September 2004 unterrichtet Vanessa Hövelmann an der Musikschule Havixbeck Klarinette.', 'Hövelmann, Vanessa', '', 'publish', 'closed', 'closed', '', 'hoevelmann-vanessa', '', '', '2015-12-13 18:58:12', '2015-12-13 17:58:12', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=dozenten&#038;p=270', 0, 'dozenten', '', 0),
(271, 1, '2015-12-13 18:57:53', '2015-12-13 17:57:53', '', 'hvelmannvanessa2071', '', 'inherit', 'open', 'closed', '', 'hvelmannvanessa2071', '', '', '2015-12-13 18:57:53', '2015-12-13 17:57:53', '', 270, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/12/hvelmannvanessa2071.jpg', 0, 'attachment', 'image/jpeg', 0),
(272, 1, '2015-12-13 19:00:51', '2015-12-13 18:00:51', 'Damit die Wahl nicht zur Qual wird, haben wir für Sie unser komplettes Angebot alphabetisch aufgelistet. Ein übersichtliches und kompaktes CrossOver aus unserem Register: Instrumente, Gesang, ergänzende Fächer, Musikalische Elementarerziehung und Musik als gemeinschaftliches Erlebnis.\n\n', 'Fächer A-Z', '', 'inherit', 'closed', 'closed', '', '132-autosave-v1', '', '', '2015-12-13 19:00:51', '2015-12-13 18:00:51', '', 132, 'http://localhost/musikschule-wp-theme/wordpress/132-autosave-v1/', 0, 'revision', '', 0),
(273, 1, '2015-12-14 15:40:37', '2015-12-14 14:40:37', 'An der Musikschule Havixbeck kann man über 20 Instrumente erlernen - Von Klassik bis Jazz, vom Klavier bis zur E-Gitarre, findet sich hier Traditionsreiches wie Modernes unter einem Dach. Stöbern Sie in unserem umfangreichen Angebot und informieren Sie sich zusätzlich über Unterrichtsformen, ergänzende Lehrveranstaltungen und Dozenten.', 'Instrumente', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-12-14 15:40:37', '2015-12-14 14:40:37', '', 72, 'http://localhost/musikschule-wp-theme/wordpress/72-revision-v1/', 0, 'revision', '', 0),
(274, 1, '2015-12-14 16:07:20', '2015-12-14 15:07:20', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Maecenas sed diam eget risus varius blandit sit amet non magna.\r\n\r\nNullam quis risus eget urna mollis ornare vel eu leo. Maecenas faucibus mollis interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Maecenas faucibus mollis interdum. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Freddy hat Geburtstag', '', 'publish', 'open', 'closed', '', 'freddy-hat-geburtstag', '', '', '2015-12-14 16:07:20', '2015-12-14 15:07:20', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=tribe_events&#038;p=274', 0, 'tribe_events', '', 0),
(275, 1, '2015-12-14 16:07:20', '2015-12-14 15:07:20', '', 'Garage', '', 'publish', 'closed', 'closed', '', 'garage', '', '', '2015-12-14 16:07:20', '2015-12-14 15:07:20', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/veranstaltungsort/garage/', 0, 'tribe_venue', '', 0),
(278, 1, '2015-12-14 16:34:15', '2015-12-14 15:34:15', 'BLÄSERKLASSE IN KOOPERATION MIT DER ANNE-FRANK-GESAMTSCHULE\r\n\r\nDie Einrichtung einer Musikklasse zum Schuljahr 2006/07 an der Anne-Frank-Gesamtschule ist beschlossen. Die Musikklasse wird stark mit der Musikschule kooperieren und bietet den teilnehmenden Schülerinnen und Schüler der 5. Klasse an, ein Instrument im regulären Schulunterricht über zwei Schuljahre zu erlernen. Dazu gehören die Instrumente Querflöte, Klarinette, Saxophon, Trompete, Horn, Euphonium und Tuba. Die musikalische Leitung der Bläserklasse wird die Gesamtschullehrerin Stefanie Aehlen übernehmen. Weiterhin werden sechs Instrumentalpädagogen den Unterricht der Bläserklasse mitgestalten. Für den Unterricht stellt die Musikschule Havixbeck ihre Räumlichkeiten und die Mietinstrumente zu Verfügung.\r\nWeitere Infos:\r\n• In der 5. und 6. Jahrgangsstufe wird eine BläserKlasse im  Klassenverband gegründet.\r\n• Der reguläre Musikunterricht wird zum Erlernen eines Orchesterinstrumentes genutzt.\r\n• Wir wollen eine gezielte Kooperation mit der Anne-Frank-Gesamtschule eingehen.\r\nInstrumente\r\n• Werden gemietet: im Mietpreis ist die Grundausstattung sowie eine Instrumentenversicherung inbegriffen.\r\nWie kommen die Kinder zu ihren Instrumenten?\r\n• Ausprobieren aller Instrumente\r\n• Wahl der 3 Wunschinstrumente\r\n• Entscheidung bis zum nächsten Tag\r\n   \r\n4 Stunden Musikunterricht bestehen aus:\r\n– 2 Stunden Orchesterunterricht im Klassenverband\r\n– 1 Stunde Instrumentalunterricht in Kleingruppen\r\n– 1 Stunde Theorieunterricht im Klassenverband ohne Instrumente\r\nRäume\r\n• Die Musikschule stellt für den Orchesterunterricht im Klassenverband den großen Probenraum zur Verfügung.\r\n• Für den Instrumentalunterricht in Kleingruppen stellt die Musikschule entsprechende Übungsräume zur Verfügung.\r\n• Der Theorieunterricht findet in den Musikräumen der AFG statt.\r\nWer unterrichtet was?\r\n• Orchesterunterricht: Frau Kneip, Herr Weißer\r\n• Instrumentalunterricht in Kleingruppen: 6 zusätzliche Instrumentalpädagogen\r\n• Theorieunterricht:  Frau Kneip, Herr Weißer\r\nLehrwerke\r\n• Für den Instrumentalunterricht wird das Yamaha-Lehrwerk „Essential Elements“ angeschafft.\r\n• Für den Theorieunterricht wird das D1-Heft für Blasorchester angeschafft.\r\nDie Schülerinnen und Schüler haben die Möglichkeit, die theoretische D1-Zertifikatsprüfung abzulegen\r\nFinanzierung\r\n• Monatliche Elternbeiträge für die Instrumentenmiete und anteilig für die Bezahlung der Instrumentalpädagogen\r\n• Einmalige Kosten für Notenmaterial', 'Bläserklasse', '', 'inherit', 'closed', 'closed', '', '130-revision-v1', '', '', '2015-12-14 16:34:15', '2015-12-14 15:34:15', '', 130, 'http://localhost/musikschule-wp-theme/wordpress/130-revision-v1/', 0, 'revision', '', 0),
(279, 1, '2015-12-14 16:35:26', '2015-12-14 15:35:26', 'BLÄSERKLASSE IN KOOPERATION MIT DER ANNE-FRANK-GESAMTSCHULE\r\n\r\nDie Einrichtung einer Musikklasse zum Schuljahr 2006/07 an der Anne-Frank-Gesamtschule ist beschlossen. Die Musikklasse wird stark mit der Musikschule kooperieren und bietet den teilnehmenden Schülerinnen und Schüler der 5. Klasse an, ein Instrument im regulären Schulunterricht über zwei Schuljahre zu erlernen. Dazu gehören die Instrumente Querflöte, Klarinette, Saxophon, Trompete, Horn, Euphonium und Tuba. Die musikalische Leitung der Bläserklasse wird die Gesamtschullehrerin Stefanie Aehlen übernehmen. Weiterhin werden sechs Instrumentalpädagogen den Unterricht der Bläserklasse mitgestalten. Für den Unterricht stellt die Musikschule Havixbeck ihre Räumlichkeiten und die Mietinstrumente zu Verfügung.\r\n\r\nWeitere Infos:\r\n\r\n• In der 5. und 6. Jahrgangsstufe wird eine BläserKlasse im  Klassenverband gegründet.\r\n• Der reguläre Musikunterricht wird zum Erlernen eines Orchesterinstrumentes genutzt.\r\n• Wir wollen eine gezielte Kooperation mit der Anne-Frank-Gesamtschule eingehen.\r\n\r\nInstrumente\r\n\r\n• Werden gemietet: im Mietpreis ist die Grundausstattung sowie eine Instrumentenversicherung inbegriffen.\r\n\r\nWie kommen die Kinder zu ihren Instrumenten?\r\n\r\n• Ausprobieren aller Instrumente\r\n• Wahl der 3 Wunschinstrumente\r\n• Entscheidung bis zum nächsten Tag\r\n   \r\n4 Stunden Musikunterricht bestehen aus:\r\n– 2 Stunden Orchesterunterricht im Klassenverband\r\n– 1 Stunde Instrumentalunterricht in Kleingruppen\r\n– 1 Stunde Theorieunterricht im Klassenverband ohne Instrumente\r\n\r\nRäume\r\n\r\n• Die Musikschule stellt für den Orchesterunterricht im Klassenverband den großen Probenraum zur Verfügung.\r\n• Für den Instrumentalunterricht in Kleingruppen stellt die Musikschule entsprechende Übungsräume zur Verfügung.\r\n• Der Theorieunterricht findet in den Musikräumen der AFG statt.\r\n\r\nWer unterrichtet was?\r\n\r\n• Orchesterunterricht: Frau Kneip, Herr Weißer\r\n• Instrumentalunterricht in Kleingruppen: 6 zusätzliche Instrumentalpädagogen\r\n• Theorieunterricht:  Frau Kneip, Herr Weißer\r\n\r\nLehrwerke\r\n\r\n• Für den Instrumentalunterricht wird das Yamaha-Lehrwerk „Essential Elements“ angeschafft.\r\n• Für den Theorieunterricht wird das D1-Heft für Blasorchester angeschafft.\r\nDie Schülerinnen und Schüler haben die Möglichkeit, die theoretische D1-Zertifikatsprüfung abzulegen\r\n\r\nFinanzierung\r\n\r\n• Monatliche Elternbeiträge für die Instrumentenmiete und anteilig für die Bezahlung der \r\n\r\nInstrumentalpädagogen\r\n\r\n• Einmalige Kosten für Notenmaterial', 'Bläserklasse', '', 'inherit', 'closed', 'closed', '', '130-revision-v1', '', '', '2015-12-14 16:35:26', '2015-12-14 15:35:26', '', 130, 'http://localhost/musikschule-wp-theme/wordpress/130-revision-v1/', 0, 'revision', '', 0),
(280, 1, '2015-12-14 16:36:30', '2015-12-14 15:36:30', 'BLÄSERKLASSE IN KOOPERATION MIT DER ANNE-FRANK-GESAMTSCHULE\r\n\r\nDie Einrichtung einer Musikklasse zum Schuljahr 2006/07 an der Anne-Frank-Gesamtschule ist beschlossen. Die Musikklasse wird stark mit der Musikschule kooperieren und bietet den teilnehmenden Schülerinnen und Schüler der 5. Klasse an, ein Instrument im regulären Schulunterricht über zwei Schuljahre zu erlernen. Dazu gehören die Instrumente Querflöte, Klarinette, Saxophon, Trompete, Horn, Euphonium und Tuba. Die musikalische Leitung der Bläserklasse wird die Gesamtschullehrerin Stefanie Aehlen übernehmen. Weiterhin werden sechs Instrumentalpädagogen den Unterricht der Bläserklasse mitgestalten. Für den Unterricht stellt die Musikschule Havixbeck ihre Räumlichkeiten und die Mietinstrumente zu Verfügung.\r\n\r\n<strong>Weitere Infos:</strong>\r\n\r\n• In der 5. und 6. Jahrgangsstufe wird eine BläserKlasse im  Klassenverband gegründet.\r\n• Der reguläre Musikunterricht wird zum Erlernen eines Orchesterinstrumentes genutzt.\r\n• Wir wollen eine gezielte Kooperation mit der Anne-Frank-Gesamtschule eingehen.\r\n\r\n<strong>Instrumente</strong>\r\n\r\n• Werden gemietet: im Mietpreis ist die Grundausstattung sowie eine Instrumentenversicherung inbegriffen.\r\n\r\n<strong>Wie kommen die Kinder zu ihren Instrumenten?</strong>\r\n\r\n• Ausprobieren aller Instrumente\r\n• Wahl der 3 Wunschinstrumente\r\n• Entscheidung bis zum nächsten Tag\r\n   \r\n4 Stunden Musikunterricht bestehen aus:\r\n– 2 Stunden Orchesterunterricht im Klassenverband\r\n– 1 Stunde Instrumentalunterricht in Kleingruppen\r\n– 1 Stunde Theorieunterricht im Klassenverband ohne Instrumente\r\n\r\n<strong>Räume</strong>\r\n\r\n• Die Musikschule stellt für den Orchesterunterricht im Klassenverband den großen Probenraum zur Verfügung.\r\n• Für den Instrumentalunterricht in Kleingruppen stellt die Musikschule entsprechende Übungsräume zur Verfügung.\r\n• Der Theorieunterricht findet in den Musikräumen der AFG statt.\r\n\r\n<strong>Wer unterrichtet was?</strong>\r\n\r\n• Orchesterunterricht: Frau Kneip, Herr Weißer\r\n• Instrumentalunterricht in Kleingruppen: 6 zusätzliche Instrumentalpädagogen\r\n• Theorieunterricht:  Frau Kneip, Herr Weißer\r\n\r\n<strong>Lehrwerke</strong>\r\n\r\n• Für den Instrumentalunterricht wird das Yamaha-Lehrwerk „Essential Elements“ angeschafft.\r\n• Für den Theorieunterricht wird das D1-Heft für Blasorchester angeschafft.\r\nDie Schülerinnen und Schüler haben die Möglichkeit, die theoretische D1-Zertifikatsprüfung abzulegen\r\n\r\n<strong>Finanzierung</strong>\r\n\r\n• Monatliche Elternbeiträge für die Instrumentenmiete und anteilig für die Bezahlung der \r\n\r\n<strong>Instrumentalpädagogen</strong>\r\n\r\n• Einmalige Kosten für Notenmaterial', 'Bläserklasse', '', 'inherit', 'closed', 'closed', '', '130-revision-v1', '', '', '2015-12-14 16:36:30', '2015-12-14 15:36:30', '', 130, 'http://localhost/musikschule-wp-theme/wordpress/130-revision-v1/', 0, 'revision', '', 0),
(281, 1, '2015-12-14 16:41:44', '2015-12-14 15:41:44', 'Die Einrichtung einer Musikklasse zum Schuljahr 2006/07 an der Anne-Frank-Gesamtschule ist beschlossen. Die Musikklasse wird stark mit der Musikschule kooperieren und bietet den teilnehmenden Schülerinnen und Schüler der 5. Klasse an, ein Instrument im regulären Schulunterricht über zwei Schuljahre zu erlernen. Dazu gehören die Instrumente Querflöte, Klarinette, Saxophon, Trompete, Horn, Euphonium und Tuba. Die musikalische Leitung der Bläserklasse wird die Gesamtschullehrerin Stefanie Aehlen übernehmen. Weiterhin werden sechs Instrumentalpädagogen den Unterricht der Bläserklasse mitgestalten. Für den Unterricht stellt die Musikschule Havixbeck ihre Räumlichkeiten und die Mietinstrumente zu Verfügung.\r\n\r\n<strong>Weitere Infos:</strong>\r\n\r\n• In der 5. und 6. Jahrgangsstufe wird eine BläserKlasse im  Klassenverband gegründet.\r\n• Der reguläre Musikunterricht wird zum Erlernen eines Orchesterinstrumentes genutzt.\r\n• Wir wollen eine gezielte Kooperation mit der Anne-Frank-Gesamtschule eingehen.\r\n\r\n<strong>Instrumente</strong>\r\n\r\n• Werden gemietet: im Mietpreis ist die Grundausstattung sowie eine Instrumentenversicherung inbegriffen.\r\n\r\n<strong>Wie kommen die Kinder zu ihren Instrumenten?</strong>\r\n\r\n• Ausprobieren aller Instrumente\r\n• Wahl der 3 Wunschinstrumente\r\n• Entscheidung bis zum nächsten Tag\r\n   \r\n4 Stunden Musikunterricht bestehen aus:\r\n– 2 Stunden Orchesterunterricht im Klassenverband\r\n– 1 Stunde Instrumentalunterricht in Kleingruppen\r\n– 1 Stunde Theorieunterricht im Klassenverband ohne Instrumente\r\n\r\n<strong>Räume</strong>\r\n\r\n• Die Musikschule stellt für den Orchesterunterricht im Klassenverband den großen Probenraum zur Verfügung.\r\n• Für den Instrumentalunterricht in Kleingruppen stellt die Musikschule entsprechende Übungsräume zur Verfügung.\r\n• Der Theorieunterricht findet in den Musikräumen der AFG statt.\r\n\r\n<strong>Wer unterrichtet was?</strong>\r\n\r\n• Orchesterunterricht: Frau Kneip, Herr Weißer\r\n• Instrumentalunterricht in Kleingruppen: 6 zusätzliche Instrumentalpädagogen\r\n• Theorieunterricht:  Frau Kneip, Herr Weißer\r\n\r\n<strong>Lehrwerke</strong>\r\n\r\n• Für den Instrumentalunterricht wird das Yamaha-Lehrwerk „Essential Elements“ angeschafft.\r\n• Für den Theorieunterricht wird das D1-Heft für Blasorchester angeschafft.\r\nDie Schülerinnen und Schüler haben die Möglichkeit, die theoretische D1-Zertifikatsprüfung abzulegen\r\n\r\n<strong>Finanzierung</strong>\r\n\r\n• Monatliche Elternbeiträge für die Instrumentenmiete und anteilig für die Bezahlung der \r\n\r\n<strong>Instrumentalpädagogen</strong>\r\n\r\n• Einmalige Kosten für Notenmaterial', 'Bläserklasse', '', 'inherit', 'closed', 'closed', '', '130-revision-v1', '', '', '2015-12-14 16:41:44', '2015-12-14 15:41:44', '', 130, 'http://localhost/musikschule-wp-theme/wordpress/130-revision-v1/', 0, 'revision', '', 0),
(282, 1, '2015-12-14 17:01:00', '2015-12-14 16:01:00', '', 'Ensembles', '', 'publish', 'closed', 'closed', '', 'acf_ensembles', '', '', '2015-12-14 17:01:00', '2015-12-14 16:01:00', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=acf&#038;p=282', 0, 'acf', '', 0),
(283, 1, '2015-12-14 17:05:04', '2015-12-14 16:05:04', 'Die Vorraussetzung, um in der „Jugendmusik“ mitzuspielen zu können, ist eine bestandene D1-Prüfung, die sowohl eine musiktheoretische als auch eine instrumentalpraktische Prüfung umfasst. Das junge Orchester, das mittlerweile auch eigene Konzerte und so genannte „Wertungsspiele“ durchführt sowie an Musikfestivals teilnimmt, besteht zurzeit aus 43 Jugendlichen, die vorwiegend aus der Gemeinde Havixbeck kommen. Doch auch externe interessierte Musikschüler mit entsprechender musikalischer Ausbildung werden immer wieder gerne als Orchestermitglieder aufgenommen.\r\n\r\n\r\nDas Repertoire der „Jugendmusik“ umfasst leichte bis mittelschwere Werke der sinfonischen Blasmusik und Kompositionen aus dem Bereich der Unterhaltungs-, Film- und Popmusik.\r\n\r\nEine weitere bestandene D2-Prüfung ermöglicht den Mitgliedern der „Jugendmusik“ wiederum den Wechsel in das deutschlandweit bekannte „Jugendorchester Havixbeck“, dessen Mitglieder Zwischen 14 und 27 Jahren alt sind.\r\n\r\nNorbert Fabritius aus Münster konnte im Frühjahr 2010 als musikalischer Leiter der „Jugendmusik Havixbeck“ gewonnen werden.\r\n', 'Jugendmusik Havixbeck', '', 'publish', 'closed', 'closed', '', 'jugendmusik-havixbeck', '', '', '2015-12-14 17:09:16', '2015-12-14 16:09:16', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=ensembles&#038;p=283', 0, 'ensembles', '', 0),
(284, 1, '2015-12-14 17:09:06', '2015-12-14 16:09:06', 'Die Vorraussetzung, um in der „Jugendmusik“ mitzuspielen zu können, ist eine bestandene D1-Prüfung, die sowohl eine musiktheoretische als auch eine instrumentalpraktische Prüfung umfasst. Das junge Orchester, das mittlerweile auch eigene Konzerte und so genannte „Wertungsspiele“ durchführt sowie an Musikfestivals teilnimmt, besteht zurzeit aus 43 Jugendlichen, die vorwiegend aus der Gemeinde Havixbeck kommen. Doch auch externe interessierte Musikschüler mit entsprechender musikalischer Ausbildung werden immer wieder gerne als Orchestermitglieder aufgenommen.\n\n\nDas Repertoire der „Jugendmusik“ umfasst leichte bis mittelschwere Werke der sinfonischen Blasmusik und Kompositionen aus dem Bereich der Unterhaltungs-, Film- und Popmusik.\n\nEine weitere bestandene D2-Prüfung ermöglicht den Mitgliedern der „Jugendmusik“ wiederum den Wechsel in das deutschlandweit bekannte „Jugendorchester Havixbeck“, dessen Mitglieder Zwischen 14 und 27 Jahren alt sind.\n\nNorbert Fabritius aus Münster konnte im Frühjahr 2010 als musikalischer Leiter der „Jugendmusik Havixbeck“ gewonnen werden.\n', 'Jugendmusik Havixbeck', '', 'inherit', 'closed', 'closed', '', '283-autosave-v1', '', '', '2015-12-14 17:09:06', '2015-12-14 16:09:06', '', 283, 'http://localhost/musikschule-wp-theme/wordpress/283-autosave-v1/', 0, 'revision', '', 0),
(285, 1, '2015-12-14 17:26:04', '2015-12-14 16:26:04', '', 'Elementarausbildung', '', 'publish', 'closed', 'closed', '', 'acf_elementarausbildung', '', '', '2015-12-15 14:55:20', '2015-12-15 13:55:20', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=acf&#038;p=285', 0, 'acf', '', 0),
(286, 1, '2015-12-14 17:27:02', '2015-12-14 16:27:02', 'Die Kinder werden in diesem Kurs daran gewöhnt, sich auch alleine in der Gruppe zurechtzufinden. Sie werden behutsam an ein selbständiges Mitmachen in der Gruppe gewöhnt und spielerisch an die Inhalte der "Musikalischen Früherziehung" herangeführt.\r\nDer Unterricht für beide Kurse der "Musikzwerge" findet jeweils in Gruppen, mit ca. 12 Kindern, statt und beginnt immer zum neuen Schuljahr, nach den Sommerferien. ', 'Musikzwerge', '', 'publish', 'closed', 'closed', '', 'musikzwerge', '', '', '2015-12-15 15:32:33', '2015-12-15 14:32:33', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=elementarausbildung&#038;p=286', 0, 'elementarausbildung', '', 0),
(289, 1, '2015-12-15 14:53:10', '2015-12-15 13:53:10', 'Etiam porta sem malesuada magna mollis euismod. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Nulla vitae elit libero, a pharetra augue.\r\n\r\nMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas faucibus mollis interdum. Aenean lacinia bibendum nulla sed consectetur. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Donec sed odio dui.\r\n\r\nCras justo odio, dapibus ac facilisis in, egestas eget quam. Nulla vitae elit libero, a pharetra augue. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed odio dui. Duis mollis, est non commodo luctus, nisi erat porttitor ligula, eget lacinia odio sem nec elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', 'Elementarausbildung', '', 'inherit', 'closed', 'closed', '', '126-revision-v1', '', '', '2015-12-15 14:53:10', '2015-12-15 13:53:10', '', 126, 'http://localhost/musikschule-wp-theme/wordpress/126-revision-v1/', 0, 'revision', '', 0),
(290, 1, '2015-12-15 14:57:17', '2015-12-15 13:57:17', 'Kinder sind neugierig und versuchen, die Welt zu erfahren. Dazu gehört auch die Klangwelt. Unmusikalische Kinder gibt es nicht! Sie besitzen eine ursprüngliche Musikalität. Für Kinder sind Stimme und Bewegung Möglichkeiten des Ausdrucks und der Mitteilung. Die nachfolgenden Veranstaltungen dienen dazu, diese Grundbedürfnisse zu stärken.', 'Elementarausbildung', '', 'inherit', 'closed', 'closed', '', '126-revision-v1', '', '', '2015-12-15 14:57:17', '2015-12-15 13:57:17', '', 126, 'http://localhost/musikschule-wp-theme/wordpress/126-revision-v1/', 0, 'revision', '', 0),
(291, 1, '2015-12-15 15:29:26', '2015-12-15 14:29:26', 'Die Wechselwirkung von Bewegung und Musik wird in der "Musikwiese" in den Vordergrund gestellt und an das natürliche Bewegungsbedürfnis des Kindes, an seine Lust am Singen, Klatschen, Hüpfen, Experimentieren und Nachahmen, angeknüpft. Die Kinder werden durch gemeinsames Singen angeregt, die eigene Stimme zu entdecken und Freude daran zu finden, mit ihr zu spielen. Durch Fingerspiele, Tanzen und Bewegungen zur Musik lernen sie auf spielerische Art und Weise ihren Körper kennen. Mit einfachen Instrumenten wie Klanghölzern, Glöckchen oder Rasseln bekommen sie durch genaues Hinhören Freude an den Klängen und Geräuschen.\r\n\r\nDie Kurse der "Musikwiese" finden in Begleitung eines Erwachsenen statt. In diesem Kurs lernen Kinder und Eltern gemeinsam zur Ruhe zu kommen und Musik zu genießen.\r\n', 'Musikwiese', '', 'publish', 'closed', 'closed', '', 'musikwiese', '', '', '2015-12-15 15:29:26', '2015-12-15 14:29:26', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=elementarausbildung&#038;p=291', 0, 'elementarausbildung', '', 0),
(292, 1, '2015-12-15 17:43:54', '2015-12-15 16:43:54', '', 'orchester_fullscreen', '', 'inherit', 'open', 'closed', '', 'orchester_fullscreen', '', '', '2015-12-15 17:43:54', '2015-12-15 16:43:54', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/wp-content/uploads/2015/11/orchester_fullscreen.jpg', 0, 'attachment', 'image/jpeg', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(293, 1, '2015-12-15 17:45:28', '2015-12-15 16:45:28', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\n\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\n\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:', 'Musikschule', '', 'inherit', 'closed', 'closed', '', '19-autosave-v1', '', '', '2015-12-15 17:45:28', '2015-12-15 16:45:28', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/19-autosave-v1/', 0, 'revision', '', 0),
(294, 1, '2015-12-15 17:45:30', '2015-12-15 16:45:30', 'Die Musikschule Havixbeck verfügt über ein Unterrichtsangebot, welches die Aufgabenerfüllung in den verschiedensten Bereichen der Musikerziehung ermöglicht und darüber hinaus in einzelnen Schwerpunkten überregionale Ausstrahlung besitzt.\r\n\r\nDas Unterrichtsangebot berücksichtigt die Interessen der Schülerinnen und Schüler in bezug auf Stilrichtungen, Ausdrucksformen, Instrumente und Ensembles auf vielen musikalischen Gebieten. Im weiteren wird auf die individuellen Möglichkeiten und Fähigkeiten Rücksicht genommen.\r\n\r\nDie Angebote der Musikschule Havixbeck gliedern sich in Fachbereiche, die jeweils untereinander vernetzt sind:', 'Musikschule', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2015-12-15 17:45:30', '2015-12-15 16:45:30', '', 19, 'http://localhost/musikschule-wp-theme/wordpress/19-revision-v1/', 0, 'revision', '', 0),
(295, 1, '2015-12-15 19:18:47', '2015-12-15 18:18:47', 'Morbi leo risus, porta ac consectetur ac, vestibulum at eros. Maecenas sed diam eget risus varius blandit sit amet non magna. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Nulla vitae elit libero, a pharetra augue. Curabitur blandit tempus porttitor. Aenean lacinia bibendum nulla sed consectetur.\r\n\r\nEtiam porta sem malesuada magna mollis euismod. Donec ullamcorper nulla non metus auctor fringilla. Donec id elit non mi porta gravida at eget metus. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit.\r\n\r\nMorbi leo risus, porta ac consectetur ac, vestibulum at eros. Sed posuere consectetur est at lobortis. Vestibulum id ligula porta felis euismod semper. Integer posuere erat a ante venenatis dapibus posuere velit aliquet. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Aenean lacinia bibendum nulla sed consectetur. Nulla vitae elit libero, a pharetra augue.', 'Arschgeige', '', 'trash', 'closed', 'closed', '', 'arschgeige', '', '', '2015-12-15 19:19:11', '2015-12-15 18:19:11', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?post_type=instrumente&#038;p=295', 0, 'instrumente', '', 0),
(296, 1, '2015-12-15 19:31:02', '2015-12-15 18:31:02', '', 'Startseite', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2015-12-15 19:31:02', '2015-12-15 18:31:02', '', 4, 'http://localhost/musikschule-wp-theme/wordpress/4-revision-v1/', 0, 'revision', '', 0),
(298, 1, '2016-01-06 18:29:54', '0000-00-00 00:00:00', '', 'Automatisch gespeicherter Entwurf', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-01-06 18:29:54', '0000-00-00 00:00:00', '', 0, 'http://localhost/musikschule-wp-theme/wordpress/?p=298', 0, 'post', '', 0),
(299, 1, '2016-01-06 18:35:51', '2016-01-06 17:35:51', '[si-contact-form form=\'1\']\r\n\r\n', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-06 18:35:51', '2016-01-06 17:35:51', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=299', 0, 'revision', '', 0),
(300, 1, '2016-01-06 18:39:27', '2016-01-06 17:39:27', '[si-contact-form form=\'1\']\r\n\r\n[wpgmza id="1"]', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-06 18:39:27', '2016-01-06 17:39:27', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=300', 0, 'revision', '', 0),
(301, 1, '2016-01-06 18:40:10', '2016-01-06 17:40:10', '[wpgmza id="1"]\r\n\r\n[si-contact-form form=\'1\']\r\n', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-06 18:40:10', '2016-01-06 17:40:10', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=301', 0, 'revision', '', 0),
(302, 1, '2016-01-07 09:32:34', '2016-01-07 08:32:34', 'jugendorchester havixbeck\nTRÄGER DER\nmusikschule havixbeck\n\nbellegarde platz\n48329 havixbeck\n\ntel. 02507 - 2285\nfax 02507 - 4075\n\nmail@musikschule-havixbeck.de\n<div class="row">\n<div class="col-lg-6" >\n[wpgmza id="1"]\n</div>\n</div>\n\n[si-contact-form form=\'1\']', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-autosave-v1', '', '', '2016-01-07 09:32:34', '2016-01-07 08:32:34', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=302', 0, 'revision', '', 0),
(303, 1, '2016-01-06 18:42:13', '2016-01-06 17:42:13', '                         jugendorchester havixbeck \r\n                               TRÄGER DER \r\n                          musikschule havixbeck \r\n\r\n                            bellegarde platz \r\n                            48329 havixbeck \r\n\r\n                           tel. 02507 - 2285 \r\n                           fax 02507 - 4075 \r\n\r\n                     mail@musikschule-havixbeck.de\r\n\r\n                             [wpgmza id="1"]\r\n\r\n                          [si-contact-form form=\'1\']', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-06 18:42:13', '2016-01-06 17:42:13', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=303', 0, 'revision', '', 0),
(304, 1, '2016-01-07 09:32:37', '2016-01-07 08:32:37', 'jugendorchester havixbeck\r\nTRÄGER DER\r\nmusikschule havixbeck\r\n\r\nbellegarde platz\r\n48329 havixbeck\r\n\r\ntel. 02507 - 2285\r\nfax 02507 - 4075\r\n\r\nmail@musikschule-havixbeck.de\r\n<div class="row">\r\n<div class="col-lg-6" >\r\n[wpgmza id="1"]\r\n</div>\r\n</div>\r\n\r\n[si-contact-form form=\'1\']', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-07 09:32:37', '2016-01-07 08:32:37', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=304', 0, 'revision', '', 0),
(305, 1, '2016-01-07 09:33:11', '2016-01-07 08:33:11', 'jugendorchester havixbeck\r\nTRÄGER DER\r\nmusikschule havixbeck\r\n\r\nbellegarde platz\r\n48329 havixbeck\r\n\r\ntel. 02507 - 2285\r\nfax 02507 - 4075\r\n\r\nmail@musikschule-havixbeck.de\r\n<div class="row">\r\n<div class="col-lg-6">\r\nasd[wpgmza id="1"] \r\n</div>\r\n</div>\r\n\r\n[si-contact-form form=\'1\']', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-07 09:33:11', '2016-01-07 08:33:11', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=305', 0, 'revision', '', 0),
(306, 1, '2016-01-07 09:33:50', '2016-01-07 08:33:50', 'jugendorchester havixbeck\r\nTRÄGER DER\r\nmusikschule havixbeck\r\n\r\nbellegarde platz\r\n48329 havixbeck\r\n\r\ntel. 02507 - 2285\r\nfax 02507 - 4075\r\n\r\nmail@musikschule-havixbeck.de\r\n<div class="container">\r\n<div class="row">\r\n<div class="col-lg-6">\r\n[wpgmza id="1"] \r\n</div>\r\n</div>\r\n</div>\r\n\r\n[si-contact-form form=\'1\']', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-07 09:33:50', '2016-01-07 08:33:50', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=306', 0, 'revision', '', 0),
(307, 1, '2016-01-07 09:34:24', '2016-01-07 08:34:24', '<div class="row text-center">\r\njugendorchester havixbeck\r\nTRÄGER DER\r\nmusikschule havixbeck\r\n\r\nbellegarde platz\r\n48329 havixbeck\r\n\r\ntel. 02507 - 2285\r\nfax 02507 - 4075\r\n\r\nmail@musikschule-havixbeck.de\r\n</div>\r\n<div class="container">\r\n<div class="row">\r\n<div class="col-lg-6">\r\n[wpgmza id="1"] \r\n</div>\r\n</div>\r\n</div>\r\n\r\n[si-contact-form form=\'1\']', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-07 09:34:24', '2016-01-07 08:34:24', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=307', 0, 'revision', '', 0),
(308, 1, '2016-01-07 09:34:35', '2016-01-07 08:34:35', '<div class="row text-center">\r\n<div class="col-lg-6">\r\njugendorchester havixbeck\r\nTRÄGER DER\r\nmusikschule havixbeck\r\n\r\nbellegarde platz\r\n48329 havixbeck\r\n\r\ntel. 02507 - 2285\r\nfax 02507 - 4075\r\n\r\nmail@musikschule-havixbeck.de\r\n</div>\r\n</div>\r\n<div class="container">\r\n<div class="row">\r\n<div class="col-lg-6">\r\n[wpgmza id="1"] \r\n</div>\r\n</div>\r\n</div>\r\n\r\n[si-contact-form form=\'1\']', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-07 09:34:35', '2016-01-07 08:34:35', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=308', 0, 'revision', '', 0),
(309, 1, '2016-01-07 09:34:53', '2016-01-07 08:34:53', '<div class="row text-center">\r\n<div class="col-lg-12">\r\njugendorchester havixbeck\r\nTRÄGER DER\r\nmusikschule havixbeck\r\n\r\nbellegarde platz\r\n48329 havixbeck\r\n\r\ntel. 02507 - 2285\r\nfax 02507 - 4075\r\n\r\nmail@musikschule-havixbeck.de\r\n</div>\r\n</div>\r\n<div class="container">\r\n<div class="row">\r\n<div class="col-lg-6">\r\n[wpgmza id="1"] \r\n</div>\r\n</div>\r\n</div>\r\n\r\n[si-contact-form form=\'1\']', 'Kontakt', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2016-01-07 09:34:53', '2016-01-07 08:34:53', '', 25, 'http://localhost/musikschule-wp-theme/wordpress/?p=309', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(28, 1, 0),
(69, 2, 0),
(159, 2, 0),
(161, 2, 0),
(162, 2, 0),
(163, 2, 0),
(164, 2, 0),
(165, 2, 0),
(166, 2, 0),
(167, 2, 0),
(168, 2, 0),
(169, 2, 0),
(170, 2, 0),
(171, 2, 0),
(172, 2, 0),
(173, 2, 0),
(174, 2, 0),
(175, 2, 0),
(176, 2, 0),
(177, 2, 0),
(178, 2, 0),
(179, 2, 0),
(180, 2, 0),
(181, 2, 0),
(182, 2, 0),
(183, 2, 0),
(184, 2, 0),
(185, 2, 0),
(186, 2, 0),
(187, 2, 0),
(188, 2, 0),
(189, 2, 0),
(190, 2, 0),
(191, 4, 0),
(192, 4, 0),
(193, 4, 0),
(194, 4, 0),
(195, 4, 0),
(196, 4, 0),
(197, 4, 0),
(198, 4, 0),
(199, 4, 0),
(200, 5, 0),
(201, 5, 0),
(202, 5, 0),
(203, 5, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'nav_menu', '', 0, 32),
(3, 3, 'category', '', 0, 0),
(4, 4, 'nav_menu', '', 0, 9),
(5, 5, 'nav_menu', '', 0, 4) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Allgemein', 'allgemein', 0),
(2, 'primary', 'primary', 0),
(3, 'Instrument', 'instrument', 0),
(4, 'left', 'left', 0),
(5, 'Anmeldung', 'anmeldung', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:1:{s:64:"a6b58ed0beac0326beb38e82df08b43caca0d882bf50591796c206f190681517";a:4:{s:10:"expiration";i:1452274189;s:2:"ip";s:3:"::1";s:2:"ua";s:116:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/601.3.9 (KHTML, like Gecko) Version/9.0.2 Safari/601.3.9";s:5:"login";i:1452101389;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '298'),
(16, 1, 'wp_user-settings', 'editor=html&libraryContent=browse&imgsize=large&hidetb=1'),
(17, 1, 'wp_user-settings-time', '1450029302'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(20, 1, 'nav_menu_recently_edited', '2'),
(21, 1, 'tribe_setDefaultNavMenuBoxes', '1'),
(22, 1, 'closedpostboxes_acf', 'a:0:{}'),
(23, 1, 'metaboxhidden_acf', 'a:0:{}'),
(24, 1, 'closedpostboxes_post', 'a:0:{}'),
(25, 1, 'metaboxhidden_post', 'a:5:{i:0;s:13:"trackbacksdiv";i:1;s:10:"postcustom";i:2;s:16:"commentstatusdiv";i:3;s:7:"slugdiv";i:4;s:9:"authordiv";}'),
(26, 1, 'meta-box-order_post', 'a:4:{s:15:"acf_after_title";s:6:"acf_61";s:4:"side";s:51:"submitdiv,categorydiv,tagsdiv-post_tag,postimagediv";s:6:"normal";s:78:"acf_60,postexcerpt,trackbacksdiv,postcustom,commentstatusdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(27, 1, 'screen_layout_post', '2'),
(28, 1, 'edit_page_per_page', '50'),
(29, 1, 'edit_instrumente_per_page', '50') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BdJerSEztu6gq.AAz6eD9//Mz.BNhd/', 'admin', 'brian.joe.stark@gmail.com', '', '2015-10-22 07:58:38', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpgmza`
#

DROP TABLE IF EXISTS `wp_wpgmza`;


#
# Table structure of table `wp_wpgmza`
#

CREATE TABLE `wp_wpgmza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `address` varchar(700) NOT NULL,
  `description` mediumtext NOT NULL,
  `pic` varchar(700) NOT NULL,
  `link` varchar(700) NOT NULL,
  `icon` varchar(700) NOT NULL,
  `lat` varchar(100) NOT NULL,
  `lng` varchar(100) NOT NULL,
  `anim` varchar(3) NOT NULL,
  `title` varchar(700) NOT NULL,
  `infoopen` varchar(3) NOT NULL,
  `category` varchar(500) NOT NULL,
  `approved` tinyint(1) DEFAULT '1',
  `retina` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wpgmza`
#
INSERT INTO `wp_wpgmza` ( `id`, `map_id`, `address`, `description`, `pic`, `link`, `icon`, `lat`, `lng`, `anim`, `title`, `infoopen`, `category`, `approved`, `retina`) VALUES
(1, 1, 'California', '', '', '', '', '36.778261', '-119.4179323999', '', '', '', '0', 1, 0),
(2, 1, 'Bellegarde-Platz 48329, Havixbeck, Deutschland', '', '', '', '', '51.97555209999999', '7.413628199999948', '0', '', '0', '', 1, 0) ;

#
# End of data contents of table `wp_wpgmza`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpgmza_categories`
#

DROP TABLE IF EXISTS `wp_wpgmza_categories`;


#
# Table structure of table `wp_wpgmza_categories`
#

CREATE TABLE `wp_wpgmza_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(1) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `category_icon` varchar(700) NOT NULL,
  `retina` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wpgmza_categories`
#

#
# End of data contents of table `wp_wpgmza_categories`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpgmza_category_maps`
#

DROP TABLE IF EXISTS `wp_wpgmza_category_maps`;


#
# Table structure of table `wp_wpgmza_category_maps`
#

CREATE TABLE `wp_wpgmza_category_maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `map_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wpgmza_category_maps`
#

#
# End of data contents of table `wp_wpgmza_category_maps`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpgmza_maps`
#

DROP TABLE IF EXISTS `wp_wpgmza_maps`;


#
# Table structure of table `wp_wpgmza_maps`
#

CREATE TABLE `wp_wpgmza_maps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_title` varchar(50) NOT NULL,
  `map_width` varchar(6) NOT NULL,
  `map_height` varchar(6) NOT NULL,
  `map_start_lat` varchar(700) NOT NULL,
  `map_start_lng` varchar(700) NOT NULL,
  `map_start_location` varchar(700) NOT NULL,
  `map_start_zoom` int(10) NOT NULL,
  `default_marker` varchar(700) NOT NULL,
  `type` int(10) NOT NULL,
  `alignment` int(10) NOT NULL,
  `directions_enabled` int(10) NOT NULL,
  `styling_enabled` int(10) NOT NULL,
  `styling_json` mediumtext NOT NULL,
  `active` int(1) NOT NULL,
  `kml` varchar(700) NOT NULL,
  `bicycle` int(10) NOT NULL,
  `traffic` int(10) NOT NULL,
  `dbox` int(10) NOT NULL,
  `dbox_width` varchar(10) NOT NULL,
  `listmarkers` int(10) NOT NULL,
  `listmarkers_advanced` int(10) NOT NULL,
  `filterbycat` tinyint(1) NOT NULL,
  `ugm_enabled` int(10) NOT NULL,
  `ugm_category_enabled` tinyint(1) NOT NULL,
  `fusion` varchar(100) NOT NULL,
  `map_width_type` varchar(3) NOT NULL,
  `map_height_type` varchar(3) NOT NULL,
  `mass_marker_support` int(10) NOT NULL,
  `ugm_access` int(10) NOT NULL,
  `order_markers_by` int(10) NOT NULL,
  `order_markers_choice` int(10) NOT NULL,
  `show_user_location` int(3) NOT NULL,
  `default_to` varchar(700) NOT NULL,
  `other_settings` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


#
# Data contents of table `wp_wpgmza_maps`
#
INSERT INTO `wp_wpgmza_maps` ( `id`, `map_title`, `map_width`, `map_height`, `map_start_lat`, `map_start_lng`, `map_start_location`, `map_start_zoom`, `default_marker`, `type`, `alignment`, `directions_enabled`, `styling_enabled`, `styling_json`, `active`, `kml`, `bicycle`, `traffic`, `dbox`, `dbox_width`, `listmarkers`, `listmarkers_advanced`, `filterbycat`, `ugm_enabled`, `ugm_category_enabled`, `fusion`, `map_width_type`, `map_height_type`, `mass_marker_support`, `ugm_access`, `order_markers_by`, `order_markers_choice`, `show_user_location`, `default_to`, `other_settings`) VALUES
(1, 'My first map', '100', '400', '51.975552', '7.413628', '51.97555209999999,7.413628199999948', 15, '0', 1, 1, 1, 0, '', 0, '', 2, 2, 1, '250', 0, 0, 0, 0, 0, '', '\\%', 'px', 1, 0, 1, 2, 0, '', 'a:8:{s:21:"store_locator_enabled";i:2;s:22:"store_locator_distance";i:2;s:20:"store_locator_bounce";i:1;s:26:"store_locator_query_string";s:14:"ZIP / Address:";s:29:"wpgmza_store_locator_restrict";s:0:"";s:12:"map_max_zoom";s:1:"1";s:15:"transport_layer";i:2;s:17:"wpgmza_theme_data";s:0:"";}') ;

#
# End of data contents of table `wp_wpgmza_maps`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpgmza_polygon`
#

DROP TABLE IF EXISTS `wp_wpgmza_polygon`;


#
# Table structure of table `wp_wpgmza_polygon`
#

CREATE TABLE `wp_wpgmza_polygon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `polydata` longtext NOT NULL,
  `linecolor` varchar(7) NOT NULL,
  `lineopacity` varchar(7) NOT NULL,
  `fillcolor` varchar(7) NOT NULL,
  `opacity` varchar(3) NOT NULL,
  `title` varchar(250) NOT NULL,
  `link` varchar(700) NOT NULL,
  `ohfillcolor` varchar(7) NOT NULL,
  `ohlinecolor` varchar(7) NOT NULL,
  `ohopacity` varchar(3) NOT NULL,
  `polyname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wpgmza_polygon`
#

#
# End of data contents of table `wp_wpgmza_polygon`
# --------------------------------------------------------



#
# Delete any existing table `wp_wpgmza_polylines`
#

DROP TABLE IF EXISTS `wp_wpgmza_polylines`;


#
# Table structure of table `wp_wpgmza_polylines`
#

CREATE TABLE `wp_wpgmza_polylines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `map_id` int(11) NOT NULL,
  `polydata` longtext NOT NULL,
  `linecolor` varchar(7) NOT NULL,
  `linethickness` varchar(3) NOT NULL,
  `opacity` varchar(3) NOT NULL,
  `polyname` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_wpgmza_polylines`
#

#
# End of data contents of table `wp_wpgmza_polylines`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

